import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../models/meal_model.dart';

//  Sources used:
//  1. TheMealDB (by-letter) → /search.php?f=a … z   (free, no key)
//  2. TheMealDB (by-name)   → /search.php?s=<term>  (free, no key)
//  3. Static JSON           → assets/static_recipes.json (bundled fallback)
// ─────────────────────────────────────────────────────────────────────────────
class RecipeService {
  static const String _mealDbUrl = 'https://www.themealdb.com/api/json/v1/1';

  // Extra name-based search terms for TheMealDB /search.php?s=
  static const List<String> _mealDbSearchTerms = [
    'Arrabiata', 'chicken', 'beef', 'pasta', 'soup', 'salad',
    'curry', 'rice', 'fish', 'lamb', 'pork', 'cake', 'pizza',
    'burger', 'steak', 'noodles', 'sushi', 'tacos', 'biryani',
    'sandwich', 'omelette', 'pancakes', 'smoothie', 'bread',
  ];

  // ─── IN-MEMORY CACHE ──────────────────────────────────────────────────────
  List<MealModel>? _cachedRecipes;

  // ── DP search memo-cache — avoids re-fetching same query ──────────────────
  final Map<String, List<MealModel>> _searchCache = {};

  // ─────────────────────────────────────────────────────────────────────────
  //  GET ALL RECIPES  (cached — only fetched once per session)
  // ─────────────────────────────────────────────────────────────────────────
  Future<List<MealModel>> getAllRecipes() async {
    if (_cachedRecipes != null) return _cachedRecipes!;

    try {
      final results = await Future.wait([
        _fetchMealDbByName(),
        _fetchMealDb(),
        _fetchStatic(),
      ]);

      final all  = results.expand((e) => e).toList();
      final seen = <String>{};
      final unique = <MealModel>[];

      for (final meal in all) {
        if (meal.name.isEmpty) continue;
        final key = meal.id.isNotEmpty ? meal.id : meal.name.toLowerCase();
        if (seen.add(key)) unique.add(meal);
      }

      unique.shuffle();
      _cachedRecipes = unique;
      return unique;
    } catch (e) {
      debugPrint('getAllRecipes error: $e');
      return [];
    }
  }

  /// Clears cache so next call re-fetches fresh data.
  void clearCache() { _cachedRecipes = null; _searchCache.clear(); }

  // ─────────────────────────────────────────────────────────────────────────
  //  SEARCH  (uses cache — zero extra network calls)
  // ─────────────────────────────────────────────────────────────────────────
  Future<List<MealModel>> search(String query) async {
    final key = query.trim().toLowerCase();
    if (_searchCache.containsKey(key)) return _searchCache[key]!;
    final all = await getAllRecipes();
    final q   = query.toLowerCase().trim();
    if (q.isEmpty) return all;

    return all.where((m) {
      return m.name.toLowerCase().contains(q) ||
          m.category.toLowerCase().contains(q) ||
          m.area.toLowerCase().contains(q) ||
          m.ingredients.any((i) => i.toLowerCase().contains(q));
    }).toList();
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  1. THEMEALDB  (free forever, no key)
  //     Fetches all 26 letters for the widest recipe pool (~300 meals)
  // ─────────────────────────────────────────────────────────────────────────
  Future<List<MealModel>> _fetchMealDb() async {
    final meals = <MealModel>[];
    final seen  = <String>{};

    for (final letter in 'abcdefghijklmnopqrstuvwxyz'.split('')) {
      try {
        final res = await http.get(
          Uri.parse('$_mealDbUrl/search.php?f=$letter'),
        ).timeout(const Duration(seconds: 10));

        if (res.statusCode != 200) continue;

        final data = jsonDecode(res.body);
        final list = data['meals'];
        if (list == null) continue;

        for (final m in list) {
          final meal = MealModel.fromJson(m);
          if (seen.add(meal.id)) meals.add(meal);
        }
      } catch (e) {
        debugPrint('MealDB [$letter]: $e');
      }
    }

    debugPrint('MealDB fetched: ${meals.length} recipes');
    return meals;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  2. THEMEALDB BY NAME  /search.php?s=<term>
  //     Catches meals that the a–z letter sweep may miss, plus lets us
  //     explicitly ensure specific dishes like Arrabiata are always present.
  // ─────────────────────────────────────────────────────────────────────────
  Future<List<MealModel>> _fetchMealDbByName() async {
    final meals = <MealModel>[];
    final seen  = <String>{};

    for (final term in _mealDbSearchTerms) {
      try {
        final res = await http.get(
          Uri.parse('$_mealDbUrl/search.php?s=$term'),
        ).timeout(const Duration(seconds: 10));

        if (res.statusCode != 200) continue;

        final data = jsonDecode(res.body);
        final list = data['meals'];
        if (list == null) continue;

        for (final m in list) {
          final meal = MealModel.fromJson(m);
          if (seen.add(meal.id)) meals.add(meal);
        }
      } catch (e) {
        debugPrint('MealDB by-name [$term]: $e');
      }
    }

    debugPrint('MealDB by-name fetched: ${meals.length} recipes');
    return meals;
  }

  // ─────────────────────────────────────────────────────────────────────────
  //  3. STATIC JSON  (bundled fallback — always works offline)
  // ─────────────────────────────────────────────────────────────────────────
  Future<List<MealModel>> _fetchStatic() async {
    try {
      final jsonStr =
          await rootBundle.loadString('assets/static_recipes.json');
      final List data = jsonDecode(jsonStr);
      return data.map((e) => MealModel.fromJson(e)).toList();
    } catch (e) {
      debugPrint('Static JSON: $e');
      return [];
    }
  }
}