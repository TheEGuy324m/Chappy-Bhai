import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

/// Central permission service — call before any feature that needs OS access.
class PermissionService {
  PermissionService._();

  // ── Camera + Gallery (photo picker / QR) ─────────────────────────────────
  static Future<bool> requestCamera(BuildContext context) async {
    final cam = await Permission.camera.request();
    return cam.isGranted;
  }

  static Future<bool> requestGallery(BuildContext context) async {
    // Android 13+ uses photos permission; older uses storage
    final photos  = await Permission.photos.request();
    final storage = await Permission.storage.request();
    return photos.isGranted || storage.isGranted;
  }

  static Future<bool> requestCameraAndGallery(BuildContext context) async {
    final results = await [
      Permission.camera,
      Permission.photos,
      Permission.storage,
    ].request();
    final granted = results.values.any((s) => s.isGranted);
    if (!granted && context.mounted) {
      _showDeniedDialog(context,
          'Camera & Gallery',
          'Cheffy needs camera and photo access to upload dish photos and scan QR codes.');
    }
    return granted;
  }

  // ── Location (Nearby Stores) ──────────────────────────────────────────────
  static Future<bool> requestLocation(BuildContext context) async {
    final status = await Permission.locationWhenInUse.request();
    if (!status.isGranted && context.mounted) {
      _showDeniedDialog(context, 'Location',
          'Cheffy needs location access to find grocery stores near you.');
    }
    return status.isGranted;
  }

  // ── Notifications ─────────────────────────────────────────────────────────
  static Future<bool> requestNotifications(BuildContext context) async {
    final status = await Permission.notification.request();
    return status.isGranted;
  }

  // ── Microphone ────────────────────────────────────────────────────────────
  static Future<bool> requestMicrophone(BuildContext context) async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  // ── Request ALL at once (call from SplashScreen or first launch) ──────────
  static Future<void> requestAll(BuildContext context) async {
    await [
      Permission.camera,
      Permission.photos,
      Permission.storage,
      Permission.locationWhenInUse,
      Permission.notification,
      Permission.microphone,
    ].request();
  }

  // ── Open Settings dialog ──────────────────────────────────────────────────
  static void _showDeniedDialog(
      BuildContext context, String feature, String reason) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('$feature Permission'),
        content: Text(reason),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Not Now'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            onPressed: () {
              Navigator.pop(context);
              openAppSettings();
            },
            child: const Text('Open Settings',
                style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }
}
