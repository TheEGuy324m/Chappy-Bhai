import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  BIOMETRIC AUTH SERVICE
// ─────────────────────────────────────────────────────────────────────────────
class BiometricAuthService {
  static final BiometricAuthService _instance =
      BiometricAuthService._internal();
  factory BiometricAuthService() => _instance;
  BiometricAuthService._internal();

  final LocalAuthentication _localAuth = LocalAuthentication();

  // ── CHECK AVAILABILITY ───────────────────────────────────────────────────
  Future<bool> isAvailable() async {
    try {
      final isDeviceSupported = await _localAuth.isDeviceSupported();
      if (!isDeviceSupported) return false;
      final canCheck = await _localAuth.canCheckBiometrics;
      final biometrics = await _localAuth.getAvailableBiometrics();
      return canCheck || biometrics.isNotEmpty;
    } on PlatformException catch (e) {
      debugPrint('[Biometric] isAvailable error: ${e.code}');
      return false;
    }
  }

  // ── GET AVAILABLE BIOMETRICS ─────────────────────────────────────────────
  Future<List<BiometricType>> getAvailableBiometrics() async {
    try {
      return await _localAuth.getAvailableBiometrics();
    } on PlatformException {
      return [];
    }
  }

  // ── AUTHENTICATE ─────────────────────────────────────────────────────────
  Future<BiometricResult> authenticate({
    String reason = 'Authenticate to access Cheffy',
  }) async {
    try {
      final available = await isAvailable();
      if (!available) {
        return BiometricResult.notAvailable;
      }

      final authenticated = await _localAuth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false, // allow PIN fallback
          stickyAuth: true,
          useErrorDialogs: true,
        ),
      );

      return authenticated ? BiometricResult.success : BiometricResult.failed;
    } on PlatformException catch (e) {
      debugPrint('[Biometric] Error: ${e.code} — ${e.message}');
      if (e.code == 'NotEnrolled') return BiometricResult.notEnrolled;
      if (e.code == 'LockedOut') return BiometricResult.lockedOut;
      if (e.code == 'PermanentlyLockedOut') return BiometricResult.lockedOut;
      return BiometricResult.error;
    }
  }

  // ── TOGGLE BIOMETRIC ENABLED ─────────────────────────────────────────────
  Future<void> setBiometricEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('biometric_enabled', value);
  }

  Future<bool> isBiometricEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('biometric_enabled') ?? false;
  }

  // ── GET BIOMETRIC ICON ───────────────────────────────────────────────────
  Future<IconData> getBiometricIcon() async {
    final types = await getAvailableBiometrics();
    if (types.contains(BiometricType.face)) {
      return Icons.face_unlock_outlined;
    } else if (types.contains(BiometricType.fingerprint)) {
      return Icons.fingerprint;
    }
    return Icons.lock_outline;
  }

  // ── GET BIOMETRIC LABEL ──────────────────────────────────────────────────
  Future<String> getBiometricLabel() async {
    final types = await getAvailableBiometrics();
    if (types.contains(BiometricType.face)) return 'Face ID';
    if (types.contains(BiometricType.fingerprint)) return 'Fingerprint';
    if (types.contains(BiometricType.iris)) return 'Iris Scan';
    return 'Biometrics';
  }
}

enum BiometricResult {
  success,
  failed,
  notAvailable,
  notEnrolled,
  lockedOut,
  error,
}

// ─────────────────────────────────────────────────────────────────────────────
//  BIOMETRIC LOCK SCREEN WIDGET
// ─────────────────────────────────────────────────────────────────────────────
class BiometricLockScreen extends StatefulWidget {
  final Widget child;
  const BiometricLockScreen({super.key, required this.child});

  @override
  State<BiometricLockScreen> createState() => _BiometricLockScreenState();
}

class _BiometricLockScreenState extends State<BiometricLockScreen> {
  final _bioService = BiometricAuthService();
  bool _isUnlocked = false;
  bool _isChecking = false;
  String _statusMsg = '';
  IconData _bioIcon = Icons.fingerprint;

  @override
  void initState() {
    super.initState();
    _checkAndAuth();
  }

  Future<void> _checkAndAuth() async {
    final enabled = await _bioService.isBiometricEnabled();
    if (!enabled) {
      setState(() => _isUnlocked = true);
      return;
    }
    _bioIcon = await _bioService.getBiometricIcon();
    _authenticate();
  }

  Future<void> _authenticate() async {
    setState(() {
      _isChecking = true;
      _statusMsg = '';
    });

    final result = await _bioService.authenticate(
      reason: 'Authenticate to open Cheffy',
    );

    if (!mounted) return;

    switch (result) {
      case BiometricResult.success:
        setState(() {
          _isUnlocked = true;
          _isChecking = false;
        });
        break;
      case BiometricResult.notAvailable:
        setState(() {
          _isUnlocked = true; // bypass if not available
          _isChecking = false;
        });
        break;
      case BiometricResult.notEnrolled:
        setState(() {
          _statusMsg = 'No biometrics enrolled. Using password.';
          _isChecking = false;
        });
        Navigator.pushReplacementNamed(context, '/login');
        break;
      case BiometricResult.lockedOut:
        setState(() {
          _statusMsg = 'Too many attempts. Try again later.';
          _isChecking = false;
        });
        break;
      default:
        setState(() {
          _statusMsg = 'Authentication failed. Try again.';
          _isChecking = false;
        });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isUnlocked) return widget.child;

    return Scaffold(
      backgroundColor: Colors.orange.shade700,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '👨‍🍳',
              style: TextStyle(fontSize: 72),
            ),
            const SizedBox(height: 16),
            const Text(
              'Cheffy',
              style: TextStyle(
                color: Colors.white,
                fontSize: 36,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Authentication required',
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 48),
            if (_isChecking)
              const CircularProgressIndicator(color: Colors.white)
            else
              GestureDetector(
                onTap: _authenticate,
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(_bioIcon, color: Colors.white, size: 48),
                ),
              ),
            const SizedBox(height: 20),
            if (_statusMsg.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(
                  _statusMsg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ),
            const SizedBox(height: 24),
            TextButton(
              onPressed: () =>
                  Navigator.pushReplacementNamed(context, '/login'),
              child: const Text(
                'Use password instead',
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
