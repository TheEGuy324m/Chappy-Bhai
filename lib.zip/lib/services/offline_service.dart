import 'dart:async';
import 'dart:convert';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  OFFLINE MODE SERVICE
// ─────────────────────────────────────────────────────────────────────────────
class OfflineService {
  static final OfflineService _instance = OfflineService._internal();
  factory OfflineService() => _instance;
  OfflineService._internal();

  final Connectivity _connectivity = Connectivity();
  final ValueNotifier<bool> isOnline = ValueNotifier(true);
  final ValueNotifier<bool> isSyncing = ValueNotifier(false);

  StreamSubscription? _subscription;
  static const String _queueKey = 'offline_operation_queue';

  // ── INIT (call from main) ─────────────────────────────────────────────────
  Future<void> initialize() async {
    final results = await _connectivity.checkConnectivity();
    _updateStatus(results);

    _subscription =
        _connectivity.onConnectivityChanged.listen((results) {
      _updateStatus(results);
      if (isOnline.value) {
        _syncQueue(); // auto-sync when back online
      }
    });
  }

  void _updateStatus(List<ConnectivityResult> results) {
    isOnline.value = results.any((r) => r != ConnectivityResult.none);
  }

  void dispose() {
    _subscription?.cancel();
    isOnline.dispose();
    isSyncing.dispose();
  }

  // ── QUEUE OPERATION ───────────────────────────────────────────────────────
  /// Queues a Firestore operation for later sync when offline
  Future<void> queueOperation({
    required String type, // 'add', 'update', 'delete'
    required String collection,
    required String docId,
    Map<String, dynamic>? data,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_queueKey) ?? [];

    final op = jsonEncode({
      'type': type,
      'collection': collection,
      'docId': docId,
      'data': data,
      'timestamp': DateTime.now().toIso8601String(),
    });

    raw.add(op);
    await prefs.setStringList(_queueKey, raw);
    debugPrint('[Offline] Queued $type on $collection/$docId');
  }

  // ── SYNC QUEUE ────────────────────────────────────────────────────────────
  Future<void> _syncQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_queueKey) ?? [];
    if (raw.isEmpty) return;

    isSyncing.value = true;
    debugPrint('[Offline] Syncing ${raw.length} queued operations…');

    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) {
      isSyncing.value = false;
      return;
    }

    final remaining = <String>[];

    for (final item in raw) {
      try {
        final op = jsonDecode(item) as Map<String, dynamic>;
        final type = op['type'] as String;
        final collection = op['collection'] as String;
        final docId = op['docId'] as String;
        final data = op['data'] as Map<String, dynamic>?;

        final ref = FirebaseFirestore.instance
            .collection('users')
            .doc(uid)
            .collection(collection)
            .doc(docId);

        if (type == 'add' || type == 'update') {
          await ref.set(data!, SetOptions(merge: true));
        } else if (type == 'delete') {
          await ref.delete();
        }

        debugPrint('[Offline] Synced: $type $collection/$docId');
      } catch (e) {
        debugPrint('[Offline] Failed to sync, re-queuing: $e');
        remaining.add(item);
      }
    }

    await prefs.setStringList(_queueKey, remaining);
    isSyncing.value = false;
    debugPrint('[Offline] Sync complete. ${remaining.length} failed.');
  }

  // ── MANUAL SYNC ───────────────────────────────────────────────────────────
  Future<void> manualSync() async {
    if (isOnline.value) {
      await _syncQueue();
    }
  }

  // ── QUEUE SIZE ────────────────────────────────────────────────────────────
  Future<int> getQueueSize() async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getStringList(_queueKey) ?? []).length;
  }

  // ── CLEAR QUEUE ───────────────────────────────────────────────────────────
  Future<void> clearQueue() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_queueKey);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  CONNECTIVITY BANNER — shows at top of any screen
// ─────────────────────────────────────────────────────────────────────────────
class ConnectivityBanner extends StatelessWidget {
  final Widget child;
  const ConnectivityBanner({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final svc = OfflineService();

    return Column(
      children: [
        ValueListenableBuilder<bool>(
          valueListenable: svc.isOnline,
          builder: (_, online, __) {
            if (online) {
              return ValueListenableBuilder<bool>(
                valueListenable: svc.isSyncing,
                builder: (_, syncing, __) {
                  if (!syncing) return const SizedBox.shrink();
                  return _Banner(
                    color: Colors.blue.shade700,
                    icon: Icons.sync,
                    message: 'Syncing offline data…',
                    spinning: true,
                  );
                },
              );
            }
            return _Banner(
              color: Colors.red.shade700,
              icon: Icons.wifi_off,
              message: 'No internet — changes saved locally',
              spinning: false,
            );
          },
        ),
        Expanded(child: child),
      ],
    );
  }
}

class _Banner extends StatelessWidget {
  final Color color;
  final IconData icon;
  final String message;
  final bool spinning;

  const _Banner({
    required this.color,
    required this.icon,
    required this.message,
    required this.spinning,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      color: color,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          spinning
              ? const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2),
                )
              : Icon(icon, color: Colors.white, size: 14),
          const SizedBox(width: 8),
          Text(
            message,
            style: const TextStyle(color: Colors.white, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
