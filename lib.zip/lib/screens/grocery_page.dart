import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../widgets/common_ui.dart';
import '../widgets/floating_ai_assistant.dart';

class GroceryPage extends StatefulWidget {
  const GroceryPage({super.key});
  @override
  State<GroceryPage> createState() => _GroceryPageState();
}

class _GroceryPageState extends State<GroceryPage> {
  late final WebViewController _controller;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {},
          onPageFinished: (url) {},
        ),
      )
      ..loadRequest(
        Uri.parse(
          'https://grocerapp.pk/?srsltid=AfmBOooq9Ls6NhMyJirN_xuLBHXnc_QzknPVXllF8vQonfmoAXNdSuSr',
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    // PopScope replaces the deprecated WillPopScope
    return Stack(
      children: [
        PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        if (await _controller.canGoBack()) {
          _controller.goBack();
        } else {
          if (context.mounted) Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        key: _scaffoldKey,
        drawer: buildDrawer(context),
        body: Column(
          children: [
            buildHeader(
              context: context,
              scaffoldKey: _scaffoldKey,
              screenWidth: screenWidth,
            ),
            Expanded(
              child: WebViewWidget(controller: _controller),
            ),
          ],
        ),
      ),
        ),
        const FloatingAIAssistant(currentPage: 'Grocery Store'),
      ],
    );
  }
}
