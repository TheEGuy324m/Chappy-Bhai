import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/permission_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _mainController;
  late AnimationController _floatController;
  late AnimationController _shimmerController;
  late AnimationController _pulseController;

  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;
  late Animation<double> _slideAnim;
  late Animation<double> _shimmerAnim;
  late Animation<double> _pulseAnim;

  final List<_FoodParticle> _particles = [];

  @override
  void initState() {
    super.initState();

    // Generate floating food particles
    final rng = Random();
    const foods = ['🍳', '🥗', '🍕', '🥘', '🍜', '🧁', '🥑', '🍋'];
    for (int i = 0; i < 12; i++) {
      _particles.add(_FoodParticle(
        emoji: foods[rng.nextInt(foods.length)],
        x: rng.nextDouble(),
        y: rng.nextDouble(),
        size: 16 + rng.nextDouble() * 18,
        speed: 0.3 + rng.nextDouble() * 0.7,
        phase: rng.nextDouble() * 2 * pi,
      ));
    }

    // Main entrance animation
    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _mainController, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)),
    );
    _scaleAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _mainController, curve: const Interval(0.0, 0.7, curve: Curves.elasticOut)),
    );
    _slideAnim = Tween<double>(begin: 40, end: 0).animate(
      CurvedAnimation(parent: _mainController, curve: const Interval(0.3, 1.0, curve: Curves.easeOut)),
    );

    // Floating particles
    _floatController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    // Shimmer on text
    _shimmerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat();
    _shimmerAnim = Tween<double>(begin: -1.5, end: 2.5).animate(
      CurvedAnimation(parent: _shimmerController, curve: Curves.easeInOut),
    );

    // Pulse glow on logo
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _mainController.forward();
    Timer(const Duration(milliseconds: 2800), _navigate);
  }

  Future<void> _navigate() async {
    // Request all app permissions on first launch
    if (mounted) await PermissionService.requestAll(context);

    final user = FirebaseAuth.instance.currentUser;
    if (!mounted) return;
    if (user != null) {
      // Admin auto-detect on splash for remembered sessions
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      Navigator.pushReplacementNamed(context, '/login');
    }
  }

  @override
  void dispose() {
    _mainController.dispose();
    _floatController.dispose();
    _shimmerController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        children: [
          // ── Gradient mesh background ──────────────────────────────────────
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFFFF6B00),
                  Color(0xFFFF8C42),
                  Color(0xFFFFB347),
                  Color(0xFFFF6B6B),
                ],
                stops: [0.0, 0.35, 0.65, 1.0],
              ),
            ),
          ),

          // ── Radial soft glow center ───────────────────────────────────────
          Center(
            child: Container(
              width: size.width * 0.85,
              height: size.width * 0.85,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    Colors.white.withValues(alpha: 0.12),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── Floating food particles ───────────────────────────────────────
          AnimatedBuilder(
            animation: _floatController,
            builder: (_, __) {
              final t = _floatController.value * 2 * pi;
              return Stack(
                children: _particles.map((p) {
                  final dy = sin(t * p.speed + p.phase) * 18;
                  final dx = cos(t * p.speed * 0.6 + p.phase) * 10;
                  return Positioned(
                    left: p.x * size.width + dx,
                    top: p.y * size.height + dy,
                    child: Opacity(
                      opacity: 0.18 + 0.12 * sin(t + p.phase).abs(),
                      child: Text(p.emoji, style: TextStyle(fontSize: p.size)),
                    ),
                  );
                }).toList(),
              );
            },
          ),

          // ── Main content ──────────────────────────────────────────────────
          Center(
            child: AnimatedBuilder(
              animation: _mainController,
              builder: (_, child) => FadeTransition(
                opacity: _fadeAnim,
                child: child,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Logo with pulse glow
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Transform.scale(
                      scale: _pulseAnim.value,
                      child: AnimatedBuilder(
                        animation: _scaleAnim,
                        builder: (_, child) => Transform.scale(
                          scale: _scaleAnim.value,
                          child: child,
                        ),
                        child: Container(
                          width: 130,
                          height: 130,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white.withValues(alpha: 0.5),
                                blurRadius: 40,
                                spreadRadius: 8,
                              ),
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.15),
                                blurRadius: 20,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text('👨‍🍳', style: TextStyle(fontSize: 60)),
                          ),
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 32),

                  // Shimmer "Cheffy" title
                  AnimatedBuilder(
                    animation: _shimmerAnim,
                    builder: (_, __) {
                      return ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                          colors: const [
                            Colors.white,
                            Color(0xFFFFECCC),
                            Colors.white,
                            Colors.white,
                          ],
                          stops: [0.0, _shimmerAnim.value - 0.2, _shimmerAnim.value, 1.0]
                              .map((s) => s.clamp(0.0, 1.0))
                              .toList(),
                        ).createShader(bounds),
                        child: const Text(
                          'Cheffy',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 52,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 3,
                            height: 1,
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(height: 10),

                  // Subtitle slide up
                  AnimatedBuilder(
                    animation: _slideAnim,
                    builder: (_, child) => Transform.translate(
                      offset: Offset(0, _slideAnim.value),
                      child: child,
                    ),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.35)),
                      ),
                      child: const Text(
                        'Your AI Personal Chef',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 60),

                  // Dot wave loader
                  _WaveDotsLoader(),
                ],
              ),
            ),
          ),

          // ── Bottom tagline ────────────────────────────────────────────────
          Positioned(
            bottom: 36,
            left: 0,
            right: 0,
            child: AnimatedBuilder(
              animation: _fadeAnim,
              builder: (_, __) => Opacity(
                opacity: _fadeAnim.value,
                child: const Text(
                  'Cook smart. Eat well.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Wave dots loader
// ─────────────────────────────────────────────────────────────────────────────
class _WaveDotsLoader extends StatefulWidget {
  @override
  State<_WaveDotsLoader> createState() => _WaveDotsLoaderState();
}

class _WaveDotsLoaderState extends State<_WaveDotsLoader>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1000))
      ..repeat();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(5, (i) {
            final phase = (i / 5);
            final t = (_ctrl.value - phase) % 1.0;
            final dy = -sin(t * 2 * pi) * 10;
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Transform.translate(
                offset: Offset(0, dy),
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.5 + 0.5 * sin(t * 2 * pi).abs()),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Food particle data
// ─────────────────────────────────────────────────────────────────────────────
class _FoodParticle {
  final String emoji;
  final double x, y, size, speed, phase;
  const _FoodParticle({
    required this.emoji,
    required this.x,
    required this.y,
    required this.size,
    required this.speed,
    required this.phase,
  });
}