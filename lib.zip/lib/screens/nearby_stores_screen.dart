import 'dart:convert';
import 'dart:async';
import '../app_secrets.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;
import '../widgets/common_ui.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  FREE API SETUP — ONLY ONE KEY NEEDED
//
//  Map tiles  → MapTiler free tier  (100k tiles/month, no billing required)
//               Sign up at https://cloud.maptiler.com, paste key below.
//
//  Store data → OpenStreetMap Overpass API  (100% free, NO key, NO signup)
//               Phone numbers come directly from OSM "phone" tags.
// ─────────────────────────────────────────────────────────────────────────────
// MapTiler key via AppSecrets (see app_secrets.dart) // <-- only key needed

const _overpassUrl = 'https://overpass-api.de/api/interpreter'; // free, no auth

// ─────────────────────────────────────────────────────────────────────────────
//  NEARBY STORES MAP SCREEN
// ─────────────────────────────────────────────────────────────────────────────
class NearbyStoresScreen extends StatefulWidget {
  const NearbyStoresScreen({super.key});

  @override
  State<NearbyStoresScreen> createState() => _NearbyStoresScreenState();
}

class _NearbyStoresScreenState extends State<NearbyStoresScreen>
    with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final MapController _mapController = MapController();

  LatLng? _userLocation;
  LatLng? _lastScannedLocation;
  List<Map<String, dynamic>> _stores = [];

  bool _isLoading = true;
  bool _isScanning = false;
  bool _locationDenied = false;
  String? _errorMsg;

  // Pulse animation
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseRadius;
  late Animation<double> _pulseOpacity;

  StreamSubscription<Position>? _locationSub;

  static const LatLng _defaultLocation = LatLng(31.5204, 74.3587); // Lahore
  static const double _searchRadiusMeters = 3000;
  static const double _rescanThresholdMeters = 100;

  @override
  void initState() {
    super.initState();
    _setupPulse();
    _init();
  }

  void _setupPulse() {
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));
    _pulseRadius = Tween<double>(begin: 0, end: 110).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeOut));
    _pulseOpacity = Tween<double>(begin: 0.65, end: 0.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeOut));
  }

  void _triggerPulse() {
    _pulseCtrl.forward(from: 0).then((_) {
      if (!mounted) return;
      _pulseCtrl.forward(from: 0).then((_) {
        if (!mounted) return;
        _pulseCtrl.forward(from: 0).then((_) {
          if (mounted) setState(() => _isScanning = false);
        });
      });
    });
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _locationSub?.cancel();
    super.dispose();
  }

  Future<void> _init() => _requestLocationAndLoad();

  // ── Location ───────────────────────────────────────────────────────────────
  Future<void> _requestLocationAndLoad() async {
    setState(() {
      _isLoading = true;
      _errorMsg = null;
      _locationDenied = false;
      _stores = [];
    });

    final approved = await _showLocationDialog();
    if (!approved) {
      _useDefault();
      return;
    }

    final status = await Permission.location.request();
    if (status.isDenied || status.isPermanentlyDenied) {
      setState(() => _locationDenied = true);
      _useDefault();
      return;
    }

    if (!await Geolocator.isLocationServiceEnabled()) {
      setState(() => _errorMsg = 'GPS disabled. Enable location services.');
      _useDefault();
      return;
    }

    try {
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      final loc = LatLng(pos.latitude, pos.longitude);
      setState(() {
        _userLocation = loc;
        _isLoading = false;
      });
      _mapController.move(loc, 14);
      _beginScan(loc);
      _startLiveTracking();
    } catch (_) {
      setState(() => _errorMsg = 'GPS fix failed. Showing default area.');
      _useDefault();
    }
  }

  void _useDefault() {
    setState(() {
      _userLocation = _defaultLocation;
      _isLoading = false;
    });
    _mapController.move(_defaultLocation, 14);
    _beginScan(_defaultLocation);
  }

  void _startLiveTracking() {
    _locationSub?.cancel();
    _locationSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 20,
      ),
    ).listen((pos) {
      final loc = LatLng(pos.latitude, pos.longitude);
      if (mounted) setState(() => _userLocation = loc);
      if (_lastScannedLocation != null) {
        final moved = const Distance()
            .as(LengthUnit.Meter, _lastScannedLocation!, loc);
        if (moved >= _rescanThresholdMeters) _beginScan(loc);
      }
    });
  }

  // ── Scan ───────────────────────────────────────────────────────────────────
  void _beginScan(LatLng loc) {
    _lastScannedLocation = loc;
    setState(() => _isScanning = true);
    _triggerPulse();
    _fetchFromOverpass(loc);
  }

  /// Overpass QL — queries nodes & ways for all grocery/supermarket types.
  /// Returns name, phone, opening_hours, website from OSM tags. FREE.
  Future<void> _fetchFromOverpass(LatLng loc) async {
    final query = '''
[out:json][timeout:25];
(
  node["shop"="supermarket"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  way["shop"="supermarket"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  node["shop"="grocery"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  way["shop"="grocery"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  node["shop"="convenience"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  node["shop"="department_store"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
  node["shop"="wholesale"](around:$_searchRadiusMeters,${loc.latitude},${loc.longitude});
);
out center tags;
''';

    try {
      final resp = await http
          .post(
            Uri.parse(_overpassUrl),
            body: 'data=${Uri.encodeQueryComponent(query)}',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          )
          .timeout(const Duration(seconds: 30));

      if (resp.statusCode == 200) {
        final data = jsonDecode(resp.body);
        final elements = (data['elements'] as List? ?? []);

        final stores = elements
            .where((e) => (e['tags']?['name'] != null))
            .map<Map<String, dynamic>>((e) {
              final tags = e['tags'] as Map<String, dynamic>? ?? {};
              final isWay = e['type'] == 'way';
              final lat = isWay
                  ? (e['center']?['lat'] ?? 0.0).toDouble()
                  : (e['lat'] ?? 0.0).toDouble();
              final lng = isWay
                  ? (e['center']?['lon'] ?? 0.0).toDouble()
                  : (e['lon'] ?? 0.0).toDouble();

              final rawHours =
                  (tags['opening_hours'] ?? '').toString().toLowerCase();
              final isOpen =
                  rawHours.contains('24/7') || rawHours.isNotEmpty;

              final phone = (tags['phone'] ??
                      tags['contact:phone'] ??
                      tags['phone:mobile'] ??
                      '')
                  .toString()
                  .split(';')
                  .first
                  .trim();

              return {
                'name': tags['name'] ?? 'Unknown Store',
                'address': _address(tags),
                'phone': phone,
                'website': (tags['website'] ??
                        tags['contact:website'] ??
                        '')
                    .toString(),
                'hours': (tags['opening_hours'] ?? '').toString(),
                'open': isOpen,
                'lat': lat,
                'lng': lng,
                'osm_id': '${e['type']}_${e['id']}',
              };
            })
            .where((s) => s['lat'] != 0.0 && s['lng'] != 0.0)
            .toList();

        // Sort nearest first
        if (_userLocation != null) {
          stores.sort((a, b) {
            final da = const Distance().as(LengthUnit.Meter, _userLocation!,
                LatLng(a['lat'] as double, a['lng'] as double));
            final db = const Distance().as(LengthUnit.Meter, _userLocation!,
                LatLng(b['lat'] as double, b['lng'] as double));
            return da.compareTo(db);
          });
        }

        if (mounted) setState(() => _stores = stores);
      } else {
        _loadDemo(loc);
      }
    } catch (_) {
      _loadDemo(loc);
    }
  }

  String _address(Map<String, dynamic> t) {
    final parts = [
      t['addr:housenumber'],
      t['addr:street'],
      t['addr:suburb'],
      t['addr:city'],
    ].whereType<String>().where((s) => s.isNotEmpty).toList();
    return parts.isNotEmpty
        ? parts.join(', ')
        : (t['addr:full'] ?? '').toString();
  }

  void _loadDemo(LatLng c) {
    if (mounted) {
      setState(() => _stores = [
            _demo('Metro Cash & Carry', 'Main Boulevard, Gulberg', '+92 42 3578 4000',
                'Mo-Su 08:00-23:00', true, c.latitude + 0.008, c.longitude + 0.005),
            _demo('Hyperstar', 'Johar Town, Lahore', '+92 42 3522 7000',
                'Mo-Su 09:00-22:00', true, c.latitude - 0.006, c.longitude + 0.010),
            _demo('Chase Up Superstore', 'Gulberg III, Lahore', '+92 42 3571 0000',
                '', false, c.latitude + 0.012, c.longitude - 0.007),
            _demo('Carrefour', 'DHA Phase 6, Lahore', '+92 42 3710 0000',
                'Mo-Su 09:00-23:00', true, c.latitude - 0.015, c.longitude - 0.003),
            _demo('Imtiaz Super Market', 'Scheme Mor, Lahore', '+92 42 3683 5000',
                'Mo-Su 08:00-22:00', true, c.latitude + 0.018, c.longitude + 0.015),
          ]);
    }
  }

  Map<String, dynamic> _demo(String name, String addr, String phone,
          String hours, bool open, double lat, double lng) =>
      {
        'name': name, 'address': addr, 'phone': phone,
        'website': '', 'hours': hours, 'open': open,
        'lat': lat, 'lng': lng, 'osm_id': name,
      };

  // ── Actions ────────────────────────────────────────────────────────────────
  Future<void> _openDirections(Map<String, dynamic> s) async {
    final uri = Uri.parse(
        'https://www.google.com/maps/dir/?api=1&destination=${s['lat']},${s['lng']}&travelmode=driving');
    if (await canLaunchUrl(uri)) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _callStore(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone.replaceAll(' ', ''));
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _openWebsite(String url) async {
    final uri = Uri.tryParse(url.startsWith('http') ? url : 'https://$url');
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _focusMap(Map<String, dynamic> s) =>
      _mapController.move(LatLng(s['lat'] as double, s['lng'] as double), 16);

  String _dist(Map<String, dynamic> s) {
    if (_userLocation == null) return '';
    final m = const Distance().as(LengthUnit.Meter, _userLocation!,
        LatLng(s['lat'] as double, s['lng'] as double));
    return m >= 1000 ? '${(m / 1000).toStringAsFixed(1)} km' : '${m.round()} m';
  }

  // ── Dialogs ────────────────────────────────────────────────────────────────
  Future<bool> _showLocationDialog() async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Row(children: [
          Icon(Icons.location_on, color: Colors.orange),
          SizedBox(width: 8),
          Text('Use Live Location'),
        ]),
        content: const Text(
          'We use your live GPS to scan nearby grocery stores using '
          'free OpenStreetMap data. Your location is never stored or shared.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Not Now')),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            icon: const Icon(Icons.radar, color: Colors.white, size: 16),
            label: const Text('Scan Now',
                style: TextStyle(color: Colors.white)),
            onPressed: () => Navigator.pop(ctx, true),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  void _showStoreSheet(Map<String, dynamic> s) {
    final isOpen = s['open'] as bool? ?? false;
    final phone = s['phone'] as String? ?? '';
    final website = s['website'] as String? ?? '';
    final hours = s['hours'] as String? ?? '';

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(
                      color: Colors.grey[300],
                      borderRadius: BorderRadius.circular(2))),
            ),
            const SizedBox(height: 12),
            Text(s['name'].toString(),
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 6),
            if ((s['address'] as String).isNotEmpty)
              _InfoRow(Icons.location_on_outlined, Colors.grey,
                  s['address'].toString()),
            _InfoRow(
              isOpen ? Icons.check_circle_outline : Icons.cancel_outlined,
              isOpen ? Colors.green : Colors.red,
              isOpen ? 'Open Now' : 'Closed',
            ),
            if (hours.isNotEmpty)
              _InfoRow(Icons.access_time, Colors.blueGrey, hours),
            if (phone.isNotEmpty)
              _InfoRow(Icons.phone, Colors.blue, phone,
                  onTap: () { Navigator.pop(ctx); _callStore(phone); }),
            if (website.isNotEmpty)
              _InfoRow(Icons.language, Colors.teal, website,
                  onTap: () { Navigator.pop(ctx); _openWebsite(website); }),
            if (_dist(s).isNotEmpty)
              _InfoRow(Icons.place_outlined, Colors.orange, _dist(s)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.directions, size: 16),
                  label: const Text('Directions'),
                  onPressed: () { Navigator.pop(ctx); _openDirections(s); },
                ),
              ),
              if (phone.isNotEmpty) ...[
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green),
                    icon: const Icon(Icons.call,
                        size: 16, color: Colors.white),
                    label: const Text('Call',
                        style: TextStyle(color: Colors.white)),
                    onPressed: () { Navigator.pop(ctx); _callStore(phone); },
                  ),
                ),
              ],
            ]),
          ],
        ),
      ),
    );
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final sw = MediaQuery.of(context).size.width;
    return CheffyScaffold(
      currentPage: 'Nearby Stores',
      child: Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      body: Column(
        children: [
          buildHeader(context: context, scaffoldKey: _scaffoldKey, screenWidth: sw),

          if (_locationDenied)
            _Banner(Colors.orange.shade100, Icons.location_off, Colors.orange,
                'Location denied — showing default area.',
                trailing: TextButton(
                    onPressed: openAppSettings,
                    child: const Text('Settings',
                        style: TextStyle(fontSize: 12, color: Colors.orange)))),

          if (_errorMsg != null)
            _Banner(Colors.blue.shade50, Icons.info_outline, Colors.blueGrey,
                _errorMsg!),

          if (_isScanning)
            _Banner(Colors.green.shade50, Icons.radar, Colors.green,
                'Scanning nearby stores via OpenStreetMap…'),

          // ── Map ───────────────────────────────────────────────────────────
          SizedBox(
            height: 300,
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: _userLocation ?? _defaultLocation,
                    initialZoom: 14,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate:
                          'https://api.maptiler.com/maps/streets-v2/{z}/{x}/{y}.png?key=${AppSecrets.mapTilerKey}',
                      userAgentPackageName: 'com.yourapp.name',
                    ),
                    MarkerLayer(markers: [
                      if (_userLocation != null)
                        Marker(
                          point: _userLocation!,
                          width: 120, height: 120,
                          child: _PulseMarker(
                              ctrl: _pulseCtrl,
                              radius: _pulseRadius,
                              opacity: _pulseOpacity),
                        ),
                      ..._stores.map((s) => Marker(
                            point: LatLng(s['lat'] as double, s['lng'] as double),
                            width: 40, height: 40,
                            child: GestureDetector(
                              onTap: () => _showStoreSheet(s),
                              child: _StorePin(isOpen: s['open'] as bool? ?? false),
                            ),
                          )),
                    ]),
                    const RichAttributionWidget(attributions: [
                      TextSourceAttribution('MapTiler'),
                      TextSourceAttribution('© OpenStreetMap contributors'),
                    ]),
                  ],
                ),

                if (_isLoading)
                  const Center(child: CircularProgressIndicator()),

                // Live badge
                if (!_locationDenied && !_isLoading)
                  Positioned(
                    top: 8, left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(20)),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.circle, color: Colors.green, size: 8),
                        SizedBox(width: 4),
                        Text('LIVE',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1)),
                      ]),
                    ),
                  ),

                // FABs
                Positioned(
                  bottom: 12, right: 12,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    FloatingActionButton.small(
                      heroTag: 'gps',
                      onPressed: _requestLocationAndLoad,
                      backgroundColor: Colors.orange,
                      tooltip: 'Use live location',
                      child: const Icon(Icons.my_location,
                          color: Colors.white, size: 18),
                    ),
                    const SizedBox(height: 8),
                    FloatingActionButton.small(
                      heroTag: 'scan',
                      onPressed: () {
                        if (_userLocation != null) _beginScan(_userLocation!);
                      },
                      backgroundColor: Colors.green,
                      tooltip: 'Re-scan area',
                      child: const Icon(Icons.radar,
                          color: Colors.white, size: 18),
                    ),
                  ]),
                ),
              ],
            ),
          ),

          // ── List header ───────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Row(children: [
              const Icon(Icons.store, color: Colors.orange, size: 18),
              const SizedBox(width: 8),
              Text('Nearby Stores (${_stores.length})',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 15)),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    border: Border.all(color: Colors.green.shade200),
                    borderRadius: BorderRadius.circular(8)),
                child: const Text('OSM • Free',
                    style: TextStyle(
                        fontSize: 10,
                        color: Colors.green,
                        fontWeight: FontWeight.bold)),
              ),
              const Spacer(),
              if (_isScanning)
                const SizedBox(
                    width: 14, height: 14,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.green)),
            ]),
          ),

          // ── Store list ────────────────────────────────────────────────────
          Expanded(
            child: _stores.isEmpty && !_isLoading && !_isScanning
                ? Center(
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('🏪', style: TextStyle(fontSize: 40)),
                      const SizedBox(height: 8),
                      Text('No stores found in this area',
                          style: TextStyle(color: Colors.grey[500])),
                      const SizedBox(height: 12),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange),
                        icon: const Icon(Icons.radar,
                            color: Colors.white, size: 16),
                        label: const Text('Scan Again',
                            style: TextStyle(color: Colors.white)),
                        onPressed: () {
                          if (_userLocation != null) _beginScan(_userLocation!);
                        },
                      ),
                    ]),
                  )
                : ListView.builder(
                    itemCount: _stores.length,
                    itemBuilder: (_, i) => _StoreCard(
                      store: _stores[i],
                      distance: _dist(_stores[i]),
                      onDirections: () => _openDirections(_stores[i]),
                      onCall: (_stores[i]['phone'] as String).isNotEmpty
                          ? () => _callStore(_stores[i]['phone'])
                          : null,
                      onFocus: () => _focusMap(_stores[i]),
                      onTap: () => _showStoreSheet(_stores[i]),
                    ),
                  ),
          ),

          buildFooter(),
        ],
      ),
    ));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  WIDGETS
// ─────────────────────────────────────────────────────────────────────────────

class _PulseMarker extends StatelessWidget {
  final AnimationController ctrl;
  final Animation<double> radius;
  final Animation<double> opacity;
  const _PulseMarker(
      {required this.ctrl, required this.radius, required this.opacity});

  @override
  Widget build(BuildContext context) => Stack(
        alignment: Alignment.center,
        children: [
          AnimatedBuilder(
            animation: ctrl,
            builder: (_, __) => Opacity(
              opacity: opacity.value,
              child: Container(
                width: radius.value,
                height: radius.value,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.orange.withValues(alpha: 0.2),
                  border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.5), width: 1.5),
                ),
              ),
            ),
          ),
          Container(
            width: 18, height: 18,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.orange,
              border: Border.all(color: Colors.white, width: 2.5),
              boxShadow: [
                BoxShadow(
                    color: Colors.orange.withValues(alpha: 0.5),
                    blurRadius: 8, spreadRadius: 2)
              ],
            ),
          ),
        ],
      );
}

class _StorePin extends StatelessWidget {
  final bool isOpen;
  const _StorePin({required this.isOpen});

  @override
  Widget build(BuildContext context) {
    final c = isOpen ? Colors.green : Colors.red;
    return Container(
      decoration: BoxDecoration(
        color: c, shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [BoxShadow(color: c.withValues(alpha: 0.4), blurRadius: 5)],
      ),
      child: const Center(
          child: Icon(Icons.store, color: Colors.white, size: 18)),
    );
  }
}

class _StoreCard extends StatelessWidget {
  final Map<String, dynamic> store;
  final String distance;
  final VoidCallback onDirections;
  final VoidCallback? onCall;
  final VoidCallback onFocus;
  final VoidCallback onTap;

  const _StoreCard({
    required this.store, required this.distance,
    required this.onDirections, required this.onCall,
    required this.onFocus, required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isOpen = store['open'] as bool? ?? false;
    final phone = store['phone'] as String? ?? '';
    final hours = store['hours'] as String? ?? '';

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                backgroundColor: isOpen ? Colors.green.shade50 : Colors.red.shade50,
                child: Icon(Icons.store,
                    color: isOpen ? Colors.green : Colors.red, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(store['name'].toString(),
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14)),
                    if ((store['address'] as String).isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(store['address'].toString(),
                          style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                    ],
                    const SizedBox(height: 4),
                    Wrap(spacing: 10, children: [
                      Text(isOpen ? 'Open' : 'Closed',
                          style: TextStyle(
                              fontSize: 12,
                              color: isOpen ? Colors.green : Colors.red,
                              fontWeight: FontWeight.w500)),
                      if (distance.isNotEmpty)
                        Text(distance,
                            style: TextStyle(
                                fontSize: 12, color: Colors.grey[600])),
                    ]),
                    if (phone.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      GestureDetector(
                        onTap: onCall,
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.phone, size: 13, color: Colors.blue),
                          const SizedBox(width: 3),
                          Text(phone,
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.blue,
                                  decoration: TextDecoration.underline)),
                        ]),
                      ),
                    ],
                    if (hours.isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.access_time,
                            size: 12, color: Colors.grey[500]),
                        const SizedBox(width: 3),
                        Flexible(
                          child: Text(hours,
                              style: TextStyle(
                                  fontSize: 11, color: Colors.grey[500]),
                              overflow: TextOverflow.ellipsis),
                        ),
                      ]),
                    ],
                  ],
                ),
              ),
              Column(mainAxisSize: MainAxisSize.min, children: [
                _Btn(Icons.location_on_outlined, Colors.orange, onFocus, 'Focus'),
                _Btn(Icons.directions, Colors.blue, onDirections, 'Directions'),
                if (onCall != null)
                  _Btn(Icons.call, Colors.green, onCall!, 'Call'),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}

class _Btn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final String tip;
  const _Btn(this.icon, this.color, this.onTap, this.tip);

  @override
  Widget build(BuildContext context) => IconButton(
        icon: Icon(icon, color: color, size: 20),
        tooltip: tip, onPressed: onTap,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
      );
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String text;
  final VoidCallback? onTap;
  const _InfoRow(this.icon, this.color, this.text, {this.onTap});

  @override
  Widget build(BuildContext context) {
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 15, color: color),
        const SizedBox(width: 6),
        Expanded(
          child: Text(text,
              style: TextStyle(
                  fontSize: 13,
                  color: onTap != null ? color : Colors.black87,
                  decoration:
                      onTap != null ? TextDecoration.underline : null)),
        ),
      ]),
    );
    return onTap != null ? GestureDetector(onTap: onTap, child: row) : row;
  }
}

class _Banner extends StatelessWidget {
  final Color bg;
  final IconData icon;
  final Color ic;
  final String msg;
  final Widget? trailing;
  const _Banner(this.bg, this.icon, this.ic, this.msg, {this.trailing});

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity, color: bg,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Row(children: [
          Icon(icon, color: ic, size: 15),
          const SizedBox(width: 8),
          Expanded(
              child: Text(msg,
                  style: TextStyle(fontSize: 12, color: ic))),
          if (trailing != null) trailing!,
        ]),
      );
}