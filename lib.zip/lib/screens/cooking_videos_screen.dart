import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/meal_model.dart';
import '../services/recipe_service.dart';
import '../widgets/common_ui.dart';

class CookingVideosScreen extends StatefulWidget {
  final MealModel? initialMeal;

  const CookingVideosScreen({super.key, this.initialMeal});

  @override
  State<CookingVideosScreen> createState() => _CookingVideosScreenState();
}

class _CookingVideosScreenState extends State<CookingVideosScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final RecipeService _recipeService = RecipeService();
  final YoutubeExplode _yt = YoutubeExplode();
  final TextEditingController _searchCtrl = TextEditingController();

  List<_VideoEntry> _allEntries = [];
  List<_VideoEntry> _filtered = [];

  bool _isLoading = true;
  String? _errorMsg;

  String _selectedCategory = 'All';
  List<String> _categories = ['All'];

  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    if (widget.initialMeal != null) {
      _searchQuery = widget.initialMeal!.name;
      _searchCtrl.text = widget.initialMeal!.name;
    }
    _loadFeed();
  }

  @override
  void dispose() {
    _yt.close();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadFeed() async {
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    try {
      final meals = await _recipeService.getAllRecipes();

      final cats = meals.map((m) => m.category).toSet().toList()..sort();
      _categories = ['All', ...cats];

      final entries = <_VideoEntry>[];

      for (var i = 0; i < meals.length; i += 10) {
        final chunk = meals.sublist(
            i, i + 10 > meals.length ? meals.length : i + 10);

        final resolved = await Future.wait(
          chunk.map((meal) => _resolveVideoId(meal)),
        );
        entries.addAll(resolved.whereType<_VideoEntry>());

        if (mounted) {
          setState(() {
            _allEntries = List.from(entries);
            _applyFilters();
            _isLoading = entries.isEmpty;
          });
        }
      }

      if (mounted) {
        setState(() {
          _allEntries = entries;
          _applyFilters();
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMsg = 'Failed to load videos: $e';
          _isLoading = false;
        });
      }
    }
  }

  Future<_VideoEntry?> _resolveVideoId(MealModel meal) async {
    try {
      if (meal.youtubeUrl.isNotEmpty) {
        final id = VideoId.parseVideoId(meal.youtubeUrl);
        if (id != null) {
          final video = await _yt.videos
              .get(id)
              .timeout(const Duration(seconds: 8));
          return _VideoEntry(
            meal: meal,
            videoId: id,
            ytTitle: video.title,
            ytThumbnail: video.thumbnails.highResUrl,
            ytDuration: video.duration,
            ytAuthor: video.author,
            ytViews: video.engagement.viewCount,
          );
        }
      }

      final results = await _yt.search
          .search('${meal.name} recipe cooking')
          .timeout(const Duration(seconds: 10));

      final first = results.whereType<Video>().first;
      return _VideoEntry(
        meal: meal,
        videoId: first.id.value,
        ytTitle: first.title,
        ytThumbnail: first.thumbnails.highResUrl,
        ytDuration: first.duration,
        ytAuthor: first.author,
        ytViews: first.engagement.viewCount,
      );
    } catch (_) {
      return _VideoEntry(
        meal: meal,
        videoId: null,
        ytTitle: '${meal.name} Recipe',
        ytThumbnail: meal.thumbnail,
        ytDuration: null,
        ytAuthor: null,
        ytViews: null,
      );
    }
  }

  void _applyFilters() {
    var list = _allEntries;

    if (_selectedCategory != 'All') {
      list = list.where((e) => e.meal.category == _selectedCategory).toList();
    }

    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      list = list.where((e) {
        return e.meal.name.toLowerCase().contains(q) ||
            e.meal.category.toLowerCase().contains(q) ||
            e.meal.area.toLowerCase().contains(q) ||
            e.ytTitle.toLowerCase().contains(q);
      }).toList();
    }

    _filtered = list;
  }

  String _formatViews(int? views) {
    if (views == null) return '';
    if (views >= 1000000) return '${(views / 1000000).toStringAsFixed(1)}M views';
    if (views >= 1000) return '${(views / 1000).toStringAsFixed(0)}K views';
    return '$views views';
  }

  String _formatDuration(Duration? d) {
    if (d == null) return '';
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final sw = MediaQuery.of(context).size.width;

    return Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      backgroundColor: const Color(0xFFF8F8F8),
      body: Column(
        children: [
          buildHeader(
              context: context,
              scaffoldKey: _scaffoldKey,
              screenWidth: sw),

          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: TextField(
              controller: _searchCtrl,
              onChanged: (v) {
                setState(() {
                  _searchQuery = v;
                  _applyFilters();
                });
              },
              decoration: InputDecoration(
                hintText: 'Search dishes, cuisines…',
                hintStyle: const TextStyle(fontSize: 13),
                prefixIcon:
                    const Icon(Icons.search, color: Colors.grey, size: 20),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() {
                            _searchQuery = '';
                            _applyFilters();
                          });
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide:
                      BorderSide(color: Colors.grey.shade200, width: 1),
                ),
              ),
            ),
          ),

          // Category chips
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: SizedBox(
              height: 34,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: _categories.length,
                separatorBuilder: (_, __) => const SizedBox(width: 6),
                itemBuilder: (_, i) {
                  final cat = _categories[i];
                  final sel = cat == _selectedCategory;
                  return GestureDetector(
                    onTap: () => setState(() {
                      _selectedCategory = cat;
                      _applyFilters();
                    }),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: sel ? Colors.orange : Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: sel
                                ? Colors.orange
                                : Colors.grey.shade200),
                        boxShadow: sel
                            ? [
                                BoxShadow(
                                    color: Colors.orange.withValues(alpha: 0.3),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2))
                              ]
                            : [],
                      ),
                      child: Text(
                        cat,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight:
                                sel ? FontWeight.bold : FontWeight.normal,
                            color: sel ? Colors.white : Colors.black87),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // Feed
          Expanded(
            child: _isLoading && _filtered.isEmpty
                ? _LoadingShimmer()
                : _errorMsg != null && _filtered.isEmpty
                    ? _ErrorState(
                        message: _errorMsg!,
                        onRetry: _loadFeed,
                      )
                    : _filtered.isEmpty
                        ? const Center(
                            child: Text('No videos found',
                                style: TextStyle(color: Colors.grey)))
                        : RefreshIndicator(
                            onRefresh: () async {
                              _recipeService.clearCache();
                              await _loadFeed();
                            },
                            child: ListView.builder(
                              padding:
                                  const EdgeInsets.fromLTRB(12, 0, 12, 12),
                              itemCount:
                                  _filtered.length + (_isLoading ? 1 : 0),
                              itemBuilder: (_, i) {
                                if (i == _filtered.length) {
                                  return const Padding(
                                    padding: EdgeInsets.all(16),
                                    child: Center(
                                        child: CircularProgressIndicator(
                                            color: Colors.orange)),
                                  );
                                }
                                final entry = _filtered[i];
                                return _VideoCard(
                                  entry: entry,
                                  durationLabel:
                                      _formatDuration(entry.ytDuration),
                                  viewsLabel: _formatViews(entry.ytViews),
                                  onTap: () => Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => _VideoDetailScreen(
                                        entry: entry,
                                        allEntries: _filtered,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
          ),

          buildFooter(),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  VIDEO ENTRY
// ─────────────────────────────────────────────────────────────────────────────
class _VideoEntry {
  final MealModel meal;
  final dynamic videoId;
  final String ytTitle;
  final String ytThumbnail;
  final Duration? ytDuration;
  final String? ytAuthor;
  final int? ytViews;

  const _VideoEntry({
    required this.meal,
    required this.videoId,
    required this.ytTitle,
    required this.ytThumbnail,
    required this.ytDuration,
    required this.ytAuthor,
    required this.ytViews,
  });

  bool get hasVideo => videoId != null;

  String get thumbnailUrl =>
      ytThumbnail.isNotEmpty ? ytThumbnail : meal.thumbnail;

  String get youtubeUrl {
    if (videoId != null) {
      final id = videoId is VideoId
          ? (videoId as VideoId).value
          : videoId.toString();
      return 'https://www.youtube.com/watch?v=$id';
    }
    if (meal.youtubeUrl.isNotEmpty) return meal.youtubeUrl;
    return 'https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent('${meal.name} recipe')}';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  VIDEO CARD
// ─────────────────────────────────────────────────────────────────────────────
class _VideoCard extends StatefulWidget {
  final _VideoEntry entry;
  final String durationLabel;
  final String viewsLabel;
  final VoidCallback onTap;

  const _VideoCard({
    required this.entry,
    required this.durationLabel,
    required this.viewsLabel,
    required this.onTap,
  });

  @override
  State<_VideoCard> createState() => _VideoCardState();
}

class _VideoCardState extends State<_VideoCard> {
  bool _isFav = false;

  @override
  void initState() {
    super.initState();
    _checkFav();
  }

  Future<void> _checkFav() async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    if (mounted) {
      setState(() {
        _isFav = favorites.any((fav) =>
            fav.split('\n').isNotEmpty &&
            fav.split('\n')[0] == widget.entry.meal.name);
      });
    }
  }

  Future<void> _toggleFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    final recipeText =
        '${widget.entry.meal.name}\n\n${widget.entry.meal.instructions}';

    if (_isFav) {
      favorites.removeWhere((fav) =>
          fav.split('\n').isNotEmpty &&
          fav.split('\n')[0] == widget.entry.meal.name);
      setState(() => _isFav = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${widget.entry.meal.name} removed from Cookbook'),
          backgroundColor: Colors.red,
          duration: const Duration(seconds: 2),
        ),
      );
    } else {
      if (!favorites.any((fav) =>
          fav.split('\n').isNotEmpty &&
          fav.split('\n')[0] == widget.entry.meal.name)) {
        favorites.add(recipeText);
        setState(() => _isFav = true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${widget.entry.meal.name} added to Cookbook ❤️'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }

    await prefs.setStringList('favorites', favorites);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.06),
                blurRadius: 8,
                offset: const Offset(0, 2)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Thumbnail
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(14)),
                  child: AspectRatio(
                    aspectRatio: 16 / 9,
                    child: widget.entry.thumbnailUrl.isNotEmpty
                        ? Image.network(
                            widget.entry.thumbnailUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _ThumbnailPlaceholder(
                                    name: widget.entry.meal.name),
                          )
                        : _ThumbnailPlaceholder(name: widget.entry.meal.name),
                  ),
                ),
                // Play overlay
                Positioned.fill(
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.55),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.play_arrow,
                          color: Colors.white, size: 30),
                    ),
                  ),
                ),
                // Duration badge
                if (widget.durationLabel.isNotEmpty)
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.75),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(widget.durationLabel,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                // Category badge
                Positioned(
                  top: 8,
                  left: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      widget.entry.meal.category,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                // Heart button
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: _toggleFavorite,
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      child: Container(
                        key: ValueKey(_isFav),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.6),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isFav ? Icons.favorite : Icons.favorite_border,
                          color: _isFav ? Colors.red : Colors.white,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),

            // Info row
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: Colors.orange.shade50,
                    child: Text(
                      _categoryEmoji(widget.entry.meal.category),
                      style: const TextStyle(fontSize: 16),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.entry.meal.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                              height: 1.3),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            if (widget.entry.ytAuthor != null) ...[
                              Text(
                                widget.entry.ytAuthor!,
                                style: TextStyle(
                                    fontSize: 11, color: Colors.grey[600]),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(width: 6),
                              Text('•',
                                  style: TextStyle(
                                      color: Colors.grey[400], fontSize: 11)),
                              const SizedBox(width: 6),
                            ],
                            if (widget.viewsLabel.isNotEmpty)
                              Text(
                                widget.viewsLabel,
                                style: TextStyle(
                                    fontSize: 11, color: Colors.grey[600]),
                              ),
                          ],
                        ),
                        if (widget.entry.meal.area.isNotEmpty &&
                            widget.entry.meal.area != 'Unknown') ...[
                          const SizedBox(height: 2),
                          Text(
                            '🌍 ${widget.entry.meal.area} cuisine',
                            style: TextStyle(
                                fontSize: 11, color: Colors.grey[500]),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Watch on YouTube button
            InkWell(
              onTap: () => launchUrl(
                Uri.parse(widget.entry.youtubeUrl),
                mode: LaunchMode.externalApplication,
              ),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.red.shade600,
                  borderRadius: const BorderRadius.vertical(
                      bottom: Radius.circular(14)),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.play_circle_fill, color: Colors.white, size: 16),
                    SizedBox(width: 6),
                    Text('Watch on YouTube',
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _categoryEmoji(String cat) {
    switch (cat.toLowerCase()) {
      case 'beef': return '🥩';
      case 'chicken': return '🍗';
      case 'seafood': return '🐟';
      case 'vegetarian': return '🥗';
      case 'dessert': return '🍰';
      case 'pasta': return '🍝';
      case 'breakfast': return '🍳';
      case 'lamb': return '🍖';
      case 'pork': return '🥓';
      case 'vegan': return '🌱';
      case 'side': return '🥙';
      case 'starter': return '🥣';
      case 'goat': return '🐐';
      case 'miscellaneous': return '🍽️';
      default: return '👨‍🍳';
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  VIDEO DETAIL SCREEN  (YouTube-only, no in-app player)
// ─────────────────────────────────────────────────────────────────────────────
class _VideoDetailScreen extends StatefulWidget {
  final _VideoEntry entry;
  final List<_VideoEntry> allEntries;

  const _VideoDetailScreen({
    required this.entry,
    required this.allEntries,
  });

  @override
  State<_VideoDetailScreen> createState() => _VideoDetailScreenState();
}

class _VideoDetailScreenState extends State<_VideoDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  late List<_VideoEntry> _related;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
    _related = widget.allEntries
        .where((e) =>
            e.meal.category == widget.entry.meal.category &&
            e.meal.id != widget.entry.meal.id)
        .take(10)
        .toList();

    // Auto-open YouTube when screen loads
    WidgetsBinding.instance.addPostFrameCallback((_) {
      launchUrl(
        Uri.parse(widget.entry.youtubeUrl),
        mode: LaunchMode.externalApplication,
      );
    });
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final meal = widget.entry.meal;

    return CheffyScaffold(
      currentPage: 'Cooking Videos',
      child: Scaffold(
        backgroundColor: const Color(0xFFF8F8F8),
        body: SafeArea(
          child: Column(
            children: [
              // Thumbnail hero with YouTube button overlay
              AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    widget.entry.thumbnailUrl.isNotEmpty
                        ? Image.network(
                            widget.entry.thumbnailUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _ThumbnailPlaceholder(name: meal.name),
                          )
                        : _ThumbnailPlaceholder(name: meal.name),
                    // Dark overlay
                    Container(color: Colors.black.withValues(alpha: 0.4)),
                    // YouTube button centred
                    Center(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.shade700,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 28, vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30)),
                          elevation: 4,
                        ),
                        icon: const Icon(Icons.play_arrow,
                            size: 24, color: Colors.white),
                        label: const Text('Watch on YouTube',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15)),
                        onPressed: () => launchUrl(
                          Uri.parse(widget.entry.youtubeUrl),
                          mode: LaunchMode.externalApplication,
                        ),
                      ),
                    ),
                    // Back button
                    Positioned(
                      top: 10,
                      left: 10,
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: Colors.black54,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Icon(Icons.arrow_back,
                              color: Colors.white, size: 20),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Content below thumbnail
              Expanded(
                child: Container(
                  color: const Color(0xFFF8F8F8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title + meta chips
                      Padding(
                        padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              meal.name,
                              style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                  height: 1.3),
                            ),
                            const SizedBox(height: 6),
                            Row(children: [
                              _MetaChip(
                                  icon: Icons.restaurant_menu,
                                  label: meal.category),
                              const SizedBox(width: 6),
                              if (meal.area.isNotEmpty &&
                                  meal.area != 'Unknown')
                                _MetaChip(
                                    icon: Icons.public, label: meal.area),
                              const SizedBox(width: 6),
                              if (widget.entry.ytAuthor != null)
                                _MetaChip(
                                    icon: Icons.person_outline,
                                    label: widget.entry.ytAuthor!),
                            ]),
                          ],
                        ),
                      ),

                      // Tabs
                      TabBar(
                        controller: _tabCtrl,
                        labelColor: Colors.orange,
                        unselectedLabelColor: Colors.grey,
                        indicatorColor: Colors.orange,
                        tabs: [
                          Tab(text:
                              'Ingredients (${meal.ingredients.length})'),
                          Tab(text: 'Related (${_related.length})'),
                        ],
                      ),

                      Expanded(
                        child: TabBarView(
                          controller: _tabCtrl,
                          children: [
                            // Ingredients tab
                            ListView(
                              padding: const EdgeInsets.all(14),
                              children: [
                                if (meal.instructions.isNotEmpty) ...[
                                  const Text('Instructions',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14)),
                                  const SizedBox(height: 8),
                                  Text(
                                    meal.instructions,
                                    style: TextStyle(
                                        fontSize: 13,
                                        color: Colors.grey[700],
                                        height: 1.6),
                                    maxLines: 8,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 14),
                                ],
                                const Text('Ingredients',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14)),
                                const SizedBox(height: 8),
                                ...List.generate(meal.ingredients.length,
                                    (i) {
                                  final measure = i < meal.measures.length
                                      ? meal.measures[i]
                                      : '';
                                  return Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 8),
                                    child: Row(children: [
                                      Container(
                                        width: 8,
                                        height: 8,
                                        decoration: const BoxDecoration(
                                            color: Colors.orange,
                                            shape: BoxShape.circle),
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                          child: Text(meal.ingredients[i],
                                              style: const TextStyle(
                                                  fontSize: 13))),
                                      if (measure.isNotEmpty)
                                        Text(measure,
                                            style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.grey[600],
                                                fontWeight:
                                                    FontWeight.w500)),
                                    ]),
                                  );
                                }),
                              ],
                            ),

                            // Related tab
                            _related.isEmpty
                                ? const Center(
                                    child: Text('No related videos',
                                        style:
                                            TextStyle(color: Colors.grey)))
                                : ListView.builder(
                                    padding: const EdgeInsets.all(12),
                                    itemCount: _related.length,
                                    itemBuilder: (ctx, i) {
                                      final rel = _related[i];
                                      return _RelatedCard(
                                        entry: rel,
                                        onTap: () =>
                                            Navigator.pushReplacement(
                                          ctx,
                                          MaterialPageRoute(
                                            builder: (_) =>
                                                _VideoDetailScreen(
                                              entry: rel,
                                              allEntries: widget.allEntries,
                                            ),
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  RELATED VIDEO CARD
// ─────────────────────────────────────────────────────────────────────────────
class _RelatedCard extends StatelessWidget {
  final _VideoEntry entry;
  final VoidCallback onTap;
  const _RelatedCard({required this.entry, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withValues(alpha: 0.05), blurRadius: 6)
          ],
        ),
        child: Row(children: [
          ClipRRect(
            borderRadius:
                const BorderRadius.horizontal(left: Radius.circular(10)),
            child: Stack(children: [
              entry.thumbnailUrl.isNotEmpty
                  ? Image.network(
                      entry.thumbnailUrl,
                      width: 100,
                      height: 68,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _ThumbnailPlaceholder(
                          name: entry.meal.name, small: true),
                    )
                  : _ThumbnailPlaceholder(name: entry.meal.name, small: true),
              Positioned.fill(
                child: Center(
                  child: Icon(Icons.play_circle_fill,
                      color: Colors.white.withValues(alpha: 0.8), size: 26),
                ),
              ),
            ]),
          ),
          Expanded(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.meal.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 12),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 3),
                  Text(
                    entry.meal.area.isNotEmpty &&
                            entry.meal.area != 'Unknown'
                        ? entry.meal.area
                        : entry.meal.category,
                    style:
                        TextStyle(fontSize: 11, color: Colors.grey[600]),
                  ),
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SMALL HELPERS
// ─────────────────────────────────────────────────────────────────────────────
class _ThumbnailPlaceholder extends StatelessWidget {
  final String name;
  final bool small;
  const _ThumbnailPlaceholder({required this.name, this.small = false});

  @override
  Widget build(BuildContext context) => Container(
        color: Colors.orange.shade100,
        width: small ? 100 : double.infinity,
        height: small ? 68 : double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.restaurant_menu,
                color: Colors.orange, size: small ? 20 : 34),
            if (!small) ...[
              const SizedBox(height: 6),
              Text(
                name,
                style: const TextStyle(
                    color: Colors.orange,
                    fontSize: 12,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
                maxLines: 2,
              ),
            ]
          ],
        ),
      );
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _MetaChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: Colors.orange.shade50,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.orange.shade100),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 11, color: Colors.orange),
          const SizedBox(width: 4),
          Text(label,
              style: TextStyle(
                  fontSize: 11, color: Colors.orange.shade800)),
        ]),
      );
}

class _LoadingShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) => ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: 4,
        itemBuilder: (_, __) => Container(
          margin: const EdgeInsets.only(bottom: 14),
          height: 240,
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      );
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child:
              Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, color: Colors.grey, size: 48),
            const SizedBox(height: 12),
            Text(message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange),
              icon: const Icon(Icons.refresh,
                  color: Colors.white, size: 16),
              label: const Text('Retry',
                  style: TextStyle(color: Colors.white)),
              onPressed: onRetry,
            ),
          ]),
        ),
      );
}