import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/common_ui.dart';
import '../models/meal_model.dart';
import '../services/recipe_service.dart';
import 'meal_detail_screen.dart';
import 'cooking_videos_screen.dart';

class RecipeSearchScreen extends StatefulWidget {
  const RecipeSearchScreen({super.key});

  @override
  State<RecipeSearchScreen> createState() => _RecipeSearchScreenState();
}

class _RecipeSearchScreenState extends State<RecipeSearchScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _searchCtrl = TextEditingController();
  final _recipeService = RecipeService();

  List<MealModel> _allRecipes = [];
  List<MealModel> _results = [];
  List<MealModel> _filtered = [];
  List<String> _categories = ['All'];
  String _selectedCategory = 'All';
  String _sortOption = 'A–Z';
  bool _isLoading = false;
  bool _hasSearched = false;
  String? _errorMsg;

  final List<String> _sortOptions = ['A–Z', 'Z–A'];

  @override
  void initState() {
    super.initState();
    _loadAllRecipes();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAllRecipes() async {
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });

    try {
      final meals = await _recipeService.getAllRecipes();
      final cats = meals
          .map((m) => m.category)
          .where((c) => c.isNotEmpty)
          .toSet()
          .toList()
        ..sort();

      setState(() {
        _allRecipes = meals;
        _results = meals;
        _categories = ['All', ...cats];
        _hasSearched = true;
        _applyFiltersAndSort();
      });
    } catch (e) {
      setState(() {
        _errorMsg = e.toString().replaceAll('Exception: ', '');
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _searchLocally(String query) {
    setState(() {
      _hasSearched = true;
      if (query.trim().isEmpty) {
        _results = _allRecipes;
      } else {
        final q = query.toLowerCase();
        _results = _allRecipes.where((m) =>
          m.name.toLowerCase().contains(q) ||
          m.category.toLowerCase().contains(q) ||
          m.area.toLowerCase().contains(q) ||
          m.ingredients.any((i) => i.toLowerCase().contains(q))
        ).toList();
      }
      _applyFiltersAndSort();
    });
  }

  void _applyFiltersAndSort() {
    List<MealModel> filtered = List.from(_results);

    if (_selectedCategory != 'All') {
      filtered = filtered
          .where((m) =>
              m.category.toLowerCase() == _selectedCategory.toLowerCase())
          .toList();
    }

    if (_sortOption == 'A–Z') {
      filtered.sort((a, b) => a.name.compareTo(b.name));
    } else {
      filtered.sort((a, b) => b.name.compareTo(a.name));
    }

    _filtered = filtered;
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return CheffyScaffold(
      currentPage: 'Recipe Search',
      child: Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      body: Column(
        children: [
          buildHeader(
            context: context,
            scaffoldKey: _scaffoldKey,
            screenWidth: screenWidth,
          ),

          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search recipes (e.g. pasta, chicken…)',
                prefixIcon: const Icon(Icons.search, color: Colors.orange),
                suffixIcon: _searchCtrl.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() {
                            _results = _allRecipes;
                            _hasSearched = true;
                            _applyFiltersAndSort();
                          });
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
              onSubmitted: _searchLocally,
              onChanged: (v) {
                setState(() {});
                _searchLocally(v);
              },
              textInputAction: TextInputAction.search,
            ),
          ),

          // Filters row
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 36,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _categories.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 6),
                      itemBuilder: (context, i) {
                        final cat = _categories[i];
                        final selected = cat == _selectedCategory;
                        return FilterChip(
                          label: Text(cat,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: selected
                                      ? Colors.white
                                      : Colors.black87)),
                          selected: selected,
                          selectedColor: Colors.orange,
                          backgroundColor: Colors.grey.shade200,
                          onSelected: (_) {
                            setState(() {
                              _selectedCategory = cat;
                              _applyFiltersAndSort();
                            });
                          },
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          showCheckmark: false,
                        );
                      },
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: _sortOption,
                  underline: const SizedBox(),
                  icon: const Icon(Icons.sort, color: Colors.orange),
                  items: _sortOptions
                      .map((s) => DropdownMenuItem(
                            value: s,
                            child: Text(s,
                                style: const TextStyle(fontSize: 13)),
                          ))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) {
                      setState(() {
                        _sortOption = v;
                        _applyFiltersAndSort();
                      });
                    }
                  },
                ),
              ],
            ),
          ),

          // Results count
          if (_hasSearched && !_isLoading)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  '${_filtered.length} recipe${_filtered.length == 1 ? '' : 's'} found',
                  style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                ),
              ),
            ),

          Expanded(child: _buildBody()),
          buildFooter(),
        ],
      ),
    ));
  }

  Widget _buildBody() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: Colors.orange),
            const SizedBox(height: 16),
            Text(
              'Loading recipes from all sources…',
              style: TextStyle(color: Colors.grey[600], fontSize: 13),
            ),
          ],
        ),
      );
    }

    if (_errorMsg != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.wifi_off, size: 56, color: Colors.grey[400]),
            const SizedBox(height: 12),
            Text(
              _errorMsg!,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[600]),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loadAllRecipes,
              icon: const Icon(Icons.refresh),
              label: const Text('Retry'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white),
            ),
          ],
        ),
      );
    }

    if (_filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🔍', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text(
              _hasSearched
                  ? 'No recipes found. Try a different search.'
                  : 'Loading recipes…',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 220,
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.8,
      ),
      itemCount: _filtered.length,
      itemBuilder: (context, index) => _MealCard(
        meal: _filtered[index],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => MealDetailScreen(meal: _filtered[index]),
          ),
        ),
      ),
    );
  }
}

class _MealCard extends StatelessWidget {
  final MealModel meal;
  final VoidCallback onTap;

  const _MealCard({required this.meal, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        elevation: 3,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // Thumbnail
                  meal.thumbnail.isNotEmpty
                      ? Image.network(
                          meal.thumbnail,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          errorBuilder: (_, __, ___) => Container(
                            color: Colors.orange.shade50,
                            child: const Center(
                              child: Text('🍽️', style: TextStyle(fontSize: 40)),
                            ),
                          ),
                        )
                      : Container(
                          color: Colors.orange.shade50,
                          child: const Center(
                            child: Text('🍽️', style: TextStyle(fontSize: 40)),
                          ),
                        ),

                  // Video button — top-right corner
                  Positioned(
                    top: 6,
                    right: 6,
                    child: GestureDetector(
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) =>
                              CookingVideosScreen(initialMeal: meal),
                        ),
                      ),
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.red.shade700,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.play_circle_fill,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    meal.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 13),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          meal.category,
                          style: TextStyle(
                              fontSize: 11, color: Colors.orange[700]),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (meal.area.isNotEmpty)
                        Text(
                          meal.area,
                          style: TextStyle(
                              fontSize: 10, color: Colors.grey[500]),
                          overflow: TextOverflow.ellipsis,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}