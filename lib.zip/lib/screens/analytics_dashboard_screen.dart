import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../widgets/common_ui.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  ANALYTICS DASHBOARD — fully dynamic, real data only
// ─────────────────────────────────────────────────────────────────────────────
class AnalyticsDashboardScreen extends StatefulWidget {
  const AnalyticsDashboardScreen({super.key});

  @override
  State<AnalyticsDashboardScreen> createState() =>
      _AnalyticsDashboardScreenState();
}

class _AnalyticsDashboardScreenState
    extends State<AnalyticsDashboardScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // ── Real stats ──────────────────────────────────────────────────────────
  int _totalFavorites = 0;
  int _totalScans = 0;
  int _rewardPoints = 0;
  int _cookingSessionsCompleted = 0;

  // ── Real chart data ─────────────────────────────────────────────────────
  /// category name → recipe count (from Firestore favorites sub-collection)
  Map<String, int> _categoryCount = {};

  /// 7 FlSpots — one per day Mon–Sun, y = actual recipes cooked that day
  /// pulled from Firestore cooking_sessions collection (date field)
  List<FlSpot> _weeklyActivity = List.generate(
    7,
    (i) => FlSpot(i.toDouble(), 0),
  );

  // ── Touch state ──────────────────────────────────────────────────────────
  int _touchedLineIndex = -1;
  int _touchedPieIndex  = -1;
  int _touchedBarIndex  = -1;

  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  // ── DATA LOADING ─────────────────────────────────────────────────────────

  Future<void> _loadStats() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final uid = FirebaseAuth.instance.currentUser?.uid;
      if (uid == null) {
        setState(() {
          _errorMessage = 'Not logged in. Please restart the app.';
          _isLoading = false;
        });
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final db    = FirebaseFirestore.instance;
      final userRef = db.collection('users').doc(uid);

      // ── 1. SAVED RECIPES (favorites) ─────────────────────────────────
      // Stored as a sub-collection: users/{uid}/favorites/{recipeId}
      // Each doc has at minimum a 'category' field.
      final favSnap = await userRef.collection('favorites').get();
      final totalFavorites = favSnap.docs.length;

      // Build category counts from real data
      final Map<String, int> catCount = {};
      for (final doc in favSnap.docs) {
        final cat = (doc.data()['category'] as String?)?.trim();
        final key = (cat != null && cat.isNotEmpty) ? cat : 'Uncategorised';
        catCount[key] = (catCount[key] ?? 0) + 1;
      }

      // ── 2. QR SCAN HISTORY ────────────────────────────────────────────
      // Stored in SharedPreferences as a list of strings (one entry per scan)
      final scans = prefs.getStringList('qr_history') ?? [];

      // ── 3. REWARD POINTS ──────────────────────────────────────────────
      // Stored in Firestore: users/{uid}.points  (falls back to prefs)
      final userSnap = await userRef.get();
      int points = 0;
      if (userSnap.exists) {
        points = (userSnap.data()?['points'] as num?)?.toInt() ?? 0;
      }
      if (points == 0) {
        points = prefs.getInt('userPoints') ?? 0;
      }

      // ── 4. COOKING SESSIONS — total count ─────────────────────────────
      // Stored in Firestore: users/{uid}/cooking_sessions/{sessionId}
      // Each doc has a 'completedAt' Timestamp field.
      final sessionsSnap =
          await userRef.collection('cooking_sessions').get();
      final totalSessions = sessionsSnap.docs.length;

      // ── 5. WEEKLY ACTIVITY — real day-by-day breakdown ─────────────────
      // Count sessions per weekday (Mon=0 … Sun=6) for the current week.
      final now = DateTime.now();
      // Start of current week (Monday)
      final weekStart =
          now.subtract(Duration(days: now.weekday - 1));
      final weekStartDay =
          DateTime(weekStart.year, weekStart.month, weekStart.day);

      final Map<int, int> dayCounts = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0};

      for (final doc in sessionsSnap.docs) {
        final ts = doc.data()['completedAt'];
        if (ts == null) continue;

        DateTime dt;
        if (ts is Timestamp) {
          dt = ts.toDate();
        } else {
          continue;
        }

        final sessionDay = DateTime(dt.year, dt.month, dt.day);
        final diff = sessionDay.difference(weekStartDay).inDays;
        if (diff >= 0 && diff < 7) {
          dayCounts[diff] = (dayCounts[diff] ?? 0) + 1;
        }
      }

      final weeklyActivity = List.generate(
        7,
        (i) => FlSpot(i.toDouble(), (dayCounts[i] ?? 0).toDouble()),
      );

      // ── COMMIT STATE ──────────────────────────────────────────────────
      if (!mounted) return;
      setState(() {
        _totalFavorites           = totalFavorites;
        _totalScans               = scans.length;
        _rewardPoints             = points;
        _cookingSessionsCompleted = totalSessions;
        _categoryCount            = catCount;
        _weeklyActivity           = weeklyActivity;
        _isLoading                = false;
      });
    } catch (e) {
      debugPrint('[Analytics] Load error: $e');
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Failed to load analytics. Pull down to retry.';
        _isLoading    = false;
      });
    }
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return CheffyScaffold(
      currentPage: 'Analytics',
      child: Scaffold(
        key: _scaffoldKey,
        drawer: buildDrawer(context),
        body: Column(
          children: [
            buildHeader(
              context: context,
              scaffoldKey: _scaffoldKey,
              screenWidth: screenWidth,
            ),

            Expanded(
              child: _isLoading
                  ? const Center(
                      child: CircularProgressIndicator(color: Colors.orange))
                  : RefreshIndicator(
                      onRefresh: _loadStats,
                      color: Colors.orange,
                      child: SingleChildScrollView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              '📊 My Cooking Analytics',
                              style: TextStyle(
                                  fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Pull to refresh  •  Your real cooking stats',
                              style: TextStyle(
                                  color: Colors.grey[500], fontSize: 12),
                            ),

                            // Error banner
                            if (_errorMessage != null) ...[
                              const SizedBox(height: 12),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.red.shade50,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                      color: Colors.red.shade200),
                                ),
                                child: Text(
                                  _errorMessage!,
                                  style: TextStyle(
                                      color: Colors.red.shade700,
                                      fontSize: 13),
                                ),
                              ),
                            ],

                            const SizedBox(height: 20),

                            // ── STAT CARDS ───────────────────────────────
                            GridView.count(
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              crossAxisCount: 2,
                              mainAxisSpacing: 12,
                              crossAxisSpacing: 12,
                              childAspectRatio: 1.5,
                              children: [
                                _StatCard(
                                  emoji: '❤️',
                                  label: 'Saved Recipes',
                                  value: '$_totalFavorites',
                                  color: Colors.red.shade100,
                                ),
                                _StatCard(
                                  emoji: '🔍',
                                  label: 'QR Scans',
                                  value: '$_totalScans',
                                  color: Colors.blue.shade100,
                                ),
                                _StatCard(
                                  emoji: '🎁',
                                  label: 'Reward Points',
                                  value: '$_rewardPoints',
                                  color: Colors.orange.shade100,
                                ),
                                _StatCard(
                                  emoji: '🍳',
                                  label: 'Cook Sessions',
                                  value: '$_cookingSessionsCompleted',
                                  color: Colors.green.shade100,
                                ),
                              ],
                            ),

                            const SizedBox(height: 24),

                            // ── WEEKLY ACTIVITY LINE CHART ────────────────
                            _chartCard(
                              title: '📅 This Week\'s Cooking Activity',
                              subtitle: 'Sessions completed per day',
                              child: _weeklyActivity
                                      .every((s) => s.y == 0)
                                  ? _emptyState(
                                      'No cooking sessions recorded\nthis week yet.')
                                  : SizedBox(
                                      height: 180,
                                      child: LineChart(
                                        LineChartData(
                                          lineTouchData: LineTouchData(
                                            enabled: true,
                                            touchCallback:
                                                (event, response) {
                                              setState(() {
                                                _touchedLineIndex = (response
                                                            ?.lineBarSpots
                                                            ?.isNotEmpty ==
                                                        true)
                                                    ? response!
                                                        .lineBarSpots!
                                                        .first
                                                        .spotIndex
                                                    : -1;
                                              });
                                            },
                                            touchTooltipData:
                                                LineTouchTooltipData(
                                              getTooltipColor: (_) =>
                                                  Colors.orange.shade700,
                                              getTooltipItems: (spots) =>
                                                  spots.map((s) {
                                                const days = [
                                                  'Mon', 'Tue', 'Wed',
                                                  'Thu', 'Fri', 'Sat',
                                                  'Sun'
                                                ];
                                                final d =
                                                    s.x.toInt() >= 0 &&
                                                            s.x.toInt() <
                                                                7
                                                        ? days[s.x.toInt()]
                                                        : '';
                                                return LineTooltipItem(
                                                  '$d\n${s.y.toInt()} sessions',
                                                  const TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 11,
                                                      fontWeight:
                                                          FontWeight.bold),
                                                );
                                              }).toList(),
                                            ),
                                          ),
                                          gridData: FlGridData(
                                            show: true,
                                            drawVerticalLine: false,
                                            getDrawingHorizontalLine: (v) =>
                                                FlLine(
                                              color: Colors.grey.shade200,
                                              strokeWidth: 1,
                                            ),
                                          ),
                                          titlesData: FlTitlesData(
                                            leftTitles: AxisTitles(
                                              sideTitles: SideTitles(
                                                showTitles: true,
                                                reservedSize: 28,
                                                interval: 1,
                                                getTitlesWidget: (v, _) =>
                                                    Text(
                                                  '${v.toInt()}',
                                                  style: const TextStyle(
                                                      fontSize: 10,
                                                      color: Colors.grey),
                                                ),
                                              ),
                                            ),
                                            bottomTitles: AxisTitles(
                                              sideTitles: SideTitles(
                                                showTitles: true,
                                                getTitlesWidget: (v, _) {
                                                  const days = [
                                                    'Mo', 'Tu', 'We',
                                                    'Th', 'Fr', 'Sa',
                                                    'Su'
                                                  ];
                                                  final i = v.toInt();
                                                  if (i < 0 ||
                                                      i >= days.length) {
                                                    return const SizedBox
                                                        .shrink();
                                                  }
                                                  return Text(
                                                    days[i],
                                                    style: TextStyle(
                                                      fontSize: 10,
                                                      fontWeight: i ==
                                                              _touchedLineIndex
                                                          ? FontWeight.bold
                                                          : FontWeight
                                                              .normal,
                                                      color: i ==
                                                              _touchedLineIndex
                                                          ? Colors.orange
                                                          : Colors.grey,
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                            topTitles: const AxisTitles(
                                                sideTitles: SideTitles(
                                                    showTitles: false)),
                                            rightTitles: const AxisTitles(
                                                sideTitles: SideTitles(
                                                    showTitles: false)),
                                          ),
                                          borderData:
                                              FlBorderData(show: false),
                                          lineBarsData: [
                                            LineChartBarData(
                                              spots: _weeklyActivity,
                                              isCurved: true,
                                              color: Colors.orange,
                                              barWidth: 3,
                                              belowBarData: BarAreaData(
                                                show: true,
                                                color: Colors.orange
                                                    .withValues(alpha: 0.15),
                                              ),
                                              dotData: FlDotData(
                                                getDotPainter:
                                                    (spot, _, __, ___) {
                                                  final touched =
                                                      spot.x.toInt() ==
                                                          _touchedLineIndex;
                                                  return FlDotCirclePainter(
                                                    radius: touched ? 7 : 4,
                                                    color: touched
                                                        ? Colors
                                                            .orange.shade800
                                                        : Colors.orange,
                                                    strokeColor:
                                                        Colors.white,
                                                    strokeWidth: 2,
                                                  );
                                                },
                                              ),
                                            ),
                                          ],
                                          minX: 0,
                                          maxX: 6,
                                          minY: 0,
                                        ),
                                      ),
                                    ),
                            ),

                            const SizedBox(height: 16),

                            // ── CATEGORY PIE CHART ────────────────────────
                            _chartCard(
                              title: '🥘 Recipe Categories',
                              subtitle:
                                  'Distribution of your saved recipes',
                              child: _categoryCount.isEmpty
                                  ? _emptyState(
                                      'No saved recipes yet.\nSave some recipes to see your categories.')
                                  : SizedBox(
                                      height: 220,
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 3,
                                            child: PieChart(
                                              PieChartData(
                                                pieTouchData: PieTouchData(
                                                  touchCallback:
                                                      (event, response) {
                                                    setState(() {
                                                      _touchedPieIndex = response
                                                                  ?.touchedSection
                                                                  ?.touchedSectionIndex ??
                                                              -1;
                                                    });
                                                  },
                                                ),
                                                sections:
                                                    _buildPieSections(),
                                                sectionsSpace: 3,
                                                centerSpaceRadius: 36,
                                                startDegreeOffset: -90,
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: _buildLegend(),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                            ),

                            const SizedBox(height: 16),

                            // ── REWARD PROGRESS ───────────────────────────
                            _chartCard(
                              title: '🏆 Reward Progress',
                              subtitle:
                                  '$_rewardPoints / 500 pts to Mystery Box',
                              child: Column(
                                children: [
                                  const SizedBox(height: 8),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: LinearProgressIndicator(
                                      value: (_rewardPoints % 500) / 500,
                                      minHeight: 16,
                                      backgroundColor:
                                          Colors.grey.shade200,
                                      valueColor:
                                          const AlwaysStoppedAnimation(
                                              Colors.orange),
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      _rewardMilestone('🥄', '100', 100),
                                      _rewardMilestone('📖', '250', 250),
                                      _rewardMilestone('🎁', '500', 500),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 16),

                            // ── BAR CHART — category breakdown ────────────
                            if (_categoryCount.isNotEmpty)
                              _chartCard(
                                title: '📈 Category Breakdown',
                                subtitle:
                                    'Saved recipes per category',
                                child: SizedBox(
                                  height: 200,
                                  child: BarChart(
                                    BarChartData(
                                      alignment:
                                          BarChartAlignment.spaceAround,
                                      barTouchData: BarTouchData(
                                        enabled: true,
                                        touchCallback: (event, response) {
                                          setState(() {
                                            _touchedBarIndex = response
                                                    ?.spot
                                                    ?.touchedBarGroupIndex ??
                                                -1;
                                          });
                                        },
                                        touchTooltipData:
                                            BarTouchTooltipData(
                                          getTooltipColor: (_) =>
                                              Colors.orange.shade700,
                                          getTooltipItem:
                                              (group, gi, rod, ri) {
                                            final keys = _categoryCount
                                                .keys
                                                .toList();
                                            final label = gi < keys.length
                                                ? keys[gi]
                                                : '';
                                            return BarTooltipItem(
                                              '$label\n${rod.toY.toInt()} recipes',
                                              const TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 11,
                                                  fontWeight:
                                                      FontWeight.bold),
                                            );
                                          },
                                        ),
                                      ),
                                      titlesData: FlTitlesData(
                                        leftTitles: AxisTitles(
                                          sideTitles: SideTitles(
                                            showTitles: true,
                                            reservedSize: 28,
                                            interval: 1,
                                            getTitlesWidget: (v, _) =>
                                                Text(
                                              '${v.toInt()}',
                                              style: const TextStyle(
                                                  fontSize: 10,
                                                  color: Colors.grey),
                                            ),
                                          ),
                                        ),
                                        bottomTitles: AxisTitles(
                                          sideTitles: SideTitles(
                                            showTitles: true,
                                            getTitlesWidget: (v, _) {
                                              final keys = _categoryCount
                                                  .keys
                                                  .toList();
                                              final i = v.toInt();
                                              if (i < 0 ||
                                                  i >= keys.length) {
                                                return const SizedBox
                                                    .shrink();
                                              }
                                              final label =
                                                  keys[i].length > 6
                                                      ? keys[i]
                                                          .substring(0, 5)
                                                      : keys[i];
                                              return Transform.rotate(
                                                angle: -0.4,
                                                child: Text(
                                                  label,
                                                  style: const TextStyle(
                                                      fontSize: 9,
                                                      color: Colors.grey),
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                        topTitles: const AxisTitles(
                                            sideTitles: SideTitles(
                                                showTitles: false)),
                                        rightTitles: const AxisTitles(
                                            sideTitles: SideTitles(
                                                showTitles: false)),
                                      ),
                                      borderData:
                                          FlBorderData(show: false),
                                      gridData: FlGridData(
                                        drawVerticalLine: false,
                                        getDrawingHorizontalLine: (v) =>
                                            FlLine(
                                          color: Colors.grey.shade200,
                                          strokeWidth: 1,
                                        ),
                                      ),
                                      barGroups: _buildBarGroups(),
                                    ),
                                  ),
                                ),
                              ),

                            const SizedBox(height: 30),
                          ],
                        ),
                      ),
                    ),
            ),

            buildFooter(),
          ],
        ),
      ),
    );
  }

  // ── CHART BUILDERS ────────────────────────────────────────────────────────

  static const _chartColors = [
    Colors.orange,
    Colors.blue,
    Colors.green,
    Colors.red,
    Colors.purple,
    Colors.teal,
  ];

  List<PieChartSectionData> _buildPieSections() {
    final total = _categoryCount.values.fold(0, (a, b) => a + b);
    int i = 0;
    return _categoryCount.entries.map((e) {
      final pct = total > 0 ? (e.value / total * 100) : 0.0;
      final isTouched = i == _touchedPieIndex;
      final color = _chartColors[i % _chartColors.length];
      final section = PieChartSectionData(
        color: color,
        value: e.value.toDouble(),
        title: isTouched ? e.key : '${pct.toStringAsFixed(0)}%',
        radius: isTouched ? 64 : 50,
        titleStyle: TextStyle(
            fontSize: isTouched ? 13 : 11,
            fontWeight: FontWeight.bold,
            color: Colors.white),
        badgeWidget: isTouched
            ? Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black.withValues(alpha: 0.15),
                        blurRadius: 4)
                  ],
                ),
                child: Text(
                  '${e.value}',
                  style: TextStyle(
                      fontSize: 10,
                      color: color,
                      fontWeight: FontWeight.bold),
                ),
              )
            : null,
        badgePositionPercentageOffset: 1.1,
      );
      i++;
      return section;
    }).toList();
  }

  List<Widget> _buildLegend() {
    int i = 0;
    return _categoryCount.entries.map((e) {
      final color = _chartColors[i++ % _chartColors.length];
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration:
                  BoxDecoration(color: color, shape: BoxShape.circle),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(e.key,
                  style: const TextStyle(fontSize: 11),
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      );
    }).toList();
  }

  List<BarChartGroupData> _buildBarGroups() {
    int i = 0;
    return _categoryCount.entries.map((e) {
      final isTouched = i == _touchedBarIndex;
      final color = _chartColors[i % _chartColors.length];
      final group = BarChartGroupData(
        x: i,
        showingTooltipIndicators: isTouched ? [0] : [],
        barRods: [
          BarChartRodData(
            toY: e.value.toDouble(),
            color: isTouched
                ? color
                : color.withValues(alpha: 0.75),
            width: isTouched ? 28 : 22,
            borderRadius: BorderRadius.circular(4),
            backDrawRodData: BackgroundBarChartRodData(
              show: isTouched,
              toY: (e.value * 1.3).ceilToDouble(),
              color: color.withValues(alpha: 0.08),
            ),
          ),
        ],
      );
      i++;
      return group;
    }).toList();
  }

  // ── UI HELPERS ────────────────────────────────────────────────────────────

  Widget _chartCard({
    required String title,
    required String subtitle,
    required Widget child,
  }) {
    return Card(
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 2),
            Text(subtitle,
                style:
                    TextStyle(fontSize: 12, color: Colors.grey[500])),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }

  Widget _emptyState(String message) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Center(
        child: Column(
          children: [
            Icon(Icons.bar_chart_outlined,
                size: 40, color: Colors.grey[300]),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey[400], fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rewardMilestone(
      String emoji, String label, int threshold) {
    final achieved = _rewardPoints >= threshold;
    return Column(
      children: [
        Text(emoji,
            style: TextStyle(
                fontSize: 20,
                color: achieved ? Colors.orange : Colors.grey[300])),
        Text(label,
            style: TextStyle(
                fontSize: 11,
                color:
                    achieved ? Colors.orange : Colors.grey[400])),
      ],
    );
  }
}

// ── STAT CARD ─────────────────────────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final String emoji;
  final String label;
  final String value;
  final Color color;

  const _StatCard({
    required this.emoji,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: color, borderRadius: BorderRadius.circular(14)),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 24)),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value,
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold)),
              Text(label,
                  style: TextStyle(
                      fontSize: 12, color: Colors.grey[700])),
            ],
          ),
        ],
      ),
    );
  }
}