import 'package:flutter/material.dart';
import '../app_secrets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (!AppSecrets.isAdmin(_auth.currentUser?.email)) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!AppSecrets.isAdmin(_auth.currentUser?.email)) {
      return const Scaffold(
        backgroundColor: Color(0xFF0F0F1A),
        body: Center(child: CircularProgressIndicator(color: Colors.orange)),
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFF0F0F1A),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A2E),
        title: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('⚡', style: TextStyle(fontSize: 20)),
            SizedBox(width: 8),
            Flexible(
              child: Text(
                'Cheffy Admin',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            SizedBox(width: 8),
            _AdminBadge(),
          ],
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: Colors.orange,
          labelColor: Colors.orange,
          unselectedLabelColor: Colors.white38,
          tabs: const [
            Tab(icon: Icon(Icons.people), text: 'Users'),
            Tab(icon: Icon(Icons.restaurant_menu), text: 'Recipes'),
            Tab(icon: Icon(Icons.shopping_cart), text: 'Grocery'),
            Tab(icon: Icon(Icons.chat_bubble), text: 'AI Chats'),
            Tab(icon: Icon(Icons.bar_chart), text: 'Analytics'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _UsersTab(db: _db),
          _RecipesTab(db: _db),
          _GroceryTab(db: _db),
          _AiChatsTab(db: _db),
          _AnalyticsTab(db: _db),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  ADMIN BADGE
// ─────────────────────────────────────────────────────────────────────────────
class _AdminBadge extends StatelessWidget {
  const _AdminBadge();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.orange.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.orange.withValues(alpha: 0.5)),
      ),
      child: const Text(
        'ADMIN',
        style: TextStyle(
          color: Colors.orange,
          fontSize: 10,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.5,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SHARED WIDGETS
// ─────────────────────────────────────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 11),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

Widget _sectionHeader(String title) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
    child: Text(
      title,
      style: const TextStyle(
        color: Colors.white,
        fontSize: 16,
        fontWeight: FontWeight.bold,
        letterSpacing: 0.5,
      ),
    ),
  );
}

Widget _emptyState(String msg) {
  return Center(
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('📭', style: TextStyle(fontSize: 48)),
        const SizedBox(height: 12),
        Text(msg, style: const TextStyle(color: Colors.white38, fontSize: 14)),
      ],
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
//  TAB 1 — USERS
// ─────────────────────────────────────────────────────────────────────────────
class _UsersTab extends StatelessWidget {
  final FirebaseFirestore db;
  const _UsersTab({required this.db});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: db
          .collection('users')
          .orderBy('createdAt', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.orange));
        }

        final docs = snap.data?.docs ?? [];

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.6,
                  children: [
                    _StatCard(
                      label: 'Total Users',
                      value: '${docs.length}',
                      icon: Icons.people,
                      color: Colors.blue,
                    ),
                    _StatCard(
                      label: 'Active Today',
                      value: '${docs.where((d) {
                        final data = d.data() as Map<String, dynamic>;
                        final ts = data['lastLogin'] as Timestamp?;
                        if (ts == null) return false;
                        return DateTime.now()
                                .difference(ts.toDate())
                                .inHours < 24;
                      }).length}',
                      icon: Icons.online_prediction,
                      color: Colors.green,
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(child: _sectionHeader('All Users')),
            docs.isEmpty
                ? SliverFillRemaining(child: _emptyState('No users found'))
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final data =
                            docs[i].data() as Map<String, dynamic>;
                        final email = data['email'] ?? 'No email';
                        final name = data['displayName'] ?? 'Unknown';
                        final ts = data['createdAt'] as Timestamp?;
                        final joined = ts != null
                            ? '${ts.toDate().day}/${ts.toDate().month}/${ts.toDate().year}'
                            : 'Unknown';
                        final photoUrl = data['photoUrl'] as String?;

                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A2E),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 20,
                                backgroundColor:
                                    Colors.orange.withValues(alpha: 0.2),
                                backgroundImage: photoUrl != null
                                    ? NetworkImage(photoUrl)
                                    : null,
                                child: photoUrl == null
                                    ? Text(
                                        name.isNotEmpty
                                            ? name[0].toUpperCase()
                                            : '?',
                                        style: const TextStyle(
                                            color: Colors.orange,
                                            fontWeight: FontWeight.bold),
                                      )
                                    : null,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      name,
                                      style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      email,
                                      style: const TextStyle(
                                          color: Colors.white54,
                                          fontSize: 11),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 6),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text('Joined',
                                      style: TextStyle(
                                          color: Colors.white38,
                                          fontSize: 10)),
                                  Text(joined,
                                      style: const TextStyle(
                                          color: Colors.white60,
                                          fontSize: 10)),
                                ],
                              ),
                              PopupMenuButton<String>(
                                color: const Color(0xFF1A1A2E),
                                iconColor: Colors.white38,
                                padding: EdgeInsets.zero,
                                onSelected: (val) async {
                                  if (val == 'delete') {
                                    await db
                                        .collection('users')
                                        .doc(docs[i].id)
                                        .delete();
                                    if (context.mounted) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                            content:
                                                Text('User deleted')),
                                      );
                                    }
                                  }
                                },
                                itemBuilder: (_) => [
                                  const PopupMenuItem(
                                    value: 'delete',
                                    child: Row(
                                      children: [
                                        Icon(Icons.delete,
                                            color: Colors.red, size: 18),
                                        SizedBox(width: 8),
                                        Text('Delete',
                                            style: TextStyle(
                                                color: Colors.red)),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                      childCount: docs.length,
                    ),
                  ),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TAB 2 — RECIPES / FAVORITES
// ─────────────────────────────────────────────────────────────────────────────
class _RecipesTab extends StatelessWidget {
  final FirebaseFirestore db;
  const _RecipesTab({required this.db});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: db
          .collectionGroup('favorites')
          .orderBy('savedAt', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.orange));
        }

        final docs = snap.data?.docs ?? [];

        final Map<String, int> recipeCounts = {};
        for (final d in docs) {
          final data = d.data() as Map<String, dynamic>;
          final title = data['title'] as String? ?? 'Unknown';
          recipeCounts[title] = (recipeCounts[title] ?? 0) + 1;
        }
        final sorted = recipeCounts.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.6,
                  children: [
                    _StatCard(
                      label: 'Total Saved',
                      value: '${docs.length}',
                      icon: Icons.favorite,
                      color: Colors.red,
                    ),
                    _StatCard(
                      label: 'Unique Recipes',
                      value: '${recipeCounts.length}',
                      icon: Icons.restaurant_menu,
                      color: Colors.orange,
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(child: _sectionHeader('Most Saved Recipes')),
            docs.isEmpty
                ? SliverFillRemaining(
                    child: _emptyState('No saved recipes yet'))
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final entry = sorted[i];
                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A2E),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 32,
                                height: 32,
                                decoration: BoxDecoration(
                                  color: Colors.orange.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: Text(
                                    '${i + 1}',
                                    style: const TextStyle(
                                      color: Colors.orange,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 13,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  entry.key,
                                  style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 13),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.red.withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Icon(Icons.favorite,
                                        color: Colors.red, size: 11),
                                    const SizedBox(width: 4),
                                    Text(
                                      '${entry.value}',
                                      style: const TextStyle(
                                          color: Colors.red,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 12),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                      childCount: sorted.length,
                    ),
                  ),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TAB 3 — GROCERY LISTS
// ─────────────────────────────────────────────────────────────────────────────
class _GroceryTab extends StatelessWidget {
  final FirebaseFirestore db;
  const _GroceryTab({required this.db});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: db
          .collectionGroup('groceryItems')
          .orderBy('addedAt', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.orange));
        }

        final docs = snap.data?.docs ?? [];
        final checkedCount = docs.where((d) {
          final data = d.data() as Map<String, dynamic>;
          return data['checked'] == true;
        }).length;

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.6,
                  children: [
                    _StatCard(
                      label: 'Total Items',
                      value: '${docs.length}',
                      icon: Icons.shopping_cart,
                      color: Colors.green,
                    ),
                    _StatCard(
                      label: 'Checked Off',
                      value: '$checkedCount',
                      icon: Icons.check_circle,
                      color: Colors.teal,
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(child: _sectionHeader('All Grocery Items')),
            docs.isEmpty
                ? SliverFillRemaining(
                    child: _emptyState('No grocery items yet'))
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final data =
                            docs[i].data() as Map<String, dynamic>;
                        final name = data['name'] ?? 'Unknown item';
                        final checked = data['checked'] == true;
                        final qty = data['quantity']?.toString() ?? '';
                        final unit = data['unit'] ?? '';
                        final ts = data['addedAt'] as Timestamp?;
                        final added = ts != null
                            ? '${ts.toDate().day}/${ts.toDate().month}'
                            : '';

                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A2E),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                checked
                                    ? Icons.check_circle
                                    : Icons.radio_button_unchecked,
                                color: checked
                                    ? Colors.teal
                                    : Colors.white38,
                                size: 20,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  name,
                                  style: TextStyle(
                                    color: checked
                                        ? Colors.white38
                                        : Colors.white,
                                    fontSize: 13,
                                    decoration: checked
                                        ? TextDecoration.lineThrough
                                        : null,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (qty.isNotEmpty) ...[
                                const SizedBox(width: 6),
                                Text(
                                  '$qty $unit',
                                  style: const TextStyle(
                                      color: Colors.white54, fontSize: 12),
                                ),
                              ],
                              const SizedBox(width: 6),
                              Text(added,
                                  style: const TextStyle(
                                      color: Colors.white38, fontSize: 11)),
                            ],
                          ),
                        );
                      },
                      childCount: docs.length,
                    ),
                  ),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TAB 4 — AI CHAT LOGS
// ─────────────────────────────────────────────────────────────────────────────
class _AiChatsTab extends StatelessWidget {
  final FirebaseFirestore db;
  const _AiChatsTab({required this.db});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: db
          .collectionGroup('chatMessages')
          .orderBy('timestamp', descending: true)
          .snapshots(),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.orange));
        }

        final docs = snap.data?.docs ?? [];
        final userMessages = docs.where((d) {
          final data = d.data() as Map<String, dynamic>;
          return data['role'] == 'user';
        }).length;

        return CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.6,
                  children: [
                    _StatCard(
                      label: 'Total Messages',
                      value: '${docs.length}',
                      icon: Icons.chat_bubble,
                      color: Colors.purple,
                    ),
                    _StatCard(
                      label: 'User Messages',
                      value: '$userMessages',
                      icon: Icons.person,
                      color: Colors.indigo,
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
                child: _sectionHeader('Recent AI Conversations')),
            docs.isEmpty
                ? SliverFillRemaining(
                    child: _emptyState('No chat logs yet'))
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) {
                        final data =
                            docs[i].data() as Map<String, dynamic>;
                        final role = data['role'] ?? 'unknown';
                        final text =
                            data['content'] ?? data['text'] ?? '';
                        final isUser = role == 'user';
                        final ts = data['timestamp'] as Timestamp?;
                        final time = ts != null
                            ? '${ts.toDate().hour}:${ts.toDate().minute.toString().padLeft(2, '0')} · ${ts.toDate().day}/${ts.toDate().month}'
                            : '';

                        return Container(
                          margin: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A2E),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isUser
                                  ? Colors.purple.withValues(alpha: 0.3)
                                  : Colors.orange.withValues(alpha: 0.3),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Flexible(
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8, vertical: 3),
                                      decoration: BoxDecoration(
                                        color: isUser
                                            ? Colors.purple
                                                .withValues(alpha: 0.2)
                                            : Colors.orange
                                                .withValues(alpha: 0.2),
                                        borderRadius:
                                            BorderRadius.circular(20),
                                      ),
                                      child: Text(
                                        isUser ? '👤 User' : '🤖 AI Chef',
                                        style: TextStyle(
                                          color: isUser
                                              ? Colors.purple
                                              : Colors.orange,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const Spacer(),
                                  Text(time,
                                      style: const TextStyle(
                                          color: Colors.white38,
                                          fontSize: 11)),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                text.length > 120
                                    ? '${text.substring(0, 120)}...'
                                    : text,
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 13),
                              ),
                            ],
                          ),
                        );
                      },
                      childCount: docs.length,
                    ),
                  ),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        );
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TAB 5 — ANALYTICS
// ─────────────────────────────────────────────────────────────────────────────
class _AnalyticsTab extends StatelessWidget {
  final FirebaseFirestore db;
  const _AnalyticsTab({required this.db});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<QuerySnapshot>>(
      future: Future.wait([
        db.collection('users').get(),
        db.collectionGroup('favorites').get(),
        db.collectionGroup('groceryItems').get(),
        db.collectionGroup('chatMessages').get(),
      ]),
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.orange));
        }

        final results = snap.data ?? [];
        final usersCount =
            results.isNotEmpty ? results[0].docs.length : 0;
        final favCount =
            results.length > 1 ? results[1].docs.length : 0;
        final grocCount =
            results.length > 2 ? results[2].docs.length : 0;
        final chatCount =
            results.length > 3 ? results[3].docs.length : 0;

        final now = DateTime.now();
        final newUsersWeek = results.isNotEmpty
            ? results[0].docs.where((d) {
                final data = d.data() as Map<String, dynamic>;
                final ts = data['createdAt'] as Timestamp?;
                if (ts == null) return false;
                return now.difference(ts.toDate()).inDays <= 7;
              }).length
            : 0;

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Overview',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.6,
                children: [
                  _StatCard(
                      label: 'Total Users',
                      value: '$usersCount',
                      icon: Icons.people,
                      color: Colors.blue),
                  _StatCard(
                      label: 'New (7 days)',
                      value: '$newUsersWeek',
                      icon: Icons.person_add,
                      color: Colors.green),
                  _StatCard(
                      label: 'Saved Recipes',
                      value: '$favCount',
                      icon: Icons.favorite,
                      color: Colors.red),
                  _StatCard(
                      label: 'Grocery Items',
                      value: '$grocCount',
                      icon: Icons.shopping_cart,
                      color: Colors.teal),
                  _StatCard(
                      label: 'AI Messages',
                      value: '$chatCount',
                      icon: Icons.smart_toy,
                      color: Colors.purple),
                  _StatCard(
                    label: 'Avg Recipes/User',
                    value: usersCount > 0
                        ? (favCount / usersCount).toStringAsFixed(1)
                        : '0',
                    icon: Icons.analytics,
                    color: Colors.orange,
                  ),
                ],
              ),

              const SizedBox(height: 24),

              const Text(
                'App Activity',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              _ActivityBar(
                  label: 'Users',
                  value: usersCount,
                  max: usersCount > 0 ? usersCount : 1,
                  color: Colors.blue),
              const SizedBox(height: 8),
              _ActivityBar(
                  label: 'Saved Recipes',
                  value: favCount,
                  max: favCount > 0 ? favCount : 1,
                  color: Colors.red),
              const SizedBox(height: 8),
              _ActivityBar(
                  label: 'Grocery Items',
                  value: grocCount,
                  max: grocCount > 0 ? grocCount : 1,
                  color: Colors.green),
              const SizedBox(height: 8),
              _ActivityBar(
                  label: 'AI Messages',
                  value: chatCount,
                  max: chatCount > 0 ? chatCount : 1,
                  color: Colors.purple),

              const SizedBox(height: 30),
            ],
          ),
        );
      },
    );
  }
}

class _ActivityBar extends StatelessWidget {
  final String label;
  final int value;
  final int max;
  final Color color;

  const _ActivityBar({
    required this.label,
    required this.value,
    required this.max,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final ratio = max > 0 ? value / max : 0.0;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(label,
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 13),
                    overflow: TextOverflow.ellipsis),
              ),
              const SizedBox(width: 8),
              Text('$value',
                  style: TextStyle(
                      color: color, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: ratio.clamp(0.0, 1.0),
              backgroundColor: Colors.white12,
              valueColor: AlwaysStoppedAnimation(color),
              minHeight: 6,
            ),
          ),
        ],
      ),
    );
  }
}