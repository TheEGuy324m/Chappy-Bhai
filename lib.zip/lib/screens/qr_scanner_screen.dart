import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/common_ui.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  QR SCANNER + GENERATOR PAGE - RECIPE FOCUSED
// ─────────────────────────────────────────────────────────────────────────────
class QRScannerScreen extends StatefulWidget {
  const QRScannerScreen({super.key});

  @override
  State<QRScannerScreen> createState() => _QRScannerScreenState();
}

class _QRScannerScreenState extends State<QRScannerScreen>
    with SingleTickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late TabController _tabController;

  // Scanner state
  MobileScannerController? _scannerCtrl;
  bool _torchOn = false;
  bool _scannerPaused = false;
  String? _lastScanned;
  List<Map<String, String>> _scanHistory = [];

  // Generator state
  final TextEditingController _recipeNameCtrl = TextEditingController();
  final TextEditingController _recipeContentCtrl = TextEditingController();
  String _generatedQR = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _scannerCtrl = MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
      facing: CameraFacing.back,
    );
    _loadScanHistory();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scannerCtrl?.dispose();
    _recipeNameCtrl.dispose();
    _recipeContentCtrl.dispose();
    super.dispose();
  }

  // ── HELPERS ─────────────────────────────────────────────────────────────────
  String _extractRecipeName(String content) {
    final lines = content.split('\n');
    return lines.isNotEmpty && lines[0].isNotEmpty ? lines[0] : 'Scanned Recipe';
  }

  // ── SCAN HISTORY ────────────────────────────────────────────────────────────
  Future<void> _loadScanHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('qr_scan_history') ?? [];
    setState(() {
      _scanHistory = raw.map((s) {
        final parts = s.split('|||');
        return {
          'text': parts[0],
          'time': parts.length > 1 ? parts[1] : '',
          'name': parts.length > 2 ? parts[2] : 'Scanned Recipe',
        };
      }).toList();
    });
  }

  Future<void> _saveToScanHistory(String recipeContent, String recipeName) async {
    final prefs = await SharedPreferences.getInstance();
    final timestamp = DateTime.now().toIso8601String();
    final entry = '$recipeContent|||$timestamp|||$recipeName';
    final raw = prefs.getStringList('qr_scan_history') ?? [];
    raw.insert(0, entry);
    if (raw.length > 20) raw.removeLast();
    await prefs.setStringList('qr_scan_history', raw);
    await _loadScanHistory();
  }

  // ── COOKBOOK (FAVORITES) ────────────────────────────────────────────────────
  Future<List<String>> _loadCookbook() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('favorites') ?? [];
  }

  Future<void> _addToCookbook(String recipeText) async {
    final prefs = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];
    
    // Check if recipe already exists
    if (!favorites.contains(recipeText)) {
      favorites.add(recipeText);
      await prefs.setStringList('favorites', favorites);
    }
  }

  // ── QR SCANNING ─────────────────────────────────────────────────────────────
  void _onDetect(BarcodeCapture capture) {
    if (_scannerPaused) return;
    final barcode = capture.barcodes.firstOrNull;
    if (barcode == null || barcode.rawValue == null) return;

    final value = barcode.rawValue!;
    if (value == _lastScanned) return;

    setState(() {
      _scannerPaused = true;
      _lastScanned = value;
    });

    _scannerCtrl?.stop();
    _showRecipeScannedDialog(value);
  }

  void _showRecipeScannedDialog(String recipeContent) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => _RecipeScannedDialog(
        recipeContent: recipeContent,
        onSaveToCookbook: () async {
          await _addToCookbook(recipeContent);
          await _saveToScanHistory(recipeContent, _extractRecipeName(recipeContent));

          if (mounted) {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Recipe saved to Cookbook ❤️'),
                backgroundColor: Colors.green,
              ),
            );
            _resumeScanner();
          }
        },
        onShare: () {
          Share.share(recipeContent, subject: 'Recipe QR Code');
          Navigator.pop(context);
          _resumeScanner();
        },
        onDismiss: () {
          Navigator.pop(context);
          _resumeScanner();
        },
      ),
    );
  }

  void _resumeScanner() {
    setState(() {
      _scannerPaused = false;
      _lastScanned = null;
    });
    _scannerCtrl?.start();
  }

  // ── QR GENERATION ───────────────────────────────────────────────────────────
  void _generateQRFromInput() {
    final recipeName = _recipeNameCtrl.text.trim();
    final recipeContent = _recipeContentCtrl.text.trim();

    if (recipeName.isEmpty || recipeContent.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill in recipe name and content'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // Format: "Recipe Name\n\nRecipe Content"
    final qrData = '$recipeName\n\n$recipeContent';

    setState(() => _generatedQR = qrData);
  }

  void _shareRecipeQR() {
    if (_generatedQR.isNotEmpty) {
      Share.share(_generatedQR, subject: 'Recipe QR Code');
    }
  }

  void _saveGeneratedRecipe() {
    if (_generatedQR.isNotEmpty) {
      _addToCookbook(_generatedQR).then((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Recipe added to Cookbook ❤️'),
            backgroundColor: Colors.green,
          ),
        );
      });
    }
  }

  void _clearGeneratorForm() {
    setState(() {
      _recipeNameCtrl.clear();
      _recipeContentCtrl.clear();
      _generatedQR = '';
    });
  }

  // ── BUILD UI ────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      body: Column(
        children: [
          buildHeader(
            context: context,
            scaffoldKey: _scaffoldKey,
            screenWidth: screenWidth,
          ),
          Container(
            color: Colors.orange.shade50,
            child: TabBar(
              controller: _tabController,
              labelColor: Colors.orange,
              unselectedLabelColor: Colors.grey,
              indicatorColor: Colors.orange,
              tabs: const [
                Tab(icon: Icon(Icons.qr_code_scanner), text: 'Scan'),
                Tab(icon: Icon(Icons.qr_code_2), text: 'Generate'),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildScannerTab(),
                _buildGeneratorTab(),
              ],
            ),
          ),
          buildFooter(),
        ],
      ),
    );
  }

  // ── SCANNER TAB ─────────────────────────────────────────────────────────────
  Widget _buildScannerTab() {
    return Column(
      children: [
        // Camera viewport
        Expanded(
          flex: 3,
          child: Stack(
            children: [
              MobileScanner(
                controller: _scannerCtrl!,
                onDetect: _onDetect,
              ),
              // Scanning overlay
              Center(
                child: Container(
                  width: 230,
                  height: 230,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.orange, width: 3),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Center(
                    child: Text(
                      'Point camera at\nRecipe QR Code',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ),
                ),
              ),
              // Torch button
              Positioned(
                top: 12,
                right: 12,
                child: IconButton(
                  onPressed: () {
                    _scannerCtrl?.toggleTorch();
                    setState(() => _torchOn = !_torchOn);
                  },
                  icon: Icon(
                    _torchOn ? Icons.flash_on : Icons.flash_off,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
              // Flip camera
              Positioned(
                top: 12,
                left: 12,
                child: IconButton(
                  onPressed: () => _scannerCtrl?.switchCamera(),
                  icon: const Icon(Icons.flip_camera_ios,
                      color: Colors.white, size: 28),
                ),
              ),
            ],
          ),
        ),

        // Scan history
        Expanded(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Scan History',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Colors.grey[800]),
                    ),
                    if (_scanHistory.isNotEmpty)
                      TextButton(
                        onPressed: () async {
                          final prefs = await SharedPreferences.getInstance();
                          await prefs.remove('qr_scan_history');
                          setState(() => _scanHistory = []);
                        },
                        child: const Text('Clear',
                            style: TextStyle(color: Colors.red, fontSize: 12)),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: _scanHistory.isEmpty
                    ? Center(
                        child: Text('No scans yet',
                            style: TextStyle(color: Colors.grey[400])),
                      )
                    : ListView.builder(
                        itemCount: _scanHistory.length,
                        itemBuilder: (context, i) {
                          final item = _scanHistory[i];
                          final text = item['text'] ?? '';
                          final time = item['time'] ?? '';
                          final name = item['name'] ?? 'Recipe';
                          final dt = time.isNotEmpty
                              ? DateTime.tryParse(time)
                              : null;

                          return ListTile(
                            dense: true,
                            leading: CircleAvatar(
                              radius: 16,
                              backgroundColor: Colors.orange.shade100,
                              child: const Icon(Icons.restaurant,
                                  size: 16, color: Colors.orange),
                            ),
                            title: Text(
                              name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 13),
                            ),
                            subtitle: dt != null
                                ? Text(
                                    '${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}',
                                    style: TextStyle(
                                        fontSize: 11, color: Colors.grey[500]),
                                  )
                                : null,
                            trailing: IconButton(
                              icon: const Icon(Icons.copy,
                                  size: 16, color: Colors.grey),
                              onPressed: () {
                                Clipboard.setData(ClipboardData(text: text));
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                      content: Text('Recipe copied')),
                                );
                              },
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── GENERATOR TAB ───────────────────────────────────────────────────────────
  Widget _buildGeneratorTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Generate Recipe QR Code',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            'Create a shareable QR code from your cookbook',
            style: TextStyle(color: Colors.grey[600], fontSize: 13),
          ),
          const SizedBox(height: 20),

          // Load from cookbook button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _showCookbookSelector,
              icon: const Icon(Icons.favorite, color: Colors.red),
              label: const Text('Select from Cookbook'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.red,
                side: const BorderSide(color: Colors.red),
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),

          const SizedBox(height: 4),
          Center(
            child: Text(
              'OR',
              style: TextStyle(color: Colors.grey[400], fontSize: 12),
            ),
          ),
          const SizedBox(height: 4),

          // Recipe name input
          TextField(
            controller: _recipeNameCtrl,
            decoration: InputDecoration(
              labelText: 'Recipe Name',
              hintText: 'e.g., Spaghetti Carbonara',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
              prefixIcon: const Icon(Icons.restaurant),
              filled: true,
              fillColor: Colors.grey.shade50,
            ),
          ),

          const SizedBox(height: 14),

          // Recipe content input
          TextField(
            controller: _recipeContentCtrl,
            maxLines: 6,
            decoration: InputDecoration(
              labelText: 'Recipe Content',
              hintText: 'Ingredients, instructions, tips…',
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12)),
              filled: true,
              fillColor: Colors.grey.shade50,
            ),
          ),

          const SizedBox(height: 14),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _generateQRFromInput,
              icon: const Icon(Icons.qr_code_2),
              label: const Text('Generate QR Code'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),

          // Display generated QR
          if (_generatedQR.isNotEmpty) ...[
            const SizedBox(height: 28),
            Center(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: QrImageView(
                      data: _generatedQR,
                      version: QrVersions.auto,
                      size: 220,
                      backgroundColor: Colors.white,
                      eyeStyle: const QrEyeStyle(
                        eyeShape: QrEyeShape.square,
                        color: Colors.orange,
                      ),
                      dataModuleStyle: const QrDataModuleStyle(
                        dataModuleShape: QrDataModuleShape.square,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    _recipeNameCtrl.text.isNotEmpty
                        ? 'Scan to view: ${_recipeNameCtrl.text}'
                        : 'Recipe QR Code Generated',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: Colors.black87),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: _generatedQR));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Recipe copied to clipboard')),
                          );
                        },
                        icon: const Icon(Icons.copy,
                            color: Colors.orange, size: 16),
                        label: const Text('Copy',
                            style: TextStyle(color: Colors.orange)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.orange),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton.icon(
                        onPressed: _shareRecipeQR,
                        icon: const Icon(Icons.share, size: 16),
                        label: const Text('Share'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    onPressed: _saveGeneratedRecipe,
                    icon: const Icon(Icons.favorite_border, size: 16),
                    label: const Text('Save to Cookbook'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextButton.icon(
                    onPressed: _clearGeneratorForm,
                    icon: const Icon(Icons.refresh, color: Colors.grey),
                    label: const Text('Create Another',
                        style: TextStyle(color: Colors.grey)),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ── COOKBOOK SELECTOR MODAL ─────────────────────────────────────────────────
  void _showCookbookSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => _CookbookSelectorSheet(
        onRecipeSelected: (name, content) {
          setState(() {
            _recipeNameCtrl.text = name;
            _recipeContentCtrl.text = content;
          });
          Navigator.pop(context);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Loaded: $name'),
              backgroundColor: Colors.green,
            ),
          );
        },
      ),
    );
  }
}

// ── COOKBOOK SELECTOR SHEET ─────────────────────────────────────────────────
class _CookbookSelectorSheet extends StatefulWidget {
  final Function(String name, String content) onRecipeSelected;

  const _CookbookSelectorSheet({required this.onRecipeSelected});

  @override
  State<_CookbookSelectorSheet> createState() => _CookbookSelectorSheetState();
}

class _CookbookSelectorSheetState extends State<_CookbookSelectorSheet> {
  late Future<List<String>> _favoritesFuture;

  @override
  void initState() {
    super.initState();
    _favoritesFuture = _loadFavorites();
  }

  Future<List<String>> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('favorites') ?? [];
  }

  String _extractRecipeName(String recipeText) {
    final lines = recipeText.split('\n');
    return lines.isNotEmpty && lines[0].isNotEmpty ? lines[0] : 'Recipe';
  }

  String _extractRecipeContent(String recipeText) {
    final lines = recipeText.split('\n');
    if (lines.length > 2) {
      return lines.sublist(2).join('\n').trim();
    }
    return lines.length > 1 ? lines[1] : '';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 36),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const Text(
            'Select Recipe from Cookbook',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: FutureBuilder<List<String>>(
              future: _favoritesFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                final favorites = snapshot.data ?? [];

                if (favorites.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.favorite_border,
                            size: 48, color: Colors.grey[300]),
                        const SizedBox(height: 12),
                        Text(
                          'No recipes in Cookbook',
                          style:
                              TextStyle(color: Colors.grey[600], fontSize: 14),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Scan a recipe QR code to save it',
                          style:
                              TextStyle(color: Colors.grey[400], fontSize: 12),
                        ),
                      ],
                    ),
                  );
                }

                return ListView.builder(
                  itemCount: favorites.length,
                  itemBuilder: (context, i) {
                    final recipeText = favorites[i];
                    final name = _extractRecipeName(recipeText);
                    final content = _extractRecipeContent(recipeText);

                    return ListTile(
                      leading: const Icon(Icons.favorite,
                          color: Colors.red, size: 24),
                      title: Text(name),
                      subtitle: Text(
                        content.length > 50
                            ? '${content.substring(0, 50)}…'
                            : content,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                      ),
                      onTap: () {
                        widget.onRecipeSelected(name, content);
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── RECIPE SCANNED DIALOG ───────────────────────────────────────────────────
class _RecipeScannedDialog extends StatelessWidget {
  final String recipeContent;
  final VoidCallback onSaveToCookbook;
  final VoidCallback onShare;
  final VoidCallback onDismiss;

  const _RecipeScannedDialog({
    required this.recipeContent,
    required this.onSaveToCookbook,
    required this.onShare,
    required this.onDismiss,
  });

  @override
  Widget build(BuildContext context) {
    // Parse recipe: first line is name, rest is content
    final lines = recipeContent.split('\n');
    final recipeName = lines.isNotEmpty && lines[0].isNotEmpty
        ? lines[0]
        : 'Scanned Recipe';
    final details =
        lines.length > 1 ? lines.sublist(1).join('\n').trim() : '';

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 48),
            const SizedBox(height: 12),
            const Text(
              'Recipe Found!',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            // Recipe name
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade50,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.orange.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Recipe',
                    style: TextStyle(
                        fontSize: 11, color: Colors.orange, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    recipeName,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            // Recipe content
            if (details.isNotEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Details',
                      style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      details.length > 200
                          ? '${details.substring(0, 200)}…'
                          : details,
                      style: const TextStyle(fontSize: 12, height: 1.5),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),
            // Buttons
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onSaveToCookbook,
                icon: const Icon(Icons.favorite_border, size: 18),
                label: const Text('Save to Cookbook'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.shade400,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onShare,
                    icon: const Icon(Icons.share, size: 16),
                    label: const Text('Share'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.orange,
                      side: const BorderSide(color: Colors.orange),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextButton(
                    onPressed: onDismiss,
                    child: const Text('Scan Another',
                        style: TextStyle(color: Colors.grey)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}