import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../app_secrets.dart';
import '../services/auth_service.dart';
import '../services/biometric_auth_service.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _authService = AuthService();
  final _bioService = BiometricAuthService();

  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _rememberMe = false;

  bool _biometricAvailable = false;
  IconData _bioIcon = Icons.fingerprint;
  String _bioLabel = 'Biometrics';

  @override
  void initState() {
    super.initState();
    _initLogin();
  }

  Future<void> _initLogin() async {
    final prefs = await SharedPreferences.getInstance();

    final savedEmail    = prefs.getString('saved_email') ?? '';
    final savedPassword = prefs.getString('saved_password') ?? '';
    final rememberMe    = prefs.getBool('remember_me') ?? false;

    final bioEnabled   = await _bioService.isBiometricEnabled();
    final bioAvailable = await _bioService.isAvailable();
    final bioIcon      = await _bioService.getBiometricIcon();
    final bioLabel     = await _bioService.getBiometricLabel();

    if (!mounted) return;

    final canUseBio = bioAvailable && bioEnabled;

    setState(() {
      _biometricAvailable = canUseBio;
      _bioIcon            = bioIcon;
      _bioLabel           = bioLabel;

      if (rememberMe) {
        _emailCtrl.text    = savedEmail;
        _passwordCtrl.text = savedPassword;
        _rememberMe        = true;
      }
    });

    if (canUseBio) {
      await Future.delayed(const Duration(milliseconds: 400));
      if (mounted) _loginWithBiometric();
    }
  }

  Future<void> _loginWithBiometric() async {
    if (_isLoading) return;

    final result = await _bioService.authenticate(
      reason: 'Hey Chef! Scan your finger to jump back in 🍳',
    );

    if (!mounted) return;

    switch (result) {
      case BiometricResult.success:
        final prefs    = await SharedPreferences.getInstance();
        final email    = prefs.getString('saved_email') ?? '';
        final password = prefs.getString('saved_password') ?? '';

        if (email.isNotEmpty && password.isNotEmpty) {
          setState(() => _isLoading = true);
          try {
            await _authService.loginWithEmail(
                email: email, password: password);
            if (!mounted) return;
            _navigateAfterLogin(email);
          } on FirebaseAuthException catch (e) {
            _showError(_friendlyAuthError(e.code));
          } finally {
            if (mounted) setState(() => _isLoading = false);
          }
        } else {
          _showBiometricCredentialDialog();
        }
        break;

      case BiometricResult.lockedOut:
        _showError(
            'Whoa, slow down! 🔒 Too many attempts. Give it a moment and try again.');
        break;

      case BiometricResult.notAvailable:
      case BiometricResult.notEnrolled:
        _showError(
            'Hmm, biometrics aren\'t set up yet 🤔 Head to device Settings → Security to enroll.');
        break;

      case BiometricResult.failed:
      case BiometricResult.error:
      default:
        break;
    }
  }

  void _showBiometricCredentialDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('One quick thing! 👋'),
        content: const Text(
          'We verified your fingerprint, but we don\'t have your login details saved yet.\n\n'
          'Just log in once with your email & password and tick "Remember me" — '
          'after that, it\'s fingerprint all the way! 🚀',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Got it!',
                style: TextStyle(
                    color: Colors.orange, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      await _authService.loginWithEmail(
        email: _emailCtrl.text.trim(),
        password: _passwordCtrl.text,
      );

      final prefs = await SharedPreferences.getInstance();
      if (_rememberMe) {
        await prefs.setString('saved_email', _emailCtrl.text.trim());
        await prefs.setString('saved_password', _passwordCtrl.text);
        await prefs.setBool('remember_me', true);
      } else {
        await prefs.remove('saved_email');
        await prefs.remove('saved_password');
        await prefs.setBool('remember_me', false);
      }

      if (!mounted) return;
      _navigateAfterLogin(_emailCtrl.text.trim());
    } on FirebaseAuthException catch (e) {
      _showError(_friendlyAuthError(e.code));
    } catch (_) {
      _showError('Something went wrong in the kitchen 😅 Please try again!');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  /// Maps Firebase error codes to friendly messages
  String _friendlyAuthError(String code) {
    switch (code) {
      case 'wrong-password':
      case 'invalid-credential':
        return 'Oops! Wrong password 😅 Double-check and try again.';
      case 'user-not-found':
        return 'Hmm, we don\'t recognise that email 🤷 Maybe try registering?';
      case 'invalid-email':
        return 'That email doesn\'t look quite right 📧 Check the format!';
      case 'user-disabled':
        return 'Uh oh! This account has been disabled 😟 Contact support.';
      case 'too-many-requests':
        return 'Whoa, too many tries! 🔥 Take a breather and try again soon.';
      case 'network-request-failed':
        return 'No internet? 📶 Check your connection and try again.';
      case 'email-already-in-use':
        return 'That email\'s already taken 🍳 Try logging in instead!';
      case 'weak-password':
        return 'That password\'s a little too easy to guess 🔓 Make it stronger!';
      case 'operation-not-allowed':
        return 'This login method isn\'t enabled right now 😕 Try another way.';
      case 'requires-recent-login':
        return 'For security, please log in again to continue 🔐';
      case 'account-exists-with-different-credential':
        return 'Looks like you signed up with a different method 🤔 Try that instead!';
      default:
        return 'Something went wrong in the kitchen 😅 Please try again!';
    }
  }

  void _navigateAfterLogin(String email) {
    if (AppSecrets.isAdmin(email)) {
      Navigator.pushReplacementNamed(context, '/admin');
    } else {
      Navigator.pushReplacementNamed(context, '/home');
    }
  }

  Future<void> _forgotPassword() async {
    if (_emailCtrl.text.trim().isEmpty) {
      _showError('Pop your email in first so we know where to send it 📧');
      return;
    }
    try {
      await _authService.sendPasswordReset(_emailCtrl.text.trim());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
              '📬 Password reset email on its way! Check your inbox.'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } on FirebaseAuthException catch (e) {
      _showError(_friendlyAuthError(e.code));
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red[400],
        duration: const Duration(seconds: 4),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),

              // ── Logo ──────────────────────────────────────────────────
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.orange.withValues(alpha: 0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text('👨‍🍳', style: TextStyle(fontSize: 44)),
                  ),
                ),
              ),

              const SizedBox(height: 24),
              const Center(
                child: Text(
                  'Welcome back, Chef! 👋',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 4),
              Center(
                child: Text(
                  'Let\'s get you back in the kitchen 🍳',
                  style: TextStyle(color: Colors.grey[600], fontSize: 14),
                ),
              ),

              const SizedBox(height: 36),

              // ── Form ──────────────────────────────────────────────────
              Form(
                key: _formKey,
                child: Column(
                  children: [
                    // Email
                    TextFormField(
                      controller: _emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        hintText: 'you@example.com',
                        prefixIcon: const Icon(Icons.email_outlined),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return 'Don\'t forget your email! 📧';
                        }
                        if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$')
                            .hasMatch(v)) {
                          return 'That doesn\'t look like a valid email 🤔';
                        }
                        return null;
                      },
                    ),

                    const SizedBox(height: 16),

                    // Password
                    TextFormField(
                      controller: _passwordCtrl,
                      obscureText: _obscurePassword,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        hintText: 'Min. 6 characters',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          icon: Icon(_obscurePassword
                              ? Icons.visibility_off_outlined
                              : Icons.visibility_outlined),
                          onPressed: () => setState(
                              () => _obscurePassword = !_obscurePassword),
                        ),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12)),
                        filled: true,
                        fillColor: Colors.white,
                      ),
                      validator: (v) {
                        if (v == null || v.isEmpty) {
                          return 'Password can\'t be empty! 🔑';
                        }
                        if (v.length < 6) {
                          return 'At least 6 characters please 🙏';
                        }
                        return null;
                      },
                    ),

                    const SizedBox(height: 8),

                    // Remember me & Forgot password
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Checkbox(
                              value: _rememberMe,
                              onChanged: (v) =>
                                  setState(() => _rememberMe = v ?? false),
                              fillColor:
                                  WidgetStateProperty.resolveWith<Color>(
                                (states) =>
                                    states.contains(WidgetState.selected)
                                        ? Colors.orange
                                        : Colors.grey,
                              ),
                            ),
                            const Text('Remember me',
                                style: TextStyle(fontSize: 13)),
                          ],
                        ),
                        TextButton(
                          onPressed: _forgotPassword,
                          child: const Text('Forgot password? 🤔',
                              style: TextStyle(color: Colors.orange)),
                        ),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // ── Login button ──────────────────────────────────
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: ElevatedButton(
                        onPressed: _isLoading ? null : _login,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          elevation: 2,
                        ),
                        child: _isLoading
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2),
                              )
                            : const Text('Let\'s Cook! 🍽️',
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                      ),
                    ),

                    // ── Biometric button ──────────────────────────────
                    if (_biometricAvailable) ...[
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: OutlinedButton.icon(
                          onPressed:
                              _isLoading ? null : _loginWithBiometric,
                          icon: Icon(_bioIcon, color: Colors.orange),
                          label: Text(
                            'Jump in with $_bioLabel 👆',
                            style: const TextStyle(
                              color: Colors.orange,
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: Colors.orange),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Center(
                        child: Text(
                          '💡 Tick "Remember me" on first login to use biometrics next time',
                          style: TextStyle(
                              fontSize: 11, color: Colors.grey[500]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── Divider ───────────────────────────────────────────────
              Row(
                children: [
                  Expanded(child: Divider(color: Colors.grey[300])),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: Text('New to Cheffy?',
                        style: TextStyle(color: Colors.grey[500])),
                  ),
                  Expanded(child: Divider(color: Colors.grey[300])),
                ],
              ),

              const SizedBox(height: 16),

              // ── Register button ───────────────────────────────────────
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton(
                  onPressed: () =>
                      Navigator.pushReplacementNamed(context, '/register'),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.orange),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text(
                    'Create My Account 🎉',
                    style: TextStyle(
                        color: Colors.orange,
                        fontSize: 16,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}