import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../widgets/common_ui.dart';

class CookingModePage extends StatefulWidget {
  final List<String> steps;

  const CookingModePage({
    super.key,
    this.steps = const ['Step 1: Example', 'Step 2: Example'],
  });

  @override
  State<CookingModePage> createState() => _CookingModePageState();
}

class _CookingModePageState extends State<CookingModePage>
    with TickerProviderStateMixin {
  int currentStep   = 0;
  Timer? stepTimer;
  int remainingTime = 0;
  bool timerRunning = false;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Step entry animation
  late AnimationController _stepCtrl;
  late Animation<double>   _stepFade;
  late Animation<double>   _stepSlide;

  // Flame animation
  late AnimationController _flameCtrl;

  // Progress pulse
  late AnimationController _pulseCtrl;
  late Animation<double>   _pulseAnim;

  // Timer ring
  late AnimationController _ringCtrl;

  @override
  void initState() {
    super.initState();

    _stepCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _stepFade  = CurvedAnimation(parent: _stepCtrl, curve: Curves.easeOut)
        as Animation<double>;
    _stepFade  = Tween<double>(begin: 0, end: 1).animate(
        CurvedAnimation(parent: _stepCtrl, curve: Curves.easeOut));
    _stepSlide = Tween<double>(begin: 40, end: 0).animate(
        CurvedAnimation(parent: _stepCtrl, curve: Curves.easeOutCubic));
    _stepCtrl.forward();

    _flameCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.06).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _ringCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );
  }

  @override
  void dispose() {
    stepTimer?.cancel();
    _stepCtrl.dispose();
    _flameCtrl.dispose();
    _pulseCtrl.dispose();
    _ringCtrl.dispose();
    super.dispose();
  }

  void _animateToStep() {
    _stepCtrl.reset();
    _stepCtrl.forward();
  }

  void nextStep() {
    if (currentStep < widget.steps.length - 1) {
      stepTimer?.cancel();
      setState(() {
        currentStep++;
        remainingTime = 0;
        timerRunning  = false;
      });
      _animateToStep();
      final t = parseTime(widget.steps[currentStep]);
      if (t > 0) {
        setState(() => remainingTime = t);
      }
    } else {
      _showCompletion();
    }
  }

  void prevStep() {
    if (currentStep > 0) {
      stepTimer?.cancel();
      setState(() {
        currentStep--;
        remainingTime = 0;
        timerRunning  = false;
      });
      _animateToStep();
    }
  }

  int parseTime(String step) {
    final regex = RegExp(r'(\d+)\s*min');
    final match = regex.firstMatch(step);
    return match != null ? int.parse(match.group(1)!) * 60 : 0;
  }

  void startTimer() {
    if (timerRunning) return;
    if (remainingTime == 0) {
      remainingTime = parseTime(widget.steps[currentStep]);
    }
    if (remainingTime == 0) return;

    setState(() => timerRunning = true);
    stepTimer?.cancel();
    stepTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (remainingTime > 0) {
        setState(() => remainingTime--);
      } else {
        timer.cancel();
        setState(() => timerRunning = false);
        _showTimerDone();
      }
    });
  }

  void pauseTimer() {
    stepTimer?.cancel();
    setState(() => timerRunning = false);
  }

  void resetTimer() {
    stepTimer?.cancel();
    setState(() {
      remainingTime = parseTime(widget.steps[currentStep]);
      timerRunning  = false;
    });
  }

  void _showTimerDone() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('⏰ Time\'s Up!',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Text(
          'Step ${currentStep + 1} timer is done.',
          style: const TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Color(0xFFFF6B00))),
          ),
        ],
      ),
    );
  }

  void _showCompletion() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E2E),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Column(
          children: [
            Text('🎉', style: TextStyle(fontSize: 56)),
            SizedBox(height: 8),
            Text('Recipe Complete!',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22)),
          ],
        ),
        content: const Text(
          'You\'ve finished all the steps. Enjoy your meal! 😋',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white60, fontSize: 14),
        ),
        actionsAlignment: MainAxisAlignment.center,
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF6B00),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(
                  horizontal: 32, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Done 🏠',
                style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  double get _timerProgress {
    final total = parseTime(widget.steps[currentStep]);
    if (total == 0) return 0;
    return remainingTime / total;
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth    = MediaQuery.of(context).size.width;
    final totalSteps     = widget.steps.length;
    final stepText       = widget.steps[currentStep];
    final hasTimer       = parseTime(stepText) > 0 || remainingTime > 0;
    final isLastStep     = currentStep == totalSteps - 1;
    final progress       = (currentStep + 1) / totalSteps;

    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFF0D0D14),
      drawer: buildDrawer(context),
      body: Column(
        children: [
          // ── App Header ───────────────────────────────────────────────────
          buildHeader(
            context:    context,
            scaffoldKey: _scaffoldKey,
            screenWidth: screenWidth,
          ),

          // ── Content ──────────────────────────────────────────────────────
          Expanded(
            child: Stack(
              children: [

                // Background glow
                Positioned(
                  top: -60,
                  left: -60,
                  child: Container(
                    width: 260,
                    height: 260,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFFFF6B00).withValues(alpha: 0.15),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      // ── Top bar: step counter + overall progress ──────────
                      Row(
                        children: [
                          // Step badge
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [
                                  Color(0xFFFF6B00),
                                  Color(0xFFFF8C00),
                                ],
                              ),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              'Step ${currentStep + 1} of $totalSteps',
                              style: const TextStyle(
                                color:      Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize:   13,
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Progress bar
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value:           progress,
                                minHeight:       6,
                                backgroundColor: Colors.white12,
                                valueColor: const AlwaysStoppedAnimation(
                                    Color(0xFFFF6B00)),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            '${(progress * 100).toInt()}%',
                            style: const TextStyle(
                                color: Colors.white54, fontSize: 12),
                          ),
                        ],
                      ),

                      const SizedBox(height: 24),

                      // ── Step card ─────────────────────────────────────────
                      Expanded(
                        child: AnimatedBuilder(
                          animation: _stepCtrl,
                          builder: (_, child) => Opacity(
                            opacity: _stepFade.value,
                            child: Transform.translate(
                              offset: Offset(0, _stepSlide.value),
                              child: child,
                            ),
                          ),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1A1A2E),
                              borderRadius: BorderRadius.circular(24),
                              border: Border.all(
                                color: const Color(0xFFFF6B00)
                                    .withValues(alpha: 0.2),
                                width: 1.5,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFFF6B00)
                                      .withValues(alpha: 0.08),
                                  blurRadius:   24,
                                  spreadRadius: 0,
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Flame icon header
                                Row(
                                  children: [
                                    AnimatedBuilder(
                                      animation: _flameCtrl,
                                      builder: (_, __) {
                                        final t = _flameCtrl.value;
                                        return Transform.scale(
                                          scale:  0.92 + t * 0.16,
                                          child: const Text('🔥',
                                              style: TextStyle(fontSize: 28)),
                                        );
                                      },
                                    ),
                                    const SizedBox(width: 10),
                                    const Text(
                                      'Cooking Mode',
                                      style: TextStyle(
                                        color:      Color(0xFFFF6B00),
                                        fontSize:   13,
                                        fontWeight: FontWeight.w600,
                                        letterSpacing: 1.2,
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 20),
                                const Divider(color: Colors.white10),
                                const SizedBox(height: 20),

                                // Step text
                                Expanded(
                                  child: SingleChildScrollView(
                                    child: Text(
                                      stepText,
                                      style: const TextStyle(
                                        color:      Colors.white,
                                        fontSize:   20,
                                        height:     1.6,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ── Timer section ─────────────────────────────────────
                      if (hasTimer) ...[
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1A1A2E),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: timerRunning
                                  ? const Color(0xFFFF6B00)
                                      .withValues(alpha: 0.5)
                                  : Colors.white12,
                            ),
                          ),
                          child: Row(
                            children: [
                              // Ring timer
                              SizedBox(
                                width:  70,
                                height: 70,
                                child: CustomPaint(
                                  painter: _TimerRingPainter(
                                    progress: _timerProgress,
                                    running:  timerRunning,
                                  ),
                                  child: Center(
                                    child: Text(
                                      _formatTime(remainingTime),
                                      style: TextStyle(
                                        color: timerRunning
                                            ? const Color(0xFFFF6B00)
                                            : Colors.white54,
                                        fontSize:   15,
                                        fontWeight: FontWeight.bold,
                                        fontFeatures: const [
                                          FontFeature.tabularFigures(),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),

                              const SizedBox(width: 16),

                              // Timer label
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      timerRunning
                                          ? 'Timer Running…'
                                          : remainingTime > 0
                                              ? 'Timer Paused'
                                              : 'Set Timer',
                                      style: TextStyle(
                                        color: timerRunning
                                            ? const Color(0xFFFF6B00)
                                            : Colors.white54,
                                        fontSize:   13,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      '${parseTime(stepText) ~/ 60} min for this step',
                                      style: const TextStyle(
                                          color:    Colors.white30,
                                          fontSize: 11),
                                    ),
                                  ],
                                ),
                              ),

                              // Timer controls
                              Row(
                                children: [
                                  // Reset
                                  _TimerBtn(
                                    icon:    Icons.replay_rounded,
                                    onTap:   resetTimer,
                                    color:   Colors.white38,
                                    tooltip: 'Reset',
                                  ),
                                  const SizedBox(width: 8),
                                  // Play / Pause
                                  _TimerBtn(
                                    icon: timerRunning
                                        ? Icons.pause_rounded
                                        : Icons.play_arrow_rounded,
                                    onTap: timerRunning
                                        ? pauseTimer
                                        : startTimer,
                                    color:  const Color(0xFFFF6B00),
                                    filled: true,
                                    tooltip: timerRunning
                                        ? 'Pause'
                                        : 'Start',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // ── Navigation buttons ────────────────────────────────
                      Row(
                        children: [
                          // Previous
                          if (currentStep > 0)
                            Expanded(
                              flex: 1,
                              child: OutlinedButton.icon(
                                onPressed: prevStep,
                                icon: const Icon(Icons.arrow_back_ios_rounded,
                                    size: 16),
                                label: const Text('Back'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: Colors.white60,
                                  side: const BorderSide(
                                      color: Colors.white24),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(14)),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 14),
                                ),
                              ),
                            ),

                          if (currentStep > 0) const SizedBox(width: 12),

                          // Next / Finish
                          Expanded(
                            flex: 2,
                            child: ScaleTransition(
                              scale: _pulseAnim,
                              child: ElevatedButton.icon(
                                onPressed: nextStep,
                                icon: Icon(
                                  isLastStep
                                      ? Icons.check_circle_rounded
                                      : Icons.arrow_forward_ios_rounded,
                                  size: 18,
                                ),
                                label: Text(
                                  isLastStep ? 'Finish 🎉' : 'Next Step',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize:   15,
                                  ),
                                ),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      const Color(0xFFFF6B00),
                                  foregroundColor: Colors.white,
                                  elevation: 4,
                                  shadowColor: const Color(0xFFFF6B00)
                                      .withValues(alpha: 0.4),
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(14)),
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 14),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      // ── Step dots ─────────────────────────────────────────
                      if (totalSteps <= 12)
                        Center(
                          child: Wrap(
                            spacing: 6,
                            children: List.generate(totalSteps, (i) {
                              final active = i == currentStep;
                              final done   = i < currentStep;
                              return AnimatedContainer(
                                duration: const Duration(milliseconds: 300),
                                width:  active ? 20 : 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: active
                                      ? const Color(0xFFFF6B00)
                                      : done
                                          ? const Color(0xFFFF6B00)
                                              .withValues(alpha: 0.4)
                                          : Colors.white12,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              );
                            }),
                          ),
                        ),
                    ],
                  ),
                ),

                // Animated flames at bottom
                Positioned(
                  bottom: 0,
                  left:   0,
                  right:  0,
                  child: AnimatedBuilder(
                    animation: _flameCtrl,
                    builder: (_, __) => CustomPaint(
                      painter: _FlamePainter(_flameCtrl.value),
                      child: const SizedBox(height: 60),
                    ),
                  ),
                ),
              ],
            ),
          ),

          buildFooter(),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TIMER BUTTON
// ─────────────────────────────────────────────────────────────────────────────
class _TimerBtn extends StatelessWidget {
  final IconData  icon;
  final VoidCallback onTap;
  final Color     color;
  final bool      filled;
  final String    tooltip;

  const _TimerBtn({
    required this.icon,
    required this.onTap,
    required this.color,
    required this.tooltip,
    this.filled = false,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width:  44,
          height: 44,
          decoration: BoxDecoration(
            color: filled
                ? color
                : color.withValues(alpha: 0.12),
            shape: BoxShape.circle,
          ),
          child: Icon(icon,
              color: filled ? Colors.white : color, size: 22),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  TIMER RING PAINTER
// ─────────────────────────────────────────────────────────────────────────────
class _TimerRingPainter extends CustomPainter {
  final double progress;
  final bool   running;

  const _TimerRingPainter({required this.progress, required this.running});

  @override
  void paint(Canvas canvas, Size size) {
    final cx    = size.width / 2;
    final cy    = size.height / 2;
    final r     = (size.width / 2) - 5;
    final sweep = 2 * pi * progress;

    // Track
    canvas.drawCircle(
      Offset(cx, cy),
      r,
      Paint()
        ..color       = Colors.white10
        ..style       = PaintingStyle.stroke
        ..strokeWidth = 5,
    );

    // Arc
    if (progress > 0) {
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy), radius: r),
        -pi / 2,
        sweep,
        false,
        Paint()
          ..color       = running
              ? const Color(0xFFFF6B00)
              : const Color(0xFFFF6B00).withValues(alpha: 0.5)
          ..style       = PaintingStyle.stroke
          ..strokeWidth = 5
          ..strokeCap   = StrokeCap.round,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _TimerRingPainter old) =>
      old.progress != progress || old.running != running;
}

// ─────────────────────────────────────────────────────────────────────────────
//  FLAME PAINTER
// ─────────────────────────────────────────────────────────────────────────────
class _FlamePainter extends CustomPainter {
  final double t;
  const _FlamePainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final h1 = 20 + sin(t * pi) * 18;
    final h2 = 14 + sin(t * pi + 1.2) * 12;
    final h3 = 18 + sin(t * pi + 2.4) * 15;

    void drawFlame(double x, double h, Color c, double w) {
      final paint = Paint()
        ..shader = LinearGradient(
          colors: [c.withValues(alpha: 0.0), c.withValues(alpha: 0.45)],
          begin:  Alignment.topCenter,
          end:    Alignment.bottomCenter,
        ).createShader(Rect.fromLTWH(x - w, 0, w * 2, size.height))
        ..style = PaintingStyle.fill;

      final path = Path()
        ..moveTo(x - w, size.height)
        ..quadraticBezierTo(x - w * 0.4, size.height - h, x, size.height - h)
        ..quadraticBezierTo(x + w * 0.4, size.height - h, x + w, size.height)
        ..close();

      canvas.drawPath(path, paint);
    }

    drawFlame(size.width * 0.2,  h1, const Color(0xFFFF4500), 60);
    drawFlame(size.width * 0.5,  h2, const Color(0xFFFF6B00), 80);
    drawFlame(size.width * 0.78, h3, const Color(0xFFFF8C00), 55);
  }

  @override
  bool shouldRepaint(covariant _FlamePainter old) => old.t != t;
}