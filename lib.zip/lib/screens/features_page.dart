import 'package:flutter/material.dart';
import '../widgets/common_ui.dart';

class FeaturesPage extends StatefulWidget {
  const FeaturesPage({super.key});

  @override
  State<FeaturesPage> createState() => _FeaturesPageState();
}

class _FeaturesPageState extends State<FeaturesPage> {
  // Moved out of build() so the key is stable across rebuilds
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final List<Map<String, String>> features = const [
    {
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZuucasw_dmQZk7uZsMyoJymP_g_39dr0aInBdFnVSRKX0oUtl',
      'name': 'AI Chat Chef',
      'description':
          'Your personal AI assistant that summarizes videos, guides recipes, suggests ingredients, and chats with you while cooking.',
    },
    {
      'image': 'https://cdn-icons-png.flaticon.com/512/5088/5088218.png',
      'name': 'Nearby Stores Map',
      'description':
          'Locate stores near you quickly with an interactive map and get directions if needed.',
    },
    {
      'image':
          'https://tse1.mm.bing.net/th/id/OIP.sjcUcqF6Bdai2O1uL5WdowHaH7?rs=1&pid=ImgDetMain&o=7&rm=3',
      'name': 'Online Grocery Integration',
      'description': 'Order ingredients directly online without stepping outside.',
    },
    {
      'image': 'https://cdn-icons-png.flaticon.com/512/32/32223.png',
      'name': 'Recipe History & Analytics',
      'description':
          'Access past recipes anytime and visualize your cooking habits with charts.',
    },
    {
      'image': 'https://cdn-icons-png.flaticon.com/256/10264/10264233.png',
      'name': 'Recipe Sharing',
      'description':
          'Share your favourite recipes with friends via social media, messaging, or email.',
    },
    {
      'image':
          'https://static.vecteezy.com/system/resources/thumbnails/029/884/056/small/notification-bell-icon-in-flat-style-incoming-inbox-message-illustration-on-isolated-background-ringing-bell-sign-business-concept-vector.jpg',
      'name': 'Smart Notifications & Favourite Recipes',
      'description':
          'Get real-time alerts and a receipt-style summary of your completed recipes.',
    },
    {
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjXFYsN261iE8y6TU9wYcJDKdEtSulAxwBcQ&s',
      'name': 'Photo Capture & Rewards',
      'description':
          'Take pictures of your dishes, earn points, and redeem them for prizes.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 700;

    return Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      body: Column(
        children: [
          buildHeader(
            context: context,
            scaffoldKey: _scaffoldKey,
            screenWidth: screenWidth,
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '✨ App Features',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  isMobile
                      ? Column(
                          children: features
                              .map((f) => _FeatureCard(feature: f))
                              .toList(),
                        )
                      : GridView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 16,
                            mainAxisSpacing: 16,
                            childAspectRatio: 1.6,
                          ),
                          itemCount: features.length,
                          itemBuilder: (_, i) =>
                              _FeatureCard(feature: features[i]),
                        ),
                ],
              ),
            ),
          ),
          buildFooter(),
        ],
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  final Map<String, String> feature;
  const _FeatureCard({required this.feature});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Image.network(
                feature['image']!,
                width: 64,
                height: 64,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: Colors.orange.shade100,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.restaurant, color: Colors.orange),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    feature['name']!,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    feature['description']!,
                    style: const TextStyle(
                      fontSize: 13,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
