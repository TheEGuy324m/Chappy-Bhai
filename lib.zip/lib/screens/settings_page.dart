import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/biometric_auth_service.dart';
import '../widgets/common_ui.dart';
import '../services/notification_service.dart';
import '../services/offline_service.dart';

class SettingsPage extends StatefulWidget {
  final Function(ThemeMode) onThemeChanged;
  const SettingsPage({super.key, required this.onThemeChanged});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool isDarkMode = false;
  bool notificationsEnabled = true;
  bool biometricEnabled = false;
  bool biometricAvailable = false;
  String selectedLanguage = 'English';
  String? userName;
  String _fcmToken = '';
  int _queueSize = 0;
  String _biometricLabel = 'Biometrics';
  IconData _bioIcon = Icons.fingerprint;

  final _bioService = BiometricAuthService();
  final _notifService = NotificationService();
  final _offlineService = OfflineService();

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final available = await _bioService.isAvailable();
    final bioEnabled = await _bioService.isBiometricEnabled();
    final bioLabel = await _bioService.getBiometricLabel();
    final bioIcon = await _bioService.getBiometricIcon();
    final token = await _notifService.getToken() ?? '';
    final qSize = await _offlineService.getQueueSize();

    debugPrint('[Settings] Biometric available: $available');
    debugPrint('[Settings] Biometric enabled: $bioEnabled');

    if (!mounted) return;
    setState(() {
      isDarkMode = prefs.getBool('darkMode') ?? false;
      notificationsEnabled = prefs.getBool('notifications') ?? true;
      selectedLanguage = prefs.getString('language') ?? 'English';
      userName = prefs.getString('user_name') ?? 'Chef';
      biometricAvailable = available;
      biometricEnabled = bioEnabled;
      _biometricLabel = bioLabel;
      _bioIcon = bioIcon;
      _fcmToken =
          token.isNotEmpty ? '${token.substring(0, 20)}…' : 'Not available';
      _queueSize = qSize;
    });
  }

  Future<void> toggleDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', value);
    setState(() => isDarkMode = value);
    widget.onThemeChanged(value ? ThemeMode.dark : ThemeMode.light);
  }

  Future<void> toggleNotifications(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications', value);
    setState(() => notificationsEnabled = value);
  }

  Future<void> toggleBiometric(bool value) async {
    debugPrint('[Settings] Toggle biometric: $value');

    if (value) {
      final available = await _bioService.isAvailable();
      debugPrint('[Settings] Biometric available: $available');

      if (!available) {
        if (!mounted) return;
        _showSnack('No biometrics found on this device.', Colors.red);
        setState(() => biometricEnabled = false);
        return;
      }

      debugPrint('[Settings] Prompting biometric to confirm...');
      final result = await _bioService.authenticate(
        reason: 'Scan your fingerprint or face to enable biometric login',
      );
      debugPrint('[Settings] Biometric auth result: $result');

      if (!mounted) return;

      if (result == BiometricResult.success) {
        // ✅ Verified — save and confirm
        await _bioService.setBiometricEnabled(true);
        if (!mounted) return;
        setState(() => biometricEnabled = true);
        _showSnack('$_biometricLabel login enabled ✅', Colors.green);
      } else if (result == BiometricResult.notAvailable ||
          result == BiometricResult.notEnrolled) {
        _showSnack(
          'Please set up $_biometricLabel in device Settings first.',
          Colors.orange,
          duration: const Duration(seconds: 4),
        );
        setState(() => biometricEnabled = false);
      } else if (result == BiometricResult.lockedOut) {
        _showSnack(
          'Too many attempts. Please try again later.',
          Colors.red,
        );
        setState(() => biometricEnabled = false);
      } else {
        // failed or cancelled — reset toggle silently, no scary error
        setState(() => biometricEnabled = false);
      }
      return;
    }

    // Disabling — no prompt needed
    await _bioService.setBiometricEnabled(false);
    if (!mounted) return;
    setState(() => biometricEnabled = false);
    _showSnack('$_biometricLabel login disabled', Colors.grey);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  void _showSnack(
    String message,
    Color color, {
    Duration duration = const Duration(seconds: 3),
  }) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: duration,
      ),
    );
  }

  Future<void> testNotification() async {
    await _notifService.showInstant(
      title: '🍳 Cheffy Test Notification',
      body: 'Notifications are working correctly!',
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Test notification sent!')),
    );
  }

  Future<void> manualSync() async {
    await _offlineService.manualSync();
    final qSize = await _offlineService.getQueueSize();
    if (!mounted) return;
    setState(() => _queueSize = qSize);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Sync complete!'), backgroundColor: Colors.green),
    );
  }

  Future<void> clearFavorites() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear Cookbook?'),
        content: const Text(
            'This will remove all your saved recipes. Are you sure?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Clear', style: TextStyle(color: Colors.red))),
        ],
      ),
    );
    if (confirm == true) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('favorites');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Cookbook cleared!')),
      );
    }
  }

  Future<void> editName() async {
    final controller = TextEditingController(text: userName);
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Edit Name'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(hintText: 'Enter your name'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () => _saveUserName(controller, context),
            child: const Text('Save', style: TextStyle(color: Colors.orange)),
          ),
        ],
      ),
    );
  }

  Future<void> _saveUserName(
      TextEditingController ctrl, BuildContext ctx) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_name', ctrl.text);
    if (!mounted) return;
    setState(() => userName = ctrl.text);
    Navigator.pop(ctx);
  }

  Future<void> _selectLanguage(String lang) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language', lang);
    if (!mounted) return;
    setState(() => selectedLanguage = lang);
    Navigator.pop(context);
  }

  // ── UI helpers ────────────────────────────────────────────────────────────

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.orange,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _tile({
    required IconData icon,
    required String title,
    String? subtitle,
    Widget? trailing,
    VoidCallback? onTap,
    Color iconColor = Colors.orange,
    bool enabled = true,
  }) {
    return ListTile(
      enabled: enabled,
      leading: CircleAvatar(
        backgroundColor: enabled ? Colors.orange.shade50 : Colors.grey.shade100,
        child: Icon(icon, color: enabled ? iconColor : Colors.grey, size: 20),
      ),
      title: Text(title,
          style: TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 15,
              color: enabled ? Colors.black : Colors.grey)),
      subtitle: subtitle != null
          ? Text(subtitle,
              style: TextStyle(
                  fontSize: 12,
                  color: enabled ? Colors.grey : Colors.grey.shade400))
          : null,
      trailing: trailing ?? const Icon(Icons.chevron_right, color: Colors.grey),
      onTap: enabled ? onTap : null,
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return CheffyScaffold(
      currentPage: 'Settings',
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Settings'),
          backgroundColor: Colors.orange,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        body: ListView(
          children: [
            // ── PROFILE ──────────────────────────────────────────────────
            _section('PROFILE'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: _tile(
                icon: Icons.person_outline,
                title: 'Your Name',
                subtitle: userName ?? 'Chef',
                trailing: const Icon(Icons.edit, color: Colors.grey, size: 18),
                onTap: editName,
              ),
            ),

            // ── APPEARANCE ───────────────────────────────────────────────
            _section('APPEARANCE'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: _tile(
                icon: isDarkMode ? Icons.dark_mode : Icons.light_mode,
                title: 'Dark Mode',
                subtitle: isDarkMode ? 'Dark theme is on' : 'Light theme is on',
                trailing: Switch(
                  value: isDarkMode,
                  onChanged: toggleDarkMode,
                  activeTrackColor: Colors.orange,
                ),
              ),
            ),

            // ── SECURITY ─────────────────────────────────────────────────────────────────
            _section('SECURITY'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: biometricAvailable
                          ? Colors.orange.shade50
                          : Colors.grey.shade100,
                      child: Icon(
                        _bioIcon,
                        color: biometricAvailable ? Colors.orange : Colors.grey,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '$_biometricLabel Login',
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              fontSize: 15,
                              color: biometricAvailable
                                  ? Colors.black
                                  : Colors.grey,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            biometricAvailable
                                ? (biometricEnabled
                                    ? 'Enabled — tap to disable'
                                    : 'Tap to enable — you will be prompted to scan')
                                : 'Not available on this device',
                            style: TextStyle(
                              fontSize: 12,
                              color: biometricAvailable
                                  ? Colors.grey
                                  : Colors.grey.shade400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: biometricEnabled,
                      onChanged:
                          biometricAvailable ? (v) => toggleBiometric(v) : null,
                      activeTrackColor: Colors.orange,
                      activeColor: Colors.white,
                    ),
                  ],
                ),
              ),
            ),
            // Success hint shown when biometric is enabled
            if (biometricAvailable && biometricEnabled)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade100),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.check_circle_outline,
                          size: 16, color: Colors.green.shade700),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '$_biometricLabel login is active. '
                          'You will be prompted automatically next time you open the app.',
                          style: TextStyle(
                              fontSize: 12, color: Colors.green.shade800),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // ── NOTIFICATIONS ────────────────────────────────────────────
            _section('NOTIFICATIONS'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  _tile(
                    icon: Icons.notifications_outlined,
                    title: 'Notifications',
                    subtitle: notificationsEnabled ? 'Enabled' : 'Disabled',
                    trailing: Switch(
                      value: notificationsEnabled,
                      onChanged: toggleNotifications,
                      activeTrackColor: Colors.orange,
                    ),
                  ),
                  const Divider(height: 1, indent: 16),
                  _tile(
                    icon: Icons.send_outlined,
                    title: 'Test Notification',
                    subtitle: 'Send a test push notification now',
                    trailing:
                        const Icon(Icons.chevron_right, color: Colors.grey),
                    onTap: testNotification,
                  ),
                  const Divider(height: 1, indent: 16),
                  _tile(
                    icon: Icons.token_outlined,
                    title: 'FCM Token',
                    subtitle: _fcmToken,
                    trailing: const SizedBox.shrink(),
                  ),
                ],
              ),
            ),

            // ── OFFLINE & SYNC ───────────────────────────────────────────
            _section('OFFLINE & SYNC'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  _tile(
                    icon: Icons.sync,
                    title: 'Sync Offline Data',
                    subtitle: '$_queueSize operation(s) pending',
                    trailing:
                        const Icon(Icons.chevron_right, color: Colors.grey),
                    onTap: manualSync,
                  ),
                  const Divider(height: 1, indent: 16),
                  _tile(
                    icon: Icons.wifi_off,
                    title: 'Offline Mode',
                    subtitle: 'Changes are saved locally when offline',
                    trailing: const SizedBox.shrink(),
                  ),
                ],
              ),
            ),

            // ── PREFERENCES ──────────────────────────────────────────────
            _section('PREFERENCES'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: _tile(
                icon: Icons.language,
                title: 'Language',
                subtitle: selectedLanguage,
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    shape: const RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(20)),
                    ),
                    builder: (_) => Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(height: 12),
                        const Text('Select Language',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 8),
                        ...[
                          'English',
                          'Urdu',
                          'Arabic',
                          'French',
                          'Spanish',
                        ].map(
                          (lang) => ListTile(
                            title: Text(lang),
                            trailing: selectedLanguage == lang
                                ? const Icon(Icons.check, color: Colors.orange)
                                : null,
                            onTap: () => _selectLanguage(lang),
                          ),
                        ),
                        const SizedBox(height: 12),
                      ],
                    ),
                  );
                },
              ),
            ),

            // ── DATA ─────────────────────────────────────────────────────
            _section('DATA'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: _tile(
                icon: Icons.delete_sweep_outlined,
                title: 'Clear Cookbook',
                subtitle: 'Remove all saved recipes',
                iconColor: Colors.red,
                trailing: const Icon(Icons.chevron_right, color: Colors.grey),
                onTap: clearFavorites,
              ),
            ),

            // ── ABOUT ────────────────────────────────────────────────────
            _section('ABOUT'),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Column(
                children: [
                  _tile(
                    icon: Icons.info_outline,
                    title: 'App Version',
                    subtitle: 'v1.0.0',
                    trailing: const SizedBox.shrink(),
                  ),
                  const Divider(height: 1, indent: 16),
                  _tile(
                    icon: Icons.restaurant,
                    title: 'About Cheffy',
                    subtitle: 'Your AI cooking assistant ❤️',
                    trailing: const SizedBox.shrink(),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
