import 'dart:io';
import '../app_secrets.dart';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/common_ui.dart';

// API key via AppSecrets (see app_secrets.dart)

class RewardsHubPage extends StatefulWidget {
  const RewardsHubPage({super.key});
  @override
  State<RewardsHubPage> createState() => _RewardsHubPageState();
}

class _RewardsHubPageState extends State<RewardsHubPage> {
  List<Map<String, dynamic>> rewards = [];
  int userPoints = 0;
  final ImagePicker picker = ImagePicker();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Fixed points per verified dish upload
  static const int _pointsPerUpload = 10;

  @override
  void initState() {
    super.initState();
    loadRewards();
  }

  Future<void> loadRewards() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      userPoints = prefs.getInt('userPoints') ?? 0;
      rewards = [
        {'title': 'Pasta Carbonara',  'image': null, 'status': 'Pending', 'points': 0},
        {'title': 'Chocolate Cake',   'image': null, 'status': 'Pending', 'points': 0},
        {'title': 'Vegan Salad',      'image': null, 'status': 'Pending', 'points': 0},
      ];
    });
  }

  Future<bool> requestPermissions() async {
    final cameraStatus = await Permission.camera.request();
    final galleryStatus = await Permission.photos.request();

    if (cameraStatus.isGranted || galleryStatus.isGranted) return true;

    if (!mounted) return false;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Permissions denied. Please enable from Settings.'),
      ),
    );
    return false;
  }

  Future<void> pickImage(int index) async {
    if (!await requestPermissions()) return;

    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 70,
      maxWidth: 800,
    );
    if (pickedFile == null) return;

    final imageFile = File(pickedFile.path);

    // Show evaluating state immediately
    setState(() {
      rewards[index]['image']      = imageFile;
      rewards[index]['status']     = 'Evaluating…';
      rewards[index]['points']     = 0;
      rewards[index]['aiFeedback'] = null;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('🤖 AI is evaluating your photo…'),
        backgroundColor: Colors.blueGrey,
        duration: const Duration(seconds: 2),
      ),
    );

    try {
      final bytes   = await imageFile.readAsBytes();
      final b64     = base64Encode(bytes);
      final ext     = pickedFile.path.split('.').last.toLowerCase();
      final mime    = ext == 'png' ? 'image/png' : 'image/jpeg';
      final dish    = rewards[index]['title'] as String;

      final res = await http.post(
        Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${AppSecrets.groqApiKey}',
        },
        body: jsonEncode({
          'model': 'meta-llama/llama-4-scout-17b-16e-instruct',
          'max_tokens': 250,
          'messages': [
            {
              'role': 'user',
              'content': [
                {
                  'type': 'image_url',
                  'image_url': {'url': 'data:$mime;base64,$b64'},
                },
                {
                  'type': 'text',
                  'text':
                    'You are a food quality judge. The user claims this photo shows: "$dish". '
                    'Evaluate: 1) Is this a food photo? 2) Does it resemble "$dish"? '
                    '3) Presentation quality (excellent/good/fair/poor)? '
                    'End with exactly one of these on its own line: VERDICT:APPROVED or VERDICT:REJECTED. '
                    'Be warm but honest. Under 60 words.',
                },
              ],
            }
          ],
        }),
      ).timeout(const Duration(seconds: 30));

      if (!mounted) return;

      if (res.statusCode == 200) {
        final data     = jsonDecode(res.body);
        final aiText   = data['choices'][0]['message']['content'] as String? ?? '';
        final approved = aiText.contains('VERDICT:APPROVED');
        final pts      = approved ? _pointsPerUpload : 0;
        final feedback = aiText
            .replaceAll('VERDICT:APPROVED', '')
            .replaceAll('VERDICT:REJECTED', '')
            .trim();

        setState(() {
          rewards[index]['status']     = approved ? 'Approved ✅' : 'Rejected ❌';
          rewards[index]['points']     = pts;
          rewards[index]['aiFeedback'] = feedback;
          if (approved) userPoints += pts;
        });

        if (approved) {
          final prefs = await SharedPreferences.getInstance();
          await prefs.setInt('userPoints', userPoints);
        }

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(approved
              ? '✅ Photo approved! +\$_pointsPerUpload pts 🎉'
              : '❌ Photo rejected. Try a clearer shot!'),
          backgroundColor:
              approved ? Colors.green.shade600 : Colors.red.shade400,
          behavior: SnackBarBehavior.floating,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      } else {
        _autoApprove(index);
      }
    } catch (_) {
      if (mounted) _autoApprove(index);
    }
  }

  void _autoApprove(int index) {
    setState(() {
      rewards[index]['status']     = 'Approved ✅';
      rewards[index]['points']     = _pointsPerUpload;
      rewards[index]['aiFeedback'] = 'AI evaluation unavailable — auto-approved.';
      userPoints += _pointsPerUpload;
    });
    SharedPreferences.getInstance()
        .then((p) => p.setInt('userPoints', userPoints));
  }

  Widget buildRewardCard(int index) {
    final reward = rewards[index];
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              reward['title'],
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            reward['image'] != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(
                      reward['image'],
                      height: 140,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  )
                : Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Center(
                      child: Icon(Icons.image, size: 60, color: Colors.grey),
                    ),
                  ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Chip(
                  label: Text(reward['status'] ?? 'Pending'),
                  backgroundColor: (reward['status'] as String? ?? '').contains('Approved')
                      ? Colors.green.shade100
                      : (reward['status'] as String? ?? '').contains('Rejected')
                          ? Colors.red.shade100
                          : Colors.orange.shade100,
                ),
                const SizedBox(width: 12),
                Chip(
                  avatar: const Icon(Icons.star, size: 16, color: Colors.amber),
                  label: Text('${reward['points'] ?? 0} pts'),
                ),
              ],
            ),
            // AI feedback block
            if (reward['aiFeedback'] != null) ...[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('🤖 ', style: TextStyle(fontSize: 14)),
                    Expanded(
                      child: Text(
                        reward['aiFeedback'],
                        style: TextStyle(
                            fontSize: 12,
                            color: Colors.orange.shade800,
                            height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
            ],
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => pickImage(index),
                icon: const Icon(Icons.upload_file),
                label: Text(
                  reward['status'] == 'Pending' ? 'Upload Photo' : 'Re-upload',
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildPrizes() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.orange.shade300, Colors.orange.shade600],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '🎁 Prizes',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            '100 pts → Free Utensil\n'
            '250 pts → Recipe Book\n'
            '500 pts → Mystery Box 🎉',
            style: TextStyle(color: Colors.white, height: 1.6),
          ),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: (userPoints % 500) / 500,
            minHeight: 10,
            backgroundColor: Colors.white38,
            valueColor:
                const AlwaysStoppedAnimation<Color>(Colors.white),
          ),
          const SizedBox(height: 6),
          Text(
            'Your Points: $userPoints  •  Next reward: ${500 - (userPoints % 500)} pts away',
            style: const TextStyle(color: Colors.white70, fontSize: 12),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return CheffyScaffold(
      currentPage: 'Rewards Hub',
      child: Scaffold(
      key: _scaffoldKey,
      drawer: buildDrawer(context),
      body: Column(
        children: [
          buildHeader(
            context: context,
            scaffoldKey: _scaffoldKey,
            screenWidth: screenWidth,
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  buildPrizes(),
                  const SizedBox(height: 20),
                  const Text(
                    'Your Recipes',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 10),
                  ...List.generate(
                    rewards.length,
                    (i) => buildRewardCard(i),
                  ),
                ],
              ),
            ),
          ),
          buildFooter(),
        ],
      ),
    )); // CheffyScaffold + Scaffold
  }
}
