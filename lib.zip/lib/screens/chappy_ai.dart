import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../app_secrets.dart';
import '../widgets/common_ui.dart';
import 'cooking_mode_page.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  CHEFFY AI — powered by Groq
// ─────────────────────────────────────────────────────────────────────────────
class ChatPage extends StatefulWidget {
  /// Optional pre-filled message — set by the Home page Meal Customizer
  final String? initialMessage;
  const ChatPage({super.key, this.initialMessage});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> with TickerProviderStateMixin {
  // API key from build-time environment (see app_secrets.dart)
  String get _groqApiKey => AppSecrets.groqApiKey;

  final TextEditingController _controller    = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _scrollController   = ScrollController();

  List<Map<String, String>> messages = [];
  List<String> currentSuggestions    = [];
  String lastAIResponse = '';
  bool _isSaved  = false;
  bool _isLoading = false;

  late AnimationController _typingCtrl;
  Timer? suggestionTimer;

  final List<String> allSuggestions = [
    "Let's make a sandwich 🥪",
    "Quick egg breakfast 🍳",
    "Healthy salad time 🥗",
    "Chocolate dessert 🍫",
    "Yummy pasta tonight 🍝",
    "Soup to warm you up 🍲",
    "Smoothie break 🥤",
    "Baking fun 🍪",
    "Vegan meal ideas 🌱",
    "Grilled dishes 🍖",
    "Snack attack 🍿",
    "Dinner in 20 mins ⏱️",
  ];

  @override
  void initState() {
    super.initState();

    _typingCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();

    updateSuggestions();
    suggestionTimer = Timer.periodic(const Duration(minutes: 5), (_) {
      updateSuggestions();
    });

    // ── Auto-send the initial message from the Home page Meal Customizer ──
    if (widget.initialMessage != null &&
        widget.initialMessage!.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        sendMessage(widget.initialMessage);
      });
    }
  }

  @override
  void dispose() {
    suggestionTimer?.cancel();
    _typingCtrl.dispose();
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ── SAVE TO COOKBOOK ────────────────────────────────────────────────────
  Future<void> saveFavorite(String recipe) async {
    final prefs     = await SharedPreferences.getInstance();
    final favorites = prefs.getStringList('favorites') ?? [];

    if (!favorites.contains(recipe)) {
      favorites.add(recipe);
      await prefs.setStringList('favorites', favorites);
      if (!mounted) return;
      setState(() => _isSaved = true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Row(
            children: [
              Icon(Icons.favorite, color: Colors.red, size: 16),
              SizedBox(width: 8),
              Text('Saved to Cookbook ❤️'),
            ],
          ),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          duration: const Duration(seconds: 2),
        ),
      );
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Already in your Cookbook!'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12)),
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void updateSuggestions() {
    setState(() {
      currentSuggestions = getRandomSuggestions(4);
    });
  }

  List<String> getRandomSuggestions(int count) {
    final copy = List<String>.from(allSuggestions)..shuffle(Random());
    return copy.take(count).toList();
  }

  // ── SEND MESSAGE ──────────────────────────────────────────────────────
  void sendMessage([String? customText]) {
    final text = (customText ?? _controller.text).trim();
    if (text.isEmpty || _isLoading) return;

    setState(() {
      messages.add({'sender': 'user', 'text': text});
      _isSaved   = false;
      _isLoading = true;
    });
    _controller.clear();
    _scrollToBottom();
    _callCheffyAI(text);
  }

  // ── CALL GROQ API ──────────────────────────────────────────────────────
  Future<void> _callCheffyAI(String userMessage) async {
    const systemPrompt =
        'You are cheffy, a friendly and expert AI cooking assistant inside '
        'the Cheffy app. Help users with recipes, cooking tips, ingredient '
        'substitutions, and step-by-step instructions. '
        'When giving a recipe, always format the steps as numbered lines '
        'like "Step 1: ...", "Step 2: ...", etc., so the user can enter '
        'Cooking Mode. Keep responses concise and practical.';

    final List<Map<String, String>> apiMessages = [
      {'role': 'system', 'content': systemPrompt},
    ];
    for (final m in messages) {
      final text = (m['text'] ?? '').trim();
      if (text.isEmpty) continue;
      apiMessages.add({
        'role':    m['sender'] == 'user' ? 'user' : 'assistant',
        'content': text,
      });
    }

    if (apiMessages.isEmpty || apiMessages.last['role'] != 'user') {
      _handleError('Conversation state error. Please try again.');
      return;
    }

    try {
      final requestBody = jsonEncode({
        'model':      'llama-3.3-70b-versatile',
        'max_tokens': 1024,
        'messages':   apiMessages,
      });

      final response = await http
          .post(
            Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $_groqApiKey',
            },
            body: requestBody,
          )
          .timeout(const Duration(seconds: 30));

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data  = jsonDecode(response.body);
        final reply = data['choices'][0]['message']['content'] as String;
        setState(() {
          lastAIResponse = reply;
          messages.add({'sender': 'bot', 'text': reply});
          _isLoading = false;
        });
      } else {
        String errorDetail = 'Status ${response.statusCode}';
        try {
          final errData = jsonDecode(response.body);
          final msg     = errData['error']?['message'] ?? '';
          if (msg.isNotEmpty) errorDetail += ': $msg';
        } catch (_) {}
        _handleError(errorDetail);
      }
    } catch (e) {
      _handleError('Network error. Please check your connection.');
      debugPrint('cheffy AI error: $e');
    }

    _scrollToBottom();
  }

  void _handleError(String msg) {
    if (!mounted) return;
    setState(() {
      messages.add({'sender': 'bot', 'text': '⚠️ $msg'});
      _isLoading = false;
    });
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 150), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── WIDGETS ──────────────────────────────────────────────────────────
  Widget buildMessage(Map<String, String> msg) {
    final isUser = msg['sender'] == 'user';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            Container(
              width: 30,
              height: 30,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFFFF8C00), Color(0xFFFF4500)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text('🍳', style: TextStyle(fontSize: 14)),
              ),
            ),
            const SizedBox(width: 8),
          ],
          Flexible(
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.72,
              ),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 11),
              decoration: BoxDecoration(
                color: isUser ? Colors.orange : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft:     const Radius.circular(18),
                  topRight:    const Radius.circular(18),
                  bottomLeft:  Radius.circular(isUser ? 18 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 18),
                ),
                boxShadow: [
                  BoxShadow(
                    color:  Colors.black.withValues(alpha: 0.06),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Text(
                msg['text']!,
                style: TextStyle(
                  color:    isUser ? Colors.white : Colors.black87,
                  fontSize: 14,
                  height:   1.45,
                ),
              ),
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: Colors.orange.shade100,
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Icon(Icons.person, size: 18, color: Colors.orange),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF8C00), Color(0xFFFF4500)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('🍳', style: TextStyle(fontSize: 14)),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(
                topLeft:     Radius.circular(18),
                topRight:    Radius.circular(18),
                bottomRight: Radius.circular(18),
                bottomLeft:  Radius.circular(4),
              ),
              boxShadow: [
                BoxShadow(
                  color:  Colors.black.withValues(alpha: 0.06),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: AnimatedBuilder(
              animation: _typingCtrl,
              builder: (_, __) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: List.generate(3, (i) {
                    final delay   = i * 0.33;
                    final t       = (_typingCtrl.value + delay) % 1.0;
                    final opacity =
                        (t < 0.5 ? t * 2 : (1 - t) * 2).clamp(0.25, 1.0);
                    final offset =
                        (t < 0.5 ? t * 2 : (1 - t) * 2) * 4;
                    return Padding(
                      padding:
                          const EdgeInsets.symmetric(horizontal: 3),
                      child: Transform.translate(
                        offset: Offset(0, -offset),
                        child: Opacity(
                          opacity: opacity,
                          child: Container(
                            width: 7,
                            height: 7,
                            decoration: const BoxDecoration(
                              color: Colors.orange,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                      ),
                    );
                  }),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget buildRecommendations() {
    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        itemCount: currentSuggestions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, i) {
          final text = currentSuggestions[i];
          return InkWell(
            onTap: () => sendMessage(text),
            borderRadius: BorderRadius.circular(20),
            child: Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color:        Colors.white,
                borderRadius: BorderRadius.circular(20),
                border:       Border.all(color: Colors.orange.shade300),
                boxShadow: [
                  BoxShadow(
                    color:  Colors.orange.withValues(alpha: 0.08),
                    blurRadius: 4,
                    offset: const Offset(0, 1),
                  ),
                ],
              ),
              child: Text(
                text,
                style: const TextStyle(
                    fontSize: 12, color: Colors.black87),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget buildChatBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        decoration: BoxDecoration(
          color:        Colors.white,
          borderRadius: BorderRadius.circular(28),
          border:       Border.all(color: Colors.orange.shade200),
          boxShadow: [
            BoxShadow(
              color:  Colors.orange.withValues(alpha: 0.08),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller:      _controller,
                onSubmitted:     (_) => sendMessage(),
                textInputAction: TextInputAction.send,
                maxLines:        null,
                decoration: const InputDecoration(
                  hintText:  'Ask cheffy...',
                  hintStyle: TextStyle(color: Colors.grey, fontSize: 14),
                  border:    InputBorder.none,
                  isDense:   true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                ),
              ),
            ),

            // Save to Cookbook
            IconButton(
              icon: Icon(
                _isSaved ? Icons.favorite : Icons.favorite_border,
                color: lastAIResponse.isNotEmpty
                    ? (_isSaved ? Colors.red : Colors.orange.shade300)
                    : Colors.grey.shade300,
                size: 22,
              ),
              tooltip: lastAIResponse.isNotEmpty
                  ? 'Save to Cookbook'
                  : 'Ask cheffy first',
              onPressed: lastAIResponse.isNotEmpty
                  ? () => saveFavorite(lastAIResponse)
                  : null,
            ),

            // Send button
            _isLoading
                ? Container(
                    width:  42,
                    height: 42,
                    margin: const EdgeInsets.only(right: 2),
                    child: const Center(
                      child: SizedBox(
                        width:  22,
                        height: 22,
                        child:  CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color:       Colors.orange,
                        ),
                      ),
                    ),
                  )
                : GestureDetector(
                    onTap: sendMessage,
                    child: Container(
                      width:  42,
                      height: 42,
                      margin: const EdgeInsets.only(right: 2),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFFFF8C00),
                            Color(0xFFFF4500),
                          ],
                          begin: Alignment.topLeft,
                          end:   Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.send_rounded,
                        color: Colors.white,
                        size:  18,
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    final steps = lastAIResponse
        .split('\n')
        .where((line) => line.trim().isNotEmpty)
        .toList();
    final hasSteps =
        steps.any((s) => s.toLowerCase().startsWith('step'));

    return CheffyScaffold(
      currentPage: 'Cheffy AI Chat',
      child: Scaffold(
        key:             _scaffoldKey,
        drawer:          buildDrawer(context),
        backgroundColor: const Color(0xFFFFF8F2),
        body: Column(
          children: [
            buildHeader(
              context:    context,
              scaffoldKey: _scaffoldKey,
              screenWidth: screenWidth,
            ),

            // ── Status bar ──────────────────────────────────────────────
            Container(
              width:   double.infinity,
              padding: const EdgeInsets.symmetric(
                  horizontal: 16, vertical: 10),
              color: Colors.white,
              child: Row(
                children: [
                  Container(
                    width:  38,
                    height: 38,
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Color(0xFFFF8C00),
                          Color(0xFFFF4500),
                        ],
                        begin: Alignment.topLeft,
                        end:   Alignment.bottomRight,
                      ),
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Text('🍳',
                          style: TextStyle(fontSize: 20)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Let's cook with cheffy 🤖",
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        _isLoading
                            ? 'Thinking...'
                            : 'Your AI cooking buddy',
                        style: TextStyle(
                          fontSize: 11,
                          color: _isLoading
                              ? Colors.orange
                              : Colors.grey[500],
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: _isLoading
                          ? Colors.orange.shade50
                          : Colors.green.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _isLoading
                            ? Colors.orange.shade200
                            : Colors.green.shade200,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width:  6,
                          height: 6,
                          decoration: BoxDecoration(
                            color: _isLoading
                                ? Colors.orange
                                : Colors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _isLoading ? 'Busy' : 'Online',
                          style: TextStyle(
                            fontSize: 10,
                            color: _isLoading
                                ? Colors.orange
                                : Colors.green,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // ── Message list ────────────────────────────────────────────
            Expanded(
              child: messages.isEmpty && !_isLoading
                  ? _buildEmptyState()
                  : ListView.builder(
                      controller: _scrollController,
                      padding:
                          const EdgeInsets.only(top: 4, bottom: 8),
                      itemCount:
                          messages.length + (_isLoading ? 1 : 0),
                      itemBuilder: (_, i) {
                        if (_isLoading && i == messages.length) {
                          return buildTypingIndicator();
                        }
                        return buildMessage(messages[i]);
                      },
                    ),
            ),

            // ── Cooking Mode button ─────────────────────────────────────
            if (hasSteps)
              Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 6),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) =>
                            CookingModePage(steps: steps),
                      ),
                    ),
                    icon:  const Text('🍳',
                        style: TextStyle(fontSize: 16)),
                    label: const Text('Start Cooking Mode'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 10),
                      elevation: 2,
                    ),
                  ),
                ),
              ),

            const SizedBox(height: 6),
            buildRecommendations(),
            const SizedBox(height: 6),
            buildChatBar(),
            buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width:  72,
            height: 72,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFFF8C00), Color(0xFFFF4500)],
                begin: Alignment.topLeft,
                end:   Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('🍳', style: TextStyle(fontSize: 36)),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            "Hi! I'm cheffy 👋",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            'Ask me for a recipe, a tip,\nor tap a suggestion above!',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Colors.grey[500]),
          ),
        ],
      ),
    );
  }
}