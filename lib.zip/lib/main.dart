import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Widgets
import 'widgets/common_ui.dart';
import 'widgets/floating_ai_assistant.dart';

// Services
import 'services/notification_service.dart';
import 'services/offline_service.dart';

// Screens
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_page.dart';
import 'screens/features_page.dart';
import 'screens/chappy_ai.dart';
import 'screens/grocery_page.dart';
import 'screens/favorites_page.dart';
import 'screens/rewards_hub_page.dart';
import 'screens/cooking_mode_page.dart';
import 'screens/recipe_search_screen.dart';
import 'screens/qr_scanner_screen.dart';
import 'screens/nearby_stores_screen.dart';
import 'screens/analytics_dashboard_screen.dart';
import 'screens/cooking_videos_screen.dart';
import 'screens/admin_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────
//  GLOBAL NAVIGATOR KEY (for notifications)
// ─────────────────────────────────────────────────────────────────────────────
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ─────────────────────────────────────────────────────────────────────────────
//  ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  await OfflineService().initialize();
  await NotificationService().initialize(navigatorKey);

  final prefs = await SharedPreferences.getInstance();
  final isDark = prefs.getBool('darkMode') ?? false;

  runApp(MyApp(initialTheme: isDark ? ThemeMode.dark : ThemeMode.light));
}

// ─────────────────────────────────────────────────────────────────────────────
//  ROOT APP
// ─────────────────────────────────────────────────────────────────────────────
class MyApp extends StatefulWidget {
  final ThemeMode initialTheme;
  const MyApp({super.key, required this.initialTheme});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late ThemeMode _themeMode;

  @override
  void initState() {
    super.initState();
    _themeMode = widget.initialTheme;
  }

  void updateTheme(ThemeMode mode) => setState(() => _themeMode = mode);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'Cheffy',
      themeMode: _themeMode,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.orange),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.orange,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      initialRoute: '/splash',
      routes: {
        '/splash':    (_) => const SplashScreen(),
        '/login':     (_) => const LoginScreen(),
        '/register':  (_) => const RegisterScreen(),
        '/home':      (_) => HomePage(onThemeChanged: updateTheme),
        '/features':  (_) => const FeaturesPage(),
        '/chappy':    (_) => const ChatPage(),
        '/grocery':   (_) => const GroceryPage(),
        '/favorites': (_) => const FavoritesPage(),
        '/rewards':   (_) => const RewardsHubPage(),
        '/cooking':   (_) => const CookingModePage(),
        '/admin':     (_) => const AdminScreen(),
        '/profile':   (_) => const ProfileScreen(),
        '/settings':  (_) => SettingsPage(onThemeChanged: updateTheme),
        '/search':    (_) => const RecipeSearchScreen(),
        '/qr':        (_) => const QRScannerScreen(),
        '/map':       (_) => const NearbyStoresScreen(),
        '/analytics': (_) => const AnalyticsDashboardScreen(),
        '/videos':    (_) => const CookingVideosScreen(),
      },
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  HOME PAGE
// ─────────────────────────────────────────────────────────────────────────────
class HomePage extends StatefulWidget {
  final Function(ThemeMode) onThemeChanged;
  const HomePage({super.key, required this.onThemeChanged});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  String selectedMood       = 'Comfort';
  String selectedTime       = '20 min';
  String selectedDifficulty = 'Easy';

  final List<String> _sliderImages = [
    'https://images.unsplash.com/photo-1600891964599-f61ba0e24092?w=800&q=80',
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80',
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80',
    'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=800&q=80',
  ];

  int _sliderIndex = 0;

  @override
  void initState() {
    super.initState();
    _startSlider();
  }

  void _startSlider() {
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;
      setState(() {
        _sliderIndex = (_sliderIndex + 1) % _sliderImages.length;
      });
      _startSlider();
    });
  }

  Widget _quickTile({
    required String emoji,
    required String label,
    required String route,
    required Color bgColor,
  }) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(14),
        ),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final tileWidth  = constraints.maxWidth;
            final tileHeight = constraints.maxHeight;
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    emoji,
                    style: TextStyle(fontSize: tileWidth * 0.30),
                  ),
                ),
                SizedBox(height: tileHeight * 0.05),
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      label,
                      textAlign: TextAlign.center,
                      maxLines: 1,
                      style: TextStyle(
                        fontSize: tileWidth * 0.15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _chips(
    String title,
    List<String> options,
    String selected,
    void Function(String) onSelected,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 8,
          children: options.map((o) {
            return ChoiceChip(
              label: Text(o),
              selected: selected == o,
              onSelected: (_) => setState(() => onSelected(o)),
              selectedColor: Colors.orange,
            );
          }).toList(),
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final user = FirebaseAuth.instance.currentUser;

    return CheffyScaffold(
      currentPage: 'Home',
      child: Scaffold(
        key: _scaffoldKey,
        drawer: buildDrawer(context),
        body: ConnectivityBanner(
          child: Column(
            children: [
              buildHeader(
                context: context,
                scaffoldKey: _scaffoldKey,
                screenWidth: screenWidth,
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [

                      // ── Hero Banner ────────────────────────────────────────
                      SizedBox(
                        width: double.infinity,
                        height: 200,
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            Image.network(
                              _sliderImages[_sliderIndex],
                              fit: BoxFit.cover,
                              gaplessPlayback: true,
                              frameBuilder: (
                                BuildContext context,
                                Widget child,
                                int? frame,
                                bool wasSynchronouslyLoaded,
                              ) {
                                if (frame == null && !wasSynchronouslyLoaded) {
                                  return Container(color: Colors.orange);
                                }
                                return child;
                              },
                              errorBuilder: (_, __, ___) =>
                                  Container(color: Colors.orange),
                            ),
                            Container(
                                color: Colors.black.withValues(alpha: 0.45)),
                            Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'Welcome${user?.displayName != null ? ', ${user!.displayName}' : ''}! 👨‍🍳',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  const Text(
                                    'Cheffy • Your Personal AI Chef',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ── Quick Access Grid ──────────────────────────────────
                      Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Quick Access',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 10),
                            LayoutBuilder(
                              builder: (context, constraints) {
                                final width = constraints.maxWidth;
                                final childAspectRatio = width < 360
                                    ? 0.95
                                    : width < 400
                                    ? 1.0
                                    : width < 600
                                    ? 1.1
                                    : 1.3;

                                return GridView.count(
                                  shrinkWrap: true,
                                  physics:
                                      const NeverScrollableScrollPhysics(),
                                  crossAxisCount: 4,
                                  mainAxisSpacing: 10,
                                  crossAxisSpacing: 10,
                                  childAspectRatio: childAspectRatio,
                                  children: [
                                    _quickTile(emoji: '🤖', label: 'AI Chef',  route: '/chappy',    bgColor: Colors.orange.shade50),
                                    _quickTile(emoji: '🔍', label: 'Search',   route: '/search',    bgColor: Colors.blue.shade50),
                                    _quickTile(emoji: '❤️', label: 'Cookbook', route: '/favorites', bgColor: Colors.red.shade50),
                                    _quickTile(emoji: '🛒', label: 'Grocery',  route: '/grocery',   bgColor: Colors.green.shade50),
                                    _quickTile(emoji: '📍', label: 'Stores',   route: '/map',       bgColor: Colors.teal.shade50),
                                    _quickTile(emoji: '📊', label: 'Stats',    route: '/analytics', bgColor: Colors.purple.shade50),
                                    _quickTile(emoji: '📷', label: 'QR Scan',  route: '/qr',        bgColor: Colors.indigo.shade50),
                                    _quickTile(emoji: '🎬', label: 'Videos',   route: '/videos',    bgColor: Colors.pink.shade50),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ── Meal Customizer ────────────────────────────────────
                      Padding(
                        padding:
                            const EdgeInsets.symmetric(horizontal: 14),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                          elevation: 2,
                          child: Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  '🍽️ Customize Your Meal',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                _chips(
                                  'Mood',
                                  ['Comfort', 'Healthy', 'Festive', 'Quick'],
                                  selectedMood,
                                  (v) => selectedMood = v,
                                ),
                                _chips(
                                  'Time',
                                  ['10 min', '20 min', '30 min', '1 hr'],
                                  selectedTime,
                                  (v) => selectedTime = v,
                                ),
                                _chips(
                                  'Difficulty',
                                  ['Easy', 'Medium', 'Hard'],
                                  selectedDifficulty,
                                  (v) => selectedDifficulty = v,
                                ),
                                const SizedBox(height: 4),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    // ── Linked to Cheffy AI with pre-filled message ──
                                    onPressed: () => Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => ChatPage(
                                          initialMessage:
                                              'Give me a $selectedMood recipe that takes $selectedTime and is $selectedDifficulty difficulty 🍽️',
                                        ),
                                      ),
                                    ),
                                    icon: const Text(
                                      '🤖',
                                      style: TextStyle(fontSize: 16),
                                    ),
                                    label: Text(
                                      'Find $selectedMood $selectedTime Recipe',
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.orange,
                                      foregroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10),
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 12,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 30),
                    ],
                  ),
                ),
              ),
              buildFooter(),
            ],
          ),
        ),
      ),
    );
  }
}