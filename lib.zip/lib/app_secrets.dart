abstract class AppSecrets {
  // ── Groq (AI chef chat + rewards vision) ────────────────────────────────
  static const String groqApiKey = String.fromEnvironment(
    'GROQ_API_KEY',
    defaultValue: 'gsk_7CrRpcRnjWvU0nbdBbYMWGdyb3FYOur1RgvZ30olCdiQLsu6oxmN', 
  );

  // ── MapTiler (map tiles for Nearby Stores) ───────────────────────────────
  static const String mapTilerKey = String.fromEnvironment(
    'MAPTILER_KEY',
    defaultValue: 'Pv8s7JqznqzygunnOYuv',
  );

  // ── Admin access ─────────────────────────────────────────────────────────
  // Override at build time: --dart-define=ADMIN_EMAIL=other@example.com
  static const String adminEmail = String.fromEnvironment(
    'ADMIN_EMAIL',
    defaultValue: 'usman324m@gmail.com',
  );

  // Convenience: list of authorised admin e-mails
  static const List<String> adminEmails = [adminEmail];

  /// Returns true if [email] belongs to an admin account.
  /// Case-insensitive, trims whitespace.
  static bool isAdmin(String? email) {
    if (email == null || email.trim().isEmpty) return false;
    final normalised = email.trim().toLowerCase();
    return adminEmails.map((e) => e.toLowerCase()).contains(normalised);
  }
}
