import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/offline_service.dart';
import 'floating_ai_assistant.dart';

// Re-export ConnectivityBanner
export '../services/offline_service.dart' show ConnectivityBanner;

// ── Design tokens ─────────────────────────────────────────────────────────────
const _kPrimary    = Color(0xFFFF6B00);
const _kPrimaryDim = Color(0xFFFF8C00);
const Color _kTextMuted = Color(0xBBFFFFFF);

// ── Header ────────────────────────────────────────────────────────────────────
Widget buildHeader({
  required BuildContext context,
  required GlobalKey<ScaffoldState> scaffoldKey,
  required double screenWidth,
}) {
  final isMobile = screenWidth < 700;

  return Container(
    decoration: BoxDecoration(
      // ── Orange gradient ──────────────────────────────────────────────────
      gradient: const LinearGradient(
        colors: [Color(0xFFFF6B00), Color(0xFFFF8C00)],
        begin: Alignment.topLeft,
        end:   Alignment.bottomRight,
      ),
      boxShadow: [
        BoxShadow(
          color:     _kPrimary.withValues(alpha: 0.35),
          blurRadius: 12,
          offset:    const Offset(0, 3),
        ),
      ],
    ),
    child: SafeArea(
      bottom: false,
      child: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: isMobile ? 14 : 22,
          vertical:   11,
        ),
        child: Row(
          children: [
            _LogoBadge(size: isMobile ? 36 : 42),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Cheffy',
                  style: TextStyle(
                    color:       Colors.white,
                    fontSize:    isMobile ? 17 : 20,
                    fontWeight:  FontWeight.w800,
                    letterSpacing: -0.3,
                    height:      1.1,
                  ),
                ),
                if (!isMobile)
                  const Text(
                    'Your AI Personal Chef',
                    style: TextStyle(color: _kTextMuted, fontSize: 10),
                  ),
              ],
            ),
            const Spacer(),
            if (!isMobile)
              Wrap(
                spacing: 2,
                children: [
                  _navItem(context, '🏠', 'Home',     '/home'),
                  _navItem(context, '🤖', 'AI Chef',  '/chappy'),
                  _navItem(context, '🔍', 'Search',   '/search'),
                  _navItem(context, '❤️', 'Cookbook', '/favorites'),
                  _navItem(context, '🛒', 'Grocery',  '/grocery'),
                  _navItem(context, '📍', 'Stores',   '/map'),
                  _navItem(context, '🎬', 'Videos',   '/videos'),
                ],
              ),
            if (isMobile)
              IconButton(
                icon: const Icon(Icons.menu_rounded,
                    color: Colors.white, size: 26),
                onPressed: () =>
                    scaffoldKey.currentState?.openDrawer(),
              ),
          ],
        ),
      ),
    ),
  );
}

Widget _navItem(BuildContext context, String emoji,
    String label, String route) {
  return InkWell(
    onTap: () => Navigator.pushNamed(context, route),
    borderRadius: BorderRadius.circular(20),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 13)),
          const SizedBox(width: 4),
          Text(
            label,
            style: const TextStyle(
              color:      _kTextMuted,
              fontSize:   12,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    ),
  );
}

class _LogoBadge extends StatelessWidget {
  final double size;
  const _LogoBadge({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width:  size,
      height: size,
      decoration: BoxDecoration(
        // Slightly darker circle so it pops on the orange background
        color: Colors.white.withValues(alpha: 0.25),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color:     Colors.black.withValues(alpha: 0.15),
            blurRadius: 8,
            offset:    const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: Text('👨‍🍳', style: TextStyle(fontSize: size * 0.5)),
      ),
    );
  }
}

// ── Drawer ────────────────────────────────────────────────────────────────────
Widget buildDrawer(BuildContext context) =>
    Drawer(child: _DrawerContent());

class _DrawerContent extends StatefulWidget {
  @override
  State<_DrawerContent> createState() => _DrawerContentState();
}

class _DrawerContentState extends State<_DrawerContent> {
  User? _user;

  @override
  void initState() {
    super.initState();
    _user = FirebaseAuth.instance.currentUser;
  }

  Future<void> _logout() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.pop(context);
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    final photoUrl    = _user?.photoURL ?? '';
    final displayName =
        _user?.displayName ?? _user?.email ?? 'Chef';

    return Column(
      children: [
        // ── Drawer header — orange gradient ────────────────────────────
        Container(
          width: double.infinity,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFF6B00), Color(0xFFFF8C00)],
              begin: Alignment.topLeft,
              end:   Alignment.bottomRight,
            ),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding:
                  const EdgeInsets.fromLTRB(20, 20, 20, 20),
              child: Row(
                children: [
                  CircleAvatar(
                    radius:          28,
                    backgroundColor: Colors.white.withValues(alpha: 0.3),
                    backgroundImage: photoUrl.isNotEmpty
                        ? NetworkImage(photoUrl)
                        : null,
                    child: photoUrl.isEmpty
                        ? const Text('👨‍🍳',
                            style: TextStyle(fontSize: 24))
                        : null,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          displayName,
                          style: const TextStyle(
                            color:      Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize:   15,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (_user?.email != null)
                          Text(
                            _user!.email!,
                            style: const TextStyle(
                                color: _kTextMuted, fontSize: 11),
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // ── Menu items ─────────────────────────────────────────────────
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              _section('MAIN'),
              _drawerItem(context, Icons.home_rounded,
                  'Home',               '/home'),
              _drawerItem(context, Icons.star_rounded,
                  'Features',           '/features'),
              _drawerItem(context, Icons.smart_toy_outlined,
                  'Cheffy AI 🤖',      '/chappy'),
              _drawerItem(context, Icons.search_rounded,
                  'Search Recipes',     '/search'),
              _drawerItem(context, Icons.menu_book_rounded,
                  'Cookbook ❤️',       '/favorites'),
              _drawerItem(context, Icons.shopping_cart_rounded,
                  'Grocery 🛒',         '/grocery'),
              _section('EXPLORE'),
              _drawerItem(context, Icons.location_on_rounded,
                  'Nearby Stores 📍',  '/map'),
              _drawerItem(context, Icons.qr_code_scanner,
                  'QR Scanner 📷',     '/qr'),
              _drawerItem(context, Icons.play_circle_rounded,
                  'Cooking Videos 🎬', '/videos'),
              _drawerItem(context, Icons.bar_chart_rounded,
                  'Analytics 📊',      '/analytics'),
              _drawerItem(context, Icons.emoji_events_rounded,
                  'Rewards Hub 🏆',    '/rewards'),
            ],
          ),
        ),

        const Divider(height: 1),
        _drawerItem(context, Icons.person_rounded,
            'Profile',  '/profile', iconColor: _kPrimary),
        _drawerItem(context, Icons.settings_rounded,
            'Settings', '/settings'),
        ListTile(
          dense: true,
          leading: const Icon(Icons.logout_rounded,
              color: Colors.red, size: 20),
          title: const Text('Logout',
              style: TextStyle(color: Colors.red, fontSize: 14)),
          onTap: _logout,
        ),
        const SizedBox(height: 8),
      ],
    );
  }

  Widget _section(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(
        title,
        style: const TextStyle(
          fontSize:    10,
          fontWeight:  FontWeight.bold,
          color:       _kPrimary,
          letterSpacing: 1.4,
        ),
      ),
    );
  }

  Widget _drawerItem(
    BuildContext context,
    IconData icon,
    String label,
    String route, {
    Color? iconColor,
  }) {
    return ListTile(
      dense: true,
      leading: Icon(icon,
          color: iconColor ?? Colors.grey[700], size: 20),
      title: Text(label,
          style: const TextStyle(fontSize: 14)),
      onTap: () {
        Navigator.pop(context);
        Navigator.pushNamed(context, route);
      },
    );
  }
}

// ── Footer ────────────────────────────────────────────────────────────────────
Widget buildFooter() {
  return Container(
    width: double.infinity,
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        colors: [Color(0xFFFF6B00), Color(0xFFFF8C00)],
        begin: Alignment.topLeft,
        end:   Alignment.bottomRight,
      ),
    ),
    padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
    child: const Center(
      child: Text(
        'Cheffy © 2026  ·  Your AI Personal Chef 👨‍🍳',
        style: TextStyle(
            color: _kTextMuted, fontSize: 11, letterSpacing: 0.3),
      ),
    ),
  );
}

// ── CheffyScaffold ────────────────────────────────────────────────────────────
class CheffyScaffold extends StatelessWidget {
  final Widget child;
  final String currentPage;
  const CheffyScaffold({
    super.key,
    required this.child,
    this.currentPage = '',
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        child,
        FloatingAIAssistant(currentPage: currentPage),
      ],
    );
  }
}