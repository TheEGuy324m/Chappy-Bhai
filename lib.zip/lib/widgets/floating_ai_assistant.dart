import 'dart:convert';
import '../app_secrets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class FloatingAIAssistant extends StatefulWidget {
  final String currentPage;
  const FloatingAIAssistant({super.key, this.currentPage = ''});
  @override
  State<FloatingAIAssistant> createState() => _FloatingAIAssistantState();
}

class _FloatingAIAssistantState extends State<FloatingAIAssistant>
    with SingleTickerProviderStateMixin {
  bool _open = false;
  bool _loading = false;
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  late AnimationController _pulse;
  late Animation<double> _pulseAnim;

  final List<Map<String, String>> _msgs = [
    {
      'role': 'assistant',
      'text': "Hey! I'm Cheffy AI 🍳\nAsk me anything — recipes, tips, or say \"add groceries for pasta\" and I'll drop them in your cart automatically! 🛒",
    }
  ];

  static const _chips = [
    '🛒 Add groceries for pasta',
    '🥗 Healthy lunch idea',
    '🍝 Quick 20-min dinner',
    '🥚 Breakfast ideas',
  ];

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1300))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.14)
        .animate(CurvedAnimation(parent: _pulse, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _pulse.dispose();
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollBot() => Future.delayed(const Duration(milliseconds: 140), () {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOut);
        }
      });

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _ctrl.text).trim();
    if (text.isEmpty || _loading) return;
    _ctrl.clear();
    setState(() {
      _msgs.add({'role': 'user', 'text': text});
      _loading = true;
    });
    _scrollBot();

    final prefs = await SharedPreferences.getInstance();
    final grocItems = prefs.getStringList('grocery_items') ?? [];
    final favCount = (prefs.getStringList('favorites') ?? []).length;

    final system =
        'You are Cheffy AI, a warm expert cooking & grocery assistant in the Cheffy app.\n'
        'Current page: ${widget.currentPage}\n'
        'Grocery cart (${grocItems.length} items): ${grocItems.take(5).join(", ")}${grocItems.length > 5 ? "…" : ""}\n'
        'Saved cookbook count: $favCount\n\n'
        'RULES:\n'
        '1. Be concise and warm. Use food emojis.\n'
        '2. When the user wants groceries added, respond helpfully AND append exactly this block at the very end:\n'
        'GROCERY_ADD_JSON:[{"name":"Item","qty":1,"unit":"pcs","emoji":"🥦"}]\n'
        '3. Only include GROCERY_ADD_JSON when user explicitly wants items in the cart.\n'
        '4. Keep responses under 120 words unless giving a recipe.\n'
        '5. For recipes format steps as numbered list.';

    final apiMsgs = <Map<String, String>>[
      {'role': 'system', 'content': system},
      for (final m in _msgs)
        if ((m['text'] ?? '').trim().isNotEmpty)
          {'role': m['role'] == 'user' ? 'user' : 'assistant',
           'content': m['text']!.trim()},
    ];

    try {
      final res = await http
          .post(
            Uri.parse('https://api.groq.com/openai/v1/chat/completions'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer ${AppSecrets.groqApiKey}',
            },
            body: jsonEncode({
              'model': 'llama-3.3-70b-versatile',
              'max_tokens': 512,
              'messages': apiMsgs,
            }),
          )
          .timeout(const Duration(seconds: 30));

      if (!mounted) return;

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        String reply =
            data['choices'][0]['message']['content'] as String? ?? '';

        // Parse grocery additions
        final gm = RegExp(r'GROCERY_ADD_JSON:(\[[\s\S]+?\])').firstMatch(reply);
        if (gm != null) {
          try {
            final newItems = (jsonDecode(gm.group(1)!) as List);
            final existing = prefs.getStringList('grocery_items') ?? [];
            int added = 0;
            for (final item in newItems) {
              final lbl =
                  '${item['emoji'] ?? '🛒'} ${item['name']} – ${item['qty']} ${item['unit']}';
              if (!existing.contains(lbl)) {
                existing.add(lbl);
                added++;
              }
            }
            await prefs.setStringList('grocery_items', existing);
            reply = reply.replaceAll(gm.group(0)!, '').trimRight();
            reply +=
                '\n\n✅ $added item${added == 1 ? '' : 's'} added to your Grocery cart!';
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(
                    '🛒 $added item${added == 1 ? '' : 's'} added to Grocery!'),
                backgroundColor: Colors.green.shade600,
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                duration: const Duration(seconds: 2),
              ));
            }
          } catch (_) {}
        }

        setState(() {
          _msgs.add({'role': 'assistant', 'text': reply.trim()});
          _loading = false;
        });
      } else {
        setState(() {
          _msgs.add({
            'role': 'assistant',
            'text': '⚠️ AI unavailable (${res.statusCode}). Try again!',
          });
          _loading = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _msgs.add({
          'role': 'assistant',
          'text': '⚠️ Network error. Check your connection.',
        });
        _loading = false;
      });
    }
    _scrollBot();
  }

  Widget _bubble(Map<String, String> msg) {
    final isUser = msg['role'] == 'user';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 8),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser) ...[
            Container(
              width: 26, height: 26,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFFFF8C00), Color(0xFFFF4500)]),
                shape: BoxShape.circle,
              ),
              child: const Center(
                  child: Text('🍳', style: TextStyle(fontSize: 13))),
            ),
            const SizedBox(width: 6),
          ],
          Flexible(
            child: Container(
              constraints: const BoxConstraints(maxWidth: 230),
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
              decoration: BoxDecoration(
                color: isUser ? Colors.orange : Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isUser ? 16 : 4),
                  bottomRight: Radius.circular(isUser ? 4 : 16),
                ),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withValues(alpha: 0.07),
                      blurRadius: 4,
                      offset: const Offset(0, 2))
                ],
              ),
              child: Text(msg['text']!,
                  style: TextStyle(
                      fontSize: 13,
                      height: 1.45,
                      color: isUser ? Colors.white : Colors.black87)),
            ),
          ),
          if (isUser) const SizedBox(width: 4),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // ── Chat panel ──────────────────────────────────────────────────────
        if (_open)
          Positioned(
            bottom: 80, right: 16,
            child: Material(
              elevation: 14,
              borderRadius: BorderRadius.circular(20),
              child: Container(
                width: 300, height: 430,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF8F2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: Colors.orange.withValues(alpha: 0.3), width: 1.2),
                ),
                child: Column(
                  children: [
                    // Header
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 11),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                            colors: [Color(0xFFFF8C00), Color(0xFFFF4500)]),
                        borderRadius:
                            BorderRadius.vertical(top: Radius.circular(20)),
                      ),
                      child: Row(
                        children: [
                          const Text('🤖', style: TextStyle(fontSize: 20)),
                          const SizedBox(width: 8),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Cheffy AI',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14)),
                                Text('Your cooking assistant',
                                    style: TextStyle(
                                        color: Colors.white70, fontSize: 10)),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () => setState(() => _open = false),
                            child: const Icon(Icons.close,
                                color: Colors.white, size: 18),
                          ),
                        ],
                      ),
                    ),
                    // Messages
                    Expanded(
                      child: ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        itemCount: _msgs.length + (_loading ? 1 : 0),
                        itemBuilder: (_, i) {
                          if (_loading && i == _msgs.length) {
                            return Padding(
                              padding: const EdgeInsets.only(left: 14),
                              child: Row(children: [
                                Container(
                                  width: 26, height: 26,
                                  decoration: const BoxDecoration(
                                    gradient: LinearGradient(colors: [
                                      Color(0xFFFF8C00), Color(0xFFFF4500)
                                    ]),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Center(
                                      child: Text('🍳',
                                          style: TextStyle(fontSize: 13))),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 9),
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius:
                                          BorderRadius.circular(16)),
                                  child: const _TypingDots(),
                                ),
                              ]),
                            );
                          }
                          return _bubble(_msgs[i]);
                        },
                      ),
                    ),
                    // Quick chips
                    SizedBox(
                      height: 36,
                      child: ListView(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        children: _chips
                            .map((c) => GestureDetector(
                                  onTap: () => _send(c),
                                  child: Container(
                                    margin: const EdgeInsets.only(
                                        right: 6, top: 3, bottom: 3),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10),
                                    decoration: BoxDecoration(
                                      color:
                                          Colors.orange.withValues(alpha: 0.1),
                                      borderRadius:
                                          BorderRadius.circular(16),
                                      border: Border.all(
                                          color: Colors.orange
                                              .withValues(alpha: 0.4)),
                                    ),
                                    child: Center(
                                      child: Text(c,
                                          style: const TextStyle(
                                              fontSize: 11,
                                              color: Colors.orange)),
                                    ),
                                  ),
                                ))
                            .toList(),
                      ),
                    ),
                    // Input
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 4, 8, 10),
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _ctrl,
                              onSubmitted: (_) => _send(),
                              textInputAction: TextInputAction.send,
                              style: const TextStyle(fontSize: 13),
                              decoration: InputDecoration(
                                hintText: 'Ask anything...',
                                hintStyle: const TextStyle(
                                    fontSize: 13, color: Colors.grey),
                                filled: true,
                                fillColor: Colors.white,
                                isDense: true,
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 12, vertical: 9),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: BorderSide(
                                      color: Colors.orange.shade200),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: BorderSide(
                                      color: Colors.orange.shade200),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                  borderSide: const BorderSide(
                                      color: Colors.orange),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          GestureDetector(
                            onTap: () => _send(),
                            child: Container(
                              width: 36, height: 36,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFFFF8C00), Color(0xFFFF4500)
                                ]),
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.send_rounded,
                                  color: Colors.white, size: 17),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

        // ── Pulsing FAB ─────────────────────────────────────────────────────
        Positioned(
          bottom: 16, right: 16,
          child: ScaleTransition(
            scale: _open ? const AlwaysStoppedAnimation(1.0) : _pulseAnim,
            child: GestureDetector(
              onTap: () => setState(() => _open = !_open),
              child: Container(
                width: 56, height: 56,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFF8C00), Color(0xFFFF4500)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                        color: Colors.orange.withValues(alpha: 0.5),
                        blurRadius: 14,
                        offset: const Offset(0, 4)),
                  ],
                ),
                child: Center(
                  child: _open
                      ? const Icon(Icons.close,
                          color: Colors.white, size: 22)
                      : const Text('🤖',
                          style: TextStyle(fontSize: 26)),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _TypingDots extends StatefulWidget {
  const _TypingDots();
  @override
  State<_TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<_TypingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) => Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(3, (i) {
          final t = (_c.value + i * 0.33) % 1.0;
          final dy =
              (t < 0.5 ? t * 2 : (1 - t) * 2).clamp(0.0, 1.0) * 5;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: Transform.translate(
              offset: Offset(0, -dy),
              child: Container(
                width: 6, height: 6,
                decoration: const BoxDecoration(
                    color: Colors.orange, shape: BoxShape.circle),
              ),
            ),
          );
        }),
      ),
    );
  }
}
