// recipe_model.dart — lightweight wrapper used by RecipeService
// (MealModel in meal_model.dart is the canonical model;
//  this file is kept for import compatibility but simply re-exports it.)
export 'meal_model.dart';
